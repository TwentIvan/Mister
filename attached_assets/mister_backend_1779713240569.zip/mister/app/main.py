"""
FastAPI entrypoint — Mister backend.

Per lanciare in dev (Replit):
  uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
"""

from contextlib import asynccontextmanager
from fastapi import FastAPI
from sqlmodel import create_engine, Session

from app.config import get_settings
from app.db.schema import create_db_and_tables
from app.db.seed import seed_system_templates
from app.api import superadmin, templates as templates_api


# ============================================================
# DB engine (modulo-livello, condiviso)
# ============================================================

settings = get_settings()
engine = create_engine(settings.database_url, echo=settings.app_env == "dev")


# ============================================================
# LIFESPAN
# ============================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    create_db_and_tables(engine)

    # Seed dei 3 template di sistema se non ci sono
    with Session(engine) as session:
        seed_system_templates(session, force_overwrite=False)

    yield
    # Shutdown: nessuna cleanup speciale per ora


# ============================================================
# APP
# ============================================================

app = FastAPI(
    title="Mister API",
    description="Il fantacalcio manageriale.",
    version="0.2.0",
    lifespan=lifespan,
)

# Routes
app.include_router(templates_api.router)
app.include_router(superadmin.router)


# ============================================================
# HEALTH / ROOT
# ============================================================

@app.get("/")
def root():
    return {
        "app": settings.app_name,
        "version": "0.2.0",
        "env": settings.app_env,
        "endpoints": {
            "public_templates": "/api/templates",
            "superadmin": "/api/superadmin/templates",
            "docs": "/docs",
        },
    }


@app.get("/health")
def health():
    return {"status": "ok"}


# ============================================================
# TODO — endpoint da implementare nelle prossime iterazioni
# ============================================================
# - POST   /api/leagues                            (crea lega da template)
# - GET    /api/leagues/{id}
# - PUT    /api/leagues/{id}/federation            (modifica regolamento)
# - POST   /api/leagues/{id}/competitions          (crea competizione)
# - POST   /api/leagues/{id}/markets               (crea evento mercato)
# - POST   /api/markets/{id}/bids                  (offerta in asta)
# - WS     /ws/markets/{id}/live                   (asta live + voice)
# - POST   /api/lineups                            (schiera formazione)
# - POST   /api/matches/{id}/calculate             (engine + narratore)
# - POST   /api/contracts/{id}/rescind             (svincolo con penale)
# - POST   /api/contracts/{id}/raise-clause        (alza clausola)
# - POST   /api/contracts/{id}/preempt-renewal     (esercita pareggio in asta)
