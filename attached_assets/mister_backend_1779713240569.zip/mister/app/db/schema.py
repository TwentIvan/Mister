"""
Database schema con SQLModel (Pydantic + SQLAlchemy).

CAMBIAMENTI RISPETTO ALLA V0:
  + tabella template_profiles    ← preset DB-stored, gestibili dal superadmin
  + tabella contracts            ← contratti multi-stagione per Esploratore/Manageriale
  + tabella users                ← con flag is_superadmin
  ~ tabella federations          ← include ora feature_flags JSON snapshot
  ~ tabella competitions         ← schema dei 6 tipi
"""

from datetime import datetime
from typing import Optional
from sqlmodel import SQLModel, Field, JSON, Column


# ============================================================
# USERS (con flag superadmin)
# ============================================================

class UserDB(SQLModel, table=True):
    __tablename__ = "users"

    id: str = Field(primary_key=True)
    email: str = Field(index=True, unique=True)
    display_name: str
    is_superadmin: bool = Field(
        default=False,
        description="True solo per l'owner del prodotto (te). Concede accesso al pannello template profili."
    )
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ============================================================
# TEMPLATE PROFILES (gestiti dal superadmin)
# ============================================================

class TemplateProfileDB(SQLModel, table=True):
    __tablename__ = "template_profiles"

    id: str = Field(primary_key=True)
    name: str
    tagline: str
    description: str
    complexity_level: int
    estimated_weekly_minutes: int
    icon: str = ""

    feature_flags_json: dict = Field(default_factory=dict, sa_column=Column(JSON))
    suggested_markets_json: dict = Field(default_factory=dict, sa_column=Column(JSON))
    suggested_competitions_json: dict = Field(default_factory=dict, sa_column=Column(JSON))

    author_user_id: Optional[str] = Field(default=None, foreign_key="users.id")
    is_system: bool = False
    is_active: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# ============================================================
# FEDERATION (con feature flags snapshot)
# ============================================================

class FederationDB(SQLModel, table=True):
    __tablename__ = "federations"

    id: str = Field(primary_key=True)
    name: str
    description: str = ""
    template_id: Optional[str] = Field(default=None, index=True)

    feature_flags_json: dict = Field(default_factory=dict, sa_column=Column(JSON))
    rules_json: dict = Field(default_factory=dict, sa_column=Column(JSON))

    mode: str = "classic"
    voto_source: str = "consensus"

    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# ============================================================
# LEAGUE
# ============================================================

class LeagueDB(SQLModel, table=True):
    __tablename__ = "leagues"

    id: str = Field(primary_key=True)
    name: str
    federation_id: str = Field(foreign_key="federations.id", index=True)
    template_id: Optional[str] = Field(default=None, index=True)
    admin_user_id: str = Field(foreign_key="users.id", index=True)
    visibility: str = "private"
    invitation_code: Optional[str] = Field(default=None, index=True)
    season: int
    started: bool = False
    config_json: dict = Field(default_factory=dict, sa_column=Column(JSON))
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ============================================================
# COMPETITION
# ============================================================

class CompetitionDB(SQLModel, table=True):
    __tablename__ = "competitions"

    id: str = Field(primary_key=True)
    league_id: str = Field(foreign_key="leagues.id", index=True)
    name: str
    type: str
    season: int
    start_giornata: int
    end_giornata: int
    active: bool = True
    completed: bool = False
    config_json: dict = Field(default_factory=dict, sa_column=Column(JSON))
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ============================================================
# MARKET EVENT
# ============================================================

class MarketEventDB(SQLModel, table=True):
    __tablename__ = "market_events"

    id: str = Field(primary_key=True)
    league_id: str = Field(foreign_key="leagues.id", index=True)
    name: str
    type: str
    starts_at: datetime
    ends_at: datetime
    status: str = "scheduled"
    config_json: dict = Field(default_factory=dict, sa_column=Column(JSON))
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ============================================================
# CONTRACT (multi-stagione, solo se federation ha multi_season_contracts on)
# ============================================================

class ContractDB(SQLModel, table=True):
    __tablename__ = "contracts"

    id: str = Field(primary_key=True)
    league_id: str = Field(foreign_key="leagues.id", index=True)
    fanta_team_id: str = Field(foreign_key="fanta_teams.id", index=True)
    player_id: int = Field(index=True)
    season_start: int
    duration_seasons: int
    purchase_price: int
    clause_default: int
    clause_investment: int = 0
    state: str = "active"
    created_at: datetime = Field(default_factory=datetime.utcnow)
    closed_at: Optional[datetime] = None
    notes_json: dict = Field(default_factory=dict, sa_column=Column(JSON))


# ============================================================
# FANTA TEAM
# ============================================================

class FantaTeamDB(SQLModel, table=True):
    __tablename__ = "fanta_teams"

    id: str = Field(primary_key=True)
    league_id: str = Field(foreign_key="leagues.id", index=True)
    manager_user_id: str = Field(foreign_key="users.id", index=True)
    name: str
    name_auction: Optional[str] = None
    logo_url: Optional[str] = None
    jersey_json: Optional[dict] = Field(default=None, sa_column=Column(JSON))
    credits_remaining: int = 0
    roster_json: dict = Field(default_factory=dict, sa_column=Column(JSON))
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ============================================================
# PLAYER
# ============================================================

class PlayerDB(SQLModel, table=True):
    __tablename__ = "players"

    id: int = Field(primary_key=True)
    name: str = Field(index=True)
    full_name: str
    real_team: str = Field(index=True)
    role_classic: str
    roles_mantra_json: dict = Field(default_factory=dict, sa_column=Column(JSON))
    birth_date: Optional[str] = None
    nationality: Optional[str] = None
    height_cm: Optional[int] = None
    foot: Optional[str] = None
    photo_url: Optional[str] = None
    injured: bool = False
    current_value: Optional[float] = Field(default=None, index=True)
    last_synced_at: datetime = Field(default_factory=datetime.utcnow)


# ============================================================
# PERFORMANCE STATS
# ============================================================

class PlayerGiornataStatsDB(SQLModel, table=True):
    __tablename__ = "player_giornata_stats"

    id: Optional[int] = Field(default=None, primary_key=True)
    season: int = Field(index=True)
    round: int = Field(index=True)
    player_id: int = Field(foreign_key="players.id", index=True)
    fixture_id: int = Field(index=True)
    stats_json: dict = Field(default_factory=dict, sa_column=Column(JSON))
    synced_at: datetime = Field(default_factory=datetime.utcnow)


# ============================================================
# LINEUP
# ============================================================

class LineupDB(SQLModel, table=True):
    __tablename__ = "lineups"

    id: str = Field(primary_key=True)
    fanta_team_id: str = Field(foreign_key="fanta_teams.id", index=True)
    competition_id: str = Field(foreign_key="competitions.id", index=True)
    round: int = Field(index=True)
    module: str
    lineup_json: dict = Field(default_factory=dict, sa_column=Column(JSON))
    submitted_at: Optional[datetime] = None
    deadline: datetime


# ============================================================
# FANTA MATCH
# ============================================================

class FantaMatchDB(SQLModel, table=True):
    __tablename__ = "fanta_matches"

    id: str = Field(primary_key=True)
    competition_id: str = Field(foreign_key="competitions.id", index=True)
    round: int = Field(index=True)
    home_team_id: str = Field(foreign_key="fanta_teams.id")
    away_team_id: str = Field(foreign_key="fanta_teams.id")
    home_score: Optional[float] = None
    away_score: Optional[float] = None
    home_goals: Optional[int] = None
    away_goals: Optional[int] = None
    events_json: dict = Field(default_factory=dict, sa_column=Column(JSON))
    narrative: Optional[str] = None
    completed: bool = False
    calculated_at: Optional[datetime] = None


# ============================================================
# DB INIT
# ============================================================

def create_db_and_tables(engine):
    """Crea tutte le tabelle. Chiamare allo startup dell'app."""
    SQLModel.metadata.create_all(engine)
