"""
Seeder per i template profili di sistema.

Eseguito allo startup dell'applicazione. Comportamento:
  • Se i tre template Classico/Esploratore/Manageriale NON sono nel DB,
    li crea con i valori di app/presets/templates.py
  • Se ci sono ma sono `is_system=True`, li lascia stare. Il superadmin
    li avrà eventualmente modificati dal pannello, vogliamo rispettare
    le sue modifiche.
  • Se ci sono ma sono `is_system=False`, segnala un warning (qualcuno
    ha cambiato il flag, situazione anomala).

Per RIFOROMATTARE i template di sistema a un nuovo default (es. dopo un
deploy che ha cambiato il preset), c'è un endpoint dedicato POST
/api/superadmin/templates/reset-system che li riporta ai valori del file.
"""

from __future__ import annotations
import logging
from sqlmodel import Session, select

from app.presets.templates import SYSTEM_TEMPLATES
from app.db.schema import TemplateProfileDB


logger = logging.getLogger(__name__)


def seed_system_templates(session: Session, force_overwrite: bool = False) -> None:
    """
    Popola/aggiorna i template di sistema nel DB.

    Args:
      session: SQLModel session aperta
      force_overwrite: se True, sovrascrive anche i template di sistema esistenti.
                       Usato dall'endpoint di reset.
    """
    for template in SYSTEM_TEMPLATES:
        existing = session.get(TemplateProfileDB, template.id)

        if existing is None:
            # Non esiste: crea
            row = TemplateProfileDB(
                id=template.id,
                name=template.name,
                tagline=template.tagline,
                description=template.description,
                complexity_level=template.complexity_level,
                estimated_weekly_minutes=template.estimated_weekly_minutes,
                icon=template.icon,
                feature_flags_json=template.feature_flags,
                suggested_markets_json={
                    "items": [m.model_dump() for m in template.suggested_markets]
                },
                suggested_competitions_json={
                    "items": [c.model_dump() for c in template.suggested_competitions]
                },
                author_user_id=None,
                is_system=True,
                is_active=True,
            )
            session.add(row)
            logger.info(f"[seed] Template '{template.id}' creato")

        elif force_overwrite:
            # Esiste e dobbiamo sovrascrivere
            existing.name = template.name
            existing.tagline = template.tagline
            existing.description = template.description
            existing.complexity_level = template.complexity_level
            existing.estimated_weekly_minutes = template.estimated_weekly_minutes
            existing.icon = template.icon
            existing.feature_flags_json = template.feature_flags
            existing.suggested_markets_json = {
                "items": [m.model_dump() for m in template.suggested_markets]
            }
            existing.suggested_competitions_json = {
                "items": [c.model_dump() for c in template.suggested_competitions]
            }
            existing.is_active = True
            session.add(existing)
            logger.info(f"[seed] Template '{template.id}' sovrascritto (force_overwrite)")

        else:
            # Esiste, non sovrascriviamo, ma controlliamo lo stato
            if not existing.is_system:
                logger.warning(
                    f"[seed] Template '{template.id}' esiste ma is_system=False. "
                    "Qualcuno l'ha modificato, lascialo stare."
                )

    session.commit()
