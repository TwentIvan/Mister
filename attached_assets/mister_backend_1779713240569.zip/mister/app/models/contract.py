"""
Contract — il legame contrattuale tra un Manager e un Giocatore.

Rilevante solo per leghe con multi_season_contracts=True (Esploratore e
Manageriale di default). Per leghe Classico non si crea nessun Contract:
i giocatori sono "una sola stagione" e basta.

CALCOLI CHIAVE:
  • ingaggio_annuo = prezzo_acquisto / durata_contratto (ammortamento lineare)
  • ammortamento_residuo = ingaggio_annuo × stagioni_rimanenti
  • clausola_default = ammortamento_residuo × clause_default_factor (es. 0.8)
  • clausola_effettiva = clausola_default + clausola_investment (alzata pagando)
  • penale_rescissione = ammortamento_residuo × coefficient_for_year_X

LIFECYCLE:
  1. Asta: giocatore aggiudicato a prezzo P
  2. Finestra post-aggiudicazione: manager sceglie durata N e clausola
  3. Contract creato con state='active'
  4. Ogni inizio stagione, ingaggio_annuo viene scalato dal budget
  5. A scadenza naturale: Contract.state='expired', giocatore va all'asta come svincolato
     (con preemption_right del detentore uscente se federation.preemption_right=True)
  6. A rescissione attiva del manager: Contract.state='rescinded', applica penale
  7. A pagamento clausola da altro manager: Contract.state='clause_paid',
     vecchio manager incassa, nuovo manager apre nuovo Contract
"""

from __future__ import annotations
from datetime import datetime
from typing import List, Literal, Optional
from pydantic import BaseModel, Field, model_validator


ContractState = Literal[
    "active",       # in corso
    "expired",      # arrivato a scadenza naturale
    "rescinded",    # svincolato attivamente dal manager con penale
    "clause_paid",  # comprato da altro manager via clausola
    "traded",       # ceduto via scambio bilaterale
]


class Contract(BaseModel):
    id: str
    league_id: str
    fanta_team_id: str          # il manager (detentore)
    player_id: int              # il giocatore reale (API-Football ID)

    # Termini del contratto
    season_start: int           # stagione in cui parte il contratto (es. 2025)
    duration_seasons: int = Field(..., ge=1, le=10)
    purchase_price: int         # prezzo pagato all'asta

    # Clausola
    clause_default: int         # ammortamento_residuo × clause_default_factor al momento della firma
    clause_investment: int = Field(
        0, ge=0,
        description="Crediti aggiuntivi pagati dal manager per alzare la clausola sopra il default."
    )

    # Stato
    state: ContractState = "active"
    created_at: datetime = Field(default_factory=datetime.utcnow)
    closed_at: Optional[datetime] = None

    # Storia (per audit + UI)
    notes: List[str] = Field(default_factory=list)

    @property
    def ingaggio_annuo(self) -> float:
        """Quota annuale di ammortamento (prezzo spalmato sugli anni)."""
        return self.purchase_price / self.duration_seasons

    def seasons_remaining(self, current_season: int) -> int:
        """Stagioni rimanenti (incluso quella corrente se attivo)."""
        seasons_passed = current_season - self.season_start
        return max(0, self.duration_seasons - seasons_passed)

    def ammortamento_residuo(self, current_season: int) -> float:
        """Crediti residui da ammortizzare."""
        return self.ingaggio_annuo * self.seasons_remaining(current_season)

    def clausola_effettiva(self, current_season: int) -> float:
        """
        Clausola che un altro manager deve pagare per comprare il giocatore.
        Cala col tempo (ammortamento_residuo decrescente), a meno che il
        manager abbia investito per alzarla.
        """
        # Ricalcoliamo il default sulla base del residuo corrente
        from app.models.flags import FLAGS_BY_KEY
        factor = FLAGS_BY_KEY["clause_default_factor"].default  # fallback
        current_default = self.ammortamento_residuo(current_season) * factor
        return current_default + self.clause_investment

    def rescission_penalty(
        self,
        current_season: int,
        coefficients: List[float],
    ) -> float:
        """
        Penale per rescissione attiva del manager.

        I coefficienti sono indicizzati per anno (1-based) di contratto:
          coefficients[0] = anno 1, coefficients[1] = anno 2, ...

        Esempio: [1.5, 1.3, 1.1, 1.0, 1.0] su contratto 5-anni:
          rescissione anno 1 → ammortamento_residuo × 1.5
          rescissione anno 2 → ammortamento_residuo × 1.3
          ...
        """
        year_in_contract = (current_season - self.season_start) + 1  # 1-indexed
        idx = min(year_in_contract - 1, len(coefficients) - 1)
        coefficient = coefficients[idx] if coefficients else 1.0
        return self.ammortamento_residuo(current_season) * coefficient

    def rescission_recovery(
        self,
        current_season: int,
        recovery_pct: float = 50.0,
    ) -> float:
        """
        Crediti recuperati dal manager al netto della penale.
        """
        residuo = self.ammortamento_residuo(current_season)
        penalty = residuo * 0.5  # placeholder, da raffinare con coefficients
        return residuo * (recovery_pct / 100.0) - penalty
