"""
Competition — un singolo torneo dentro una Lega.

Sei tipi supportati, allineati alle modalità standard del fantacalcio italiano:

  • campionato         — girone all'italiana, default ripetuto N volte
  • coppa              — eliminazione diretta, bracket manuale
  • battle_royale      — tutti contro tutti ogni giornata, cumulativo
  • sprint_race        — eliminazione del peggiore ogni giornata
  • formula_uno        — punteggio F1 per posizione ogni giornata
  • punteggio_assoluto — somma cumulativa pura

L'admin crea ESPLICITAMENTE ogni Competizione: nessun automatismo, nessun
calendario di default. La Lega nasce con zero competizioni.
"""

from __future__ import annotations
from datetime import datetime
from typing import Dict, List, Literal, Optional
from pydantic import BaseModel, Field, model_validator


# ============================================================
# ENUMS
# ============================================================

CompetitionType = Literal[
    "campionato",
    "coppa",
    "battle_royale",
    "sprint_race",
    "formula_uno",
    "punteggio_assoluto",
]

# Catalogo completo dei criteri di tiebreaker possibili.
# La validazione per-tipo (quale criterio è applicabile a quale tipo) avviene
# nel model_validator sotto.
TiebreakerCriterion = Literal[
    "punti",                       # punti classifica 3-1-0
    "scontri_diretti",             # H2H (solo round-robin)
    "differenza_reti",             # gol_fatti - gol_subiti
    "gol_fatti",
    "gol_subiti",
    "punteggio_totale",            # somma fanta-punti assoluti
    "vittorie",                    # numero match vinti (campionato/battle_royale)
    "vittorie_totali_match",       # alias per battle_royale: somma vittorie su tutti i match parallel
    "giornate_vinte",              # primi posti di giornata (formula_uno / punteggio_assoluto)
    "f1_punti",                    # punti F1 (solo formula_uno)
    "f1_vittorie",                 # primi posti in F1
    "f1_podi",                     # top 3 in F1
    "punteggio_max_giornata",      # punteggio singolo massimo
    "gol_fatti_giornata",          # per sprint_race tiebreaker eliminazione
    "punteggio_totale_storico",    # cumulativo fino a quel momento (sprint_race)
    "sorteggio",                   # ultimo, casuale
]


# Mapping tipo → criteri ammessi
ALLOWED_TIEBREAKERS_BY_TYPE: dict[str, list[str]] = {
    "campionato": [
        "scontri_diretti", "differenza_reti", "gol_fatti", "gol_subiti",
        "punteggio_totale", "vittorie", "sorteggio",
    ],
    "coppa": [],  # gestito a livello di singolo match (penalties / fanta_extra)
    "battle_royale": [
        "vittorie_totali_match", "differenza_reti", "gol_fatti", "gol_subiti",
        "punteggio_totale", "giornate_vinte", "sorteggio",
    ],
    "sprint_race": [
        "gol_fatti_giornata", "punteggio_totale_storico", "sorteggio",
    ],
    "formula_uno": [
        "f1_vittorie", "f1_podi", "punteggio_totale", "punteggio_max_giornata",
        "sorteggio",
    ],
    "punteggio_assoluto": [
        "giornate_vinte", "punteggio_max_giornata", "sorteggio",
    ],
}


# ============================================================
# SCORING (per round-robin / battle royale)
# ============================================================

class ScoringRules(BaseModel):
    """Punti per win / draw / loss (default 3-1-0)."""
    win: int = 3
    draw: int = 1
    loss: int = 0


# ============================================================
# SUB-MODELS PER TIPO
# ============================================================

class CampionatoSettings(BaseModel):
    """
    Campionato a girone all'italiana, ripetuto N volte sul calendario di stagione.

    Esempio classico per 8 manager:
      giornate_per_girone = 7  (n-1)
      numero_gironi       = 5
      → totale 35 giornate fanta su 38 di Serie A

    Lo schedule è auto-generato dal sistema (round-robin), l'admin non lo tocca.
    Per ogni girone si può sovrascrivere il flag "ignora vantaggio campo"
    (utile per il girone "neutro" dell'esempio sopra).
    """
    giornate_per_girone: int = Field(
        ...,
        description="Tipicamente uguale a n_manager - 1. Calcolato a creation time."
    )
    numero_gironi: int = Field(
        5,
        ge=1,
        description="Quante volte si ripete il girone all'italiana."
    )
    home_advantage_enabled: bool = Field(
        True,
        description="Bonus al fanta-punteggio del padrone di casa (vedi Federation.home_advantage)."
    )
    home_advantage_bonus: float = Field(
        3.0,
        description="Bonus punti da applicare. Default eredita da Federation."
    )
    # Override per girone: keys = numero girone (1-indexed), values = "non considerare fattore campo"
    girone_neutro: List[int] = Field(
        default_factory=list,
        description="Numeri di girone che si giocano in campo neutro (no home advantage)."
    )


class CoppaSettings(BaseModel):
    """Coppa a eliminazione diretta. Bracket gestito manualmente dall'admin."""
    two_legs: bool = Field(
        False,
        description="False = gara secca; True = andata + ritorno."
    )
    tie_break_in_match: Literal["penalties", "fanta_extra_time", "away_goals"] = Field(
        "penalties",
        description=(
            "'penalties': sorteggio fanta come rappresentazione rigori. "
            "'fanta_extra_time': tempi supplementari simulati (50% voti). "
            "'away_goals': gol fuori casa (FIFA l'ha abolita, opzione legacy)."
        )
    )
    bracket: List[List[str]] = Field(
        default_factory=list,
        description=(
            "Lista delle coppie del primo turno, ogni coppia è una lista [team_id_1, team_id_2]. "
            "L'admin definisce esplicitamente l'abbinamento iniziale al momento della creazione."
        )
    )


class BattleRoyaleSettings(BaseModel):
    """
    Tutti contro tutti ogni giornata. Cumulative.
    Ogni manager gioca N-1 partite per giornata, somma punti 0-(3*(N-1)).
    """
    home_advantage_enabled: bool = Field(
        False,
        description="In battle royale di norma off (formato simmetrico)."
    )


class SprintRaceSettings(BaseModel):
    """Eliminazione del peggiore di giornata fino a un solo sopravvissuto."""
    pass  # nessuna config oltre ai partecipanti/range giornate/tiebreaker


class FormulaUnoSettings(BaseModel):
    """Punti F1 per posizione di giornata."""
    points_scale: List[int] = Field(
        default_factory=lambda: [25, 18, 15, 12, 10, 8, 6, 4, 2, 1],
        description=(
            "Punti assegnati a posizione 1, 2, 3, ... . "
            "Posizioni oltre la lunghezza della scala ricevono 0 punti. "
            "Preset suggeriti: modern (default), historic [10,6,4,3,2,1]."
        )
    )


class PunteggioAssolutoSettings(BaseModel):
    """Somma cumulativa fanta-punteggi su tutte le giornate."""
    exclude_worst_n_giornate: int = Field(
        0,
        ge=0,
        description="Scarto delle peggiori N giornate per ammorbidire la fortuna."
    )


# ============================================================
# COMPETITION
# ============================================================

class Competition(BaseModel):
    """Una Competizione dentro una Lega."""
    id: str
    league_id: str
    name: str = Field(..., min_length=2, max_length=80)
    description: str = ""
    type: CompetitionType
    season: int

    # Range giornate Serie A su cui si svolge
    start_giornata: int = Field(..., ge=1, le=38)
    end_giornata: int = Field(..., ge=1, le=38)

    # Partecipanti (sottoinsieme dei manager della lega)
    participant_team_ids: List[str] = Field(
        default_factory=list,
        description="Vuoto = tutti i manager della lega."
    )

    # Sub-config (solo uno popolato in base al type)
    campionato: Optional[CampionatoSettings] = None
    coppa: Optional[CoppaSettings] = None
    battle_royale: Optional[BattleRoyaleSettings] = None
    sprint_race: Optional[SprintRaceSettings] = None
    formula_uno: Optional[FormulaUnoSettings] = None
    punteggio_assoluto: Optional[PunteggioAssolutoSettings] = None

    # Scoring (solo per campionato e battle_royale)
    scoring: ScoringRules = Field(default_factory=ScoringRules)

    # Tiebreaker — lista ordinata dall'admin
    tiebreakers: List[TiebreakerCriterion] = Field(default_factory=list)

    # Premi (testuali, no monetario)
    prizes: Dict[str, str] = Field(default_factory=dict)

    # Calendario
    starts_at: Optional[datetime] = None
    ends_at: Optional[datetime] = None

    active: bool = True
    completed: bool = False
    created_at: datetime = Field(default_factory=datetime.utcnow)

    @model_validator(mode="after")
    def validate_consistency(self):
        # 1. start_giornata ≤ end_giornata
        if self.start_giornata > self.end_giornata:
            raise ValueError("start_giornata deve essere ≤ end_giornata")

        # 2. Il sub-model giusto deve essere popolato in base al type
        type_to_field = {
            "campionato": "campionato",
            "coppa": "coppa",
            "battle_royale": "battle_royale",
            "sprint_race": "sprint_race",
            "formula_uno": "formula_uno",
            "punteggio_assoluto": "punteggio_assoluto",
        }
        required_field = type_to_field[self.type]
        if getattr(self, required_field) is None:
            # Auto-popola con default
            default_models = {
                "campionato": lambda: CampionatoSettings(giornate_per_girone=7),
                "coppa": CoppaSettings,
                "battle_royale": BattleRoyaleSettings,
                "sprint_race": SprintRaceSettings,
                "formula_uno": FormulaUnoSettings,
                "punteggio_assoluto": PunteggioAssolutoSettings,
            }
            setattr(self, required_field, default_models[self.type]())

        # 3. I tiebreaker selezionati devono essere applicabili al tipo
        allowed = ALLOWED_TIEBREAKERS_BY_TYPE[self.type]
        for tb in self.tiebreakers:
            if tb == "sorteggio":
                continue  # sempre ammesso
            if tb not in allowed:
                raise ValueError(
                    f"Tiebreaker '{tb}' non applicabile al tipo '{self.type}'. "
                    f"Ammessi: {allowed + ['sorteggio']}"
                )

        # 4. Sorteggio in coda automatico (rete di sicurezza)
        if "sorteggio" not in self.tiebreakers:
            self.tiebreakers.append("sorteggio")

        return self
