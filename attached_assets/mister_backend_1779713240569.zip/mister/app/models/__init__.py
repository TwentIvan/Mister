"""
Modelli di dominio di Mister.

ARCHITETTURA:

  TemplateProfile           ← preset di partenza per nuove leghe (DB-stored, superadmin-editable)
       ↓ (snapshot al momento della creazione)
  Federation                ← regolamento sportivo + feature flags di UNA lega
       ↑
  League                    ← l'istanza con manager, crediti, rosa
       ↓ (ne ha N di ognuno)
  Competition + MarketEvent ← creati dall'admin nel corso della stagione

Modelli ausiliari: Contract, Player, FantaTeam, Lineup, FantaMatch.
"""

# Feature flag catalog (source of truth per superadmin)
from app.models.flags import (
    FlagSpec,
    FlagCategory,
    FlagType,
    FLAGS,
    FLAGS_BY_KEY,
    default_flag_values,
    validate_flag_value,
    flags_by_category,
)

# Template profile (preset DB-stored)
from app.models.template import (
    TemplateProfile,
    MarketEventTemplate,
    CompetitionSuggestion,
)

# Federation (regolamento + feature flag snapshot)
from app.models.federation import (
    Federation,
    Mode,
    VotoSource,
    BonusMalus,
    GoalThresholds,
    DefenseModifier,
    MidfieldModifier,
    HomeAdvantage,
    SubstitutionRules,
)

# League (instance)
from app.models.league import (
    League,
    Visibility,
    LineupVisibility,
    SquadComposition,
    CaptainRules,
    BudgetRules,
    PostAcquisitionWindow,
)

# Competition (i 6 tipi)
from app.models.competition import (
    Competition,
    CompetitionType,
    TiebreakerCriterion,
    ALLOWED_TIEBREAKERS_BY_TYPE,
    ScoringRules,
    CampionatoSettings,
    CoppaSettings,
    BattleRoyaleSettings,
    SprintRaceSettings,
    FormulaUnoSettings,
    PunteggioAssolutoSettings,
)

# Market (eventi di mercato)
from app.models.market import (
    MarketEvent,
    MarketType,
    AuctionMode,
    ReleaseMode,
    TimeWindow,
    TimeshiftRule,
    AutobidRule,
    AuctionRules,
    TradeRules,
    ReleaseRules,
    FreeAgentRules,
)

# Contract (multi-season, solo per leghe con multi_season_contracts on)
from app.models.contract import (
    Contract,
    ContractState,
)

# Common (Player, FantaTeam, Lineup, FantaMatch)
from app.models.common import (
    Player,
    PlayerRole,
    MantraRole,
    FantaTeam,
    Lineup,
    FantaMatch,
)

__all__ = [
    # flags
    "FlagSpec", "FlagCategory", "FlagType",
    "FLAGS", "FLAGS_BY_KEY",
    "default_flag_values", "validate_flag_value", "flags_by_category",
    # template
    "TemplateProfile", "MarketEventTemplate", "CompetitionSuggestion",
    # federation
    "Federation", "Mode", "VotoSource",
    "BonusMalus", "GoalThresholds",
    "DefenseModifier", "MidfieldModifier", "HomeAdvantage",
    "SubstitutionRules",
    # league
    "League", "Visibility", "LineupVisibility",
    "SquadComposition", "CaptainRules", "BudgetRules", "PostAcquisitionWindow",
    # competition
    "Competition", "CompetitionType", "TiebreakerCriterion",
    "ALLOWED_TIEBREAKERS_BY_TYPE", "ScoringRules",
    "CampionatoSettings", "CoppaSettings",
    "BattleRoyaleSettings", "SprintRaceSettings",
    "FormulaUnoSettings", "PunteggioAssolutoSettings",
    # market
    "MarketEvent", "MarketType", "AuctionMode", "ReleaseMode",
    "TimeWindow", "TimeshiftRule", "AutobidRule",
    "AuctionRules", "TradeRules", "ReleaseRules", "FreeAgentRules",
    # contract
    "Contract", "ContractState",
    # common
    "Player", "PlayerRole", "MantraRole",
    "FantaTeam", "Lineup", "FantaMatch",
]
