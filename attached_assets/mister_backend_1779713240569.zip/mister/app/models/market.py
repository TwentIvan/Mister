"""
MarketEvent — un evento di mercato schedulato dentro una Lega.

L'admin crea esplicitamente ogni evento. Il TemplateProfile suggerisce un
calendario starter in onboarding, ma è solo una facilitation: l'admin
accetta/rifiuta ogni suggerimento, e in qualsiasi momento può aggiungere
nuovi eventi.

Quattro tipi canonici (auction / trade / release / free_agent) mappano le
7 modalità di Leghe Fantacalcio in una tassonomia più chiara.
"""

from __future__ import annotations
from datetime import datetime
from typing import List, Literal, Optional
from pydantic import BaseModel, Field, model_validator


# ============================================================
# ENUMS
# ============================================================

MarketType = Literal["auction", "trade", "release", "free_agent"]
AuctionMode = Literal["live", "async", "blind", "token"]
ReleaseMode = Literal["open", "blind"]


# ============================================================
# COMMON SUB-MODELS
# ============================================================

class TimeWindow(BaseModel):
    starts_at: datetime
    ends_at: datetime
    open_24h: bool = False
    daily_hours: Optional[tuple[int, int]] = None


class TimeshiftRule(BaseModel):
    """Anti-snipe: estende la scadenza su rilanci dell'ultimo minuto."""
    enabled: bool = True
    threshold_seconds: int = 30
    extension_seconds: int = 30


class AutobidRule(BaseModel):
    """Autobid con soglia max o strategia AI delegata."""
    enabled: bool = True
    allow_ai_strategy: bool = True
    visible_max_to_others: bool = False


# ============================================================
# AUCTION
# ============================================================

class AuctionRules(BaseModel):
    mode: AuctionMode

    role_pool: List[Literal["GK", "DEF", "MID", "ATT"]] = Field(
        default_factory=lambda: ["GK", "DEF", "MID", "ATT"]
    )
    player_pool: Optional[List[str]] = None  # None = tutti i giocatori Serie A

    base_bid: int = Field(1, ge=1)
    bid_increments: List[int] = Field(default_factory=lambda: [1, 5, 10])
    seconds_per_player: int = Field(60)

    timeshift: TimeshiftRule = Field(default_factory=TimeshiftRule)
    autobid: AutobidRule = Field(default_factory=AutobidRule)

    show_best_bidder: bool = True

    # Solo per mode='live'
    voice_recognition: bool = True
    auctioneer_ai: bool = True

    # Solo per mode='blind'
    bids_per_player: int = 1
    reveal_all_after: bool = True

    # Solo per mode='token'
    tokens_per_manager: Optional[int] = None

    # Pareggio del detentore uscente (richiede federation.preemption_right)
    allow_preemption: bool = Field(
        True,
        description=(
            "Se True e il giocatore è in scadenza contratto, il detentore "
            "uscente ha il diritto di pareggio in tempo reale durante l'asta."
        )
    )

    @model_validator(mode="after")
    def validate_mode_specific(self):
        if self.mode == "blind" and self.bids_per_player < 1:
            raise ValueError("blind auction requires bids_per_player >= 1")
        if self.mode == "token" and self.tokens_per_manager is None:
            self.tokens_per_manager = 11
        return self


# ============================================================
# TRADE
# ============================================================

class TradeRules(BaseModel):
    bilateral_only: bool = True
    include_credits: bool = True
    requires_admin_approval: bool = True
    cool_down_days: int = 0
    max_per_manager: Optional[int] = None


# ============================================================
# RELEASE
# ============================================================

class ReleaseRules(BaseModel):
    mode: ReleaseMode = "open"
    recovery_percentage: float = Field(50.0, ge=0.0, le=100.0)
    max_releases_per_manager: Optional[int] = None
    block_rebuy: bool = False
    rebuy_cooldown_days: int = 7
    blind_competing_bids: bool = False
    apply_rescission_penalty: bool = Field(
        False,
        description=(
            "Se True e il giocatore ha contratto pluriennale, applica la "
            "penale di rescissione (federation.rescission_penalty + coefficienti)."
        )
    )


# ============================================================
# FREE AGENT
# ============================================================

class FreeAgentRules(BaseModel):
    base_price_per_role: dict[str, int] = Field(
        default_factory=lambda: {"GK": 5, "DEF": 5, "MID": 8, "ATT": 10}
    )
    allow_blind_competing: bool = True
    waiting_period_hours: int = 24
    include_rescinded_players: bool = Field(
        True,
        description=(
            "Se True, includi anche giocatori svincolati attivamente da altri manager. "
            "Se False, solo non-acquistati all'asta iniziale (Classico)."
        )
    )


# ============================================================
# MARKET EVENT
# ============================================================

class MarketEvent(BaseModel):
    id: str
    league_id: str
    name: str
    type: MarketType
    description: str = ""

    window: TimeWindow

    # Sub-config (popolato solo quello che combacia col type)
    auction: Optional[AuctionRules] = None
    trade: Optional[TradeRules] = None
    release: Optional[ReleaseRules] = None
    free_agent: Optional[FreeAgentRules] = None

    status: Literal["scheduled", "active", "completed", "cancelled"] = "scheduled"
    created_at: datetime = Field(default_factory=datetime.utcnow)

    label_color: str = "#1f4733"

    @model_validator(mode="after")
    def settings_match_type(self):
        if self.type == "auction" and self.auction is None:
            raise ValueError("MarketEvent of type 'auction' requires AuctionRules")
        if self.type == "trade" and self.trade is None:
            self.trade = TradeRules()
        if self.type == "release" and self.release is None:
            self.release = ReleaseRules()
        if self.type == "free_agent" and self.free_agent is None:
            self.free_agent = FreeAgentRules()
        return self
