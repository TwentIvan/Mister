"""
League — l'istanza di una competizione fantacalcio organizzata.

La League appartiene a una Federation (1-a-1). La Federation contiene il
regolamento sportivo + i feature flags. La League contiene il resto:
chi sono i manager, quanti crediti partono, com'è la rosa, com'è il
capitano, ecc.

Il `template_id` è denormalizzato qui per analytics/UI rapida — la fonte
di verità è la Federation.
"""

from __future__ import annotations
from datetime import datetime
from typing import Dict, List, Literal, Optional
from pydantic import BaseModel, Field, field_validator


# ============================================================
# ENUMS
# ============================================================

Visibility = Literal["private", "public", "unlisted"]
LineupVisibility = Literal["always", "after_deadline", "hidden_all_season"]


# ============================================================
# SUB-MODELS
# ============================================================

class SquadComposition(BaseModel):
    """Composizione rosa: quanti giocatori per ruolo, quanti titolari, quali moduli."""
    gk: int  = Field( 3, ge=2, le=5)
    def_: int= Field( 8, ge=6, le=12, alias="def")
    mid: int = Field( 8, ge=6, le=12)
    att: int = Field( 6, ge=4, le=10)
    starters_total: int = Field(11)
    allowed_modules: List[str] = Field(
        default_factory=lambda: [
            "3-4-3", "3-5-2",
            "4-3-3", "4-4-2", "4-5-1",
            "5-3-2", "5-4-1",
        ]
    )

    model_config = {"populate_by_name": True}

    @property
    def total(self) -> int:
        return self.gk + self.def_ + self.mid + self.att


class CaptainRules(BaseModel):
    enabled: bool = True
    multiplier: float = Field(
        1.0,
        description="1.0 = simbolico (default). 1.5 = generoso. Sopra 2.0 sbilancia."
    )
    use_vice: bool = True


class BudgetRules(BaseModel):
    """Crediti d'asta e regole di gestione."""
    initial_credits: int = Field(500, ge=100, le=10000)
    minimum_bid: int = Field(1, ge=1)
    allow_negative_balance: bool = False
    reserve_for_unfilled_roles: bool = True


class PostAcquisitionWindow(BaseModel):
    """
    Finestra di decisione contratto/clausola dopo l'aggiudicazione di un giocatore.
    Applicabile solo se il template ha multi_season_contracts on.
    """
    enabled: bool = True
    live_seconds: int = Field(
        45,
        description="Quanti secondi ha il manager in asta live per decidere durata + clausola."
    )
    async_hours: int = Field(
        12,
        description="Quante ore in asta async."
    )
    default_contract_years: int = Field(
        1,
        description="Se il manager non decide entro la finestra, assegna questo numero di anni."
    )
    default_clause_action: Literal["leave_default", "decline"] = "leave_default"


# ============================================================
# LEAGUE
# ============================================================

class League(BaseModel):
    """Una Lega fantacalcio. Una Federation, un set di manager, un calendario."""
    id: str
    name: str = Field(..., min_length=3, max_length=80)

    # Referenza al regolamento
    federation_id: str = Field(..., description="ID della Federation di questa lega.")

    # Tracciabilità del template di origine
    template_id: Optional[str] = Field(
        None,
        description="Slug del template scelto in onboarding. Solo informativo."
    )

    # Visibilità e accesso
    visibility: Visibility = "private"
    invitation_code: Optional[str] = None

    # Gestione manager
    max_managers: int = Field(10, ge=4, le=20)
    admin_user_id: str
    co_admin_user_ids: List[str] = Field(default_factory=list)

    # Configurazione rose e tattica
    squad: SquadComposition = Field(default_factory=SquadComposition)
    captain: CaptainRules = Field(default_factory=CaptainRules)
    budget: BudgetRules = Field(default_factory=BudgetRules)
    post_acquisition_window: PostAcquisitionWindow = Field(default_factory=PostAcquisitionWindow)

    # Visibilità formazioni e rose
    lineup_visibility: LineupVisibility = "after_deadline"
    roster_visibility: LineupVisibility = "always"

    # Calendario e stato
    season: int = Field(..., description="2025 per stagione 2025-26")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    started: bool = False

    # Notifiche
    notify_email: bool = True
    notify_push: bool = True

    @field_validator("name")
    @classmethod
    def name_clean(cls, v: str) -> str:
        return v.strip()
