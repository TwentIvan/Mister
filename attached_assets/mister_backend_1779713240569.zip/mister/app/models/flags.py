"""
Feature flags — catalogo canonico delle feature configurabili del prodotto.

Questo file è la single source of truth di "cosa il sistema sa esprimere".
Aggiungere un flag qui richiede contestualmente:
  1. Implementare il comportamento corrispondente nel match engine, nei
     mercati, o nella UI a seconda della categoria
  2. Aggiornare i template profili predefiniti in app/presets/templates.py
  3. Eventualmente migrare le leghe esistenti (con default-off, in genere)

I valori di default qui dichiarati sono i "valori conservativi": quello
che fa il sistema se nessuno tocca nulla. I template profili sovrascrivono
con valori specifici di profilo.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Literal


# ============================================================
# CATEGORIE
# ============================================================

FlagCategory = Literal[
    "contracts",     # contratti pluriennali, rinnovi, prelazione
    "market",        # mercati schedulabili in stagione
    "economy",       # ammortamento, clausole, recovery, carryover
    "tactics",       # moduli, no-schema
    "scouting",      # discovery giocatori, sviluppo
]

FlagType = Literal["bool", "int", "float", "string"]


@dataclass
class FlagSpec:
    """Specifica di un flag: nome, tipo, default, descrizione, categoria."""
    key: str
    category: FlagCategory
    type: FlagType
    default: Any
    label: str
    description: str
    # se type=int/float, limiti opzionali per validazione UI
    min_value: float | None = None
    max_value: float | None = None
    # se type=string, elenco valori consentiti opzionale
    allowed_values: list[str] | None = None


# ============================================================
# CATALOGO COMPLETO
# ============================================================
# L'ordine qui è quello che appare nel pannello superadmin.

FLAGS: list[FlagSpec] = [
    # --- CONTRATTI E PERSISTENZA ---
    FlagSpec(
        key="multi_season_contracts",
        category="contracts",
        type="bool",
        default=False,
        label="Contratti pluriennali",
        description=(
            "Permette contratti di durata maggiore di 1 stagione. "
            "Se off, ogni stagione riparte con rosa azzerata."
        ),
    ),
    FlagSpec(
        key="max_contract_length",
        category="contracts",
        type="int",
        default=1,
        min_value=1,
        max_value=10,
        label="Durata massima contratto (stagioni)",
        description="Massimo numero di stagioni per cui un manager può vincolarsi a un giocatore.",
    ),
    FlagSpec(
        key="contract_renewal",
        category="contracts",
        type="bool",
        default=False,
        label="Rinnovo contrattuale",
        description="Abilita il flusso esplicito di rinnovo prima della scadenza.",
    ),
    FlagSpec(
        key="preemption_right",
        category="contracts",
        type="bool",
        default=False,
        label="Diritto di pareggio in asta",
        description=(
            "Alla scadenza, il detentore uscente può pareggiare in tempo "
            "reale i rilanci nell'asta di re-acquisto del giocatore."
        ),
    ),

    # --- MERCATO ---
    FlagSpec(
        key="repair_auction_january",
        category="market",
        type="bool",
        default=True,
        label="Riparazione di gennaio",
        description="Asta di riparazione invernale (async) sui nuovi acquisti reali.",
    ),
    FlagSpec(
        key="free_agent_pool",
        category="market",
        type="bool",
        default=True,
        label="Pool svincolati permanente",
        description=(
            "Giocatori non acquistati restano disponibili come free agent. "
            "In modalità avanzata include anche svincolati da altri manager."
        ),
    ),
    FlagSpec(
        key="direct_trades",
        category="market",
        type="bool",
        default=False,
        label="Scambi diretti tra manager",
        description="Permette scambi 1-1 tra manager, con o senza crediti.",
    ),
    FlagSpec(
        key="always_on_markets",
        category="market",
        type="bool",
        default=False,
        label="Mercati sempre attivi in stagione",
        description="Scambi e free agent disponibili in continuativa, non in finestre.",
    ),

    # --- ECONOMIA ---
    FlagSpec(
        key="carryover_budget",
        category="economy",
        type="bool",
        default=False,
        label="Carryover del budget tra stagioni",
        description="A fine stagione i crediti residui vengono mantenuti per quella successiva.",
    ),
    FlagSpec(
        key="carryover_percentage",
        category="economy",
        type="float",
        default=0.0,
        min_value=0.0,
        max_value=100.0,
        label="Percentuale di carryover",
        description="Percentuale del residuo che viene mantenuta. Solo se carryover_budget è on.",
    ),
    FlagSpec(
        key="player_value_dynamic",
        category="economy",
        type="bool",
        default=False,
        label="Valore giocatore dinamico",
        description=(
            "Il sistema traccia un valore di mercato del giocatore che si "
            "aggiorna in base a performance, età, minutaggio."
        ),
    ),
    FlagSpec(
        key="amortization",
        category="economy",
        type="bool",
        default=False,
        label="Ammortamento del prezzo d'acquisto",
        description=(
            "Il prezzo pagato all'asta viene spalmato sugli anni di "
            "contratto come ingaggio annuo. Richiede multi_season_contracts."
        ),
    ),
    FlagSpec(
        key="release_clauses",
        category="economy",
        type="bool",
        default=False,
        label="Clausole rescissorie",
        description=(
            "Ogni giocatore ha una clausola rescissoria che altri manager "
            "possono pagare per acquistarlo. Default = ammortamento_residuo × 0.8."
        ),
    ),
    FlagSpec(
        key="clause_default_factor",
        category="economy",
        type="float",
        default=0.8,
        min_value=0.5,
        max_value=1.0,
        label="Fattore default clausola",
        description="Moltiplicatore applicato all'ammortamento residuo per ottenere il default della clausola.",
    ),
    FlagSpec(
        key="rescission_penalty",
        category="economy",
        type="bool",
        default=False,
        label="Penale di rescissione",
        description=(
            "Quando un manager svincola un giocatore prima della scadenza, "
            "paga una penale proporzionale al residuo. Richiede amortization."
        ),
    ),
    FlagSpec(
        key="rescission_recovery_pct",
        category="economy",
        type="float",
        default=50.0,
        min_value=0.0,
        max_value=100.0,
        label="Recupero crediti su svincolo (%)",
        description="Percentuale di crediti recuperata quando il manager svincola un giocatore.",
    ),

    # --- TATTICA ---
    FlagSpec(
        key="no_schema_tactics",
        category="tactics",
        type="bool",
        default=False,
        label="Tattica no-schema",
        description=(
            "Permette di schierare una formazione senza vincoli di modulo "
            "predefinito, con sistema di penalità tattica configurabile."
        ),
    ),

    # --- SCOUTING ---
    FlagSpec(
        key="scouting_enabled",
        category="scouting",
        type="bool",
        default=False,
        label="Scouting attivo",
        description="Sistema di scoperta e sviluppo di giocatori giovani/emergenti.",
    ),
]


# ============================================================
# HELPER
# ============================================================

FLAGS_BY_KEY: Dict[str, FlagSpec] = {f.key: f for f in FLAGS}


def default_flag_values() -> Dict[str, Any]:
    """Restituisce tutti i flag con i loro valori di default conservativi."""
    return {f.key: f.default for f in FLAGS}


def validate_flag_value(key: str, value: Any) -> bool:
    """Valida che un valore sia accettabile per un flag specifico."""
    if key not in FLAGS_BY_KEY:
        return False
    spec = FLAGS_BY_KEY[key]
    if spec.type == "bool":
        return isinstance(value, bool)
    if spec.type == "int":
        if not isinstance(value, int) or isinstance(value, bool):
            return False
        if spec.min_value is not None and value < spec.min_value:
            return False
        if spec.max_value is not None and value > spec.max_value:
            return False
        return True
    if spec.type == "float":
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            return False
        if spec.min_value is not None and value < spec.min_value:
            return False
        if spec.max_value is not None and value > spec.max_value:
            return False
        return True
    if spec.type == "string":
        if not isinstance(value, str):
            return False
        if spec.allowed_values is not None:
            return value in spec.allowed_values
        return True
    return False


def flags_by_category(category: FlagCategory) -> list[FlagSpec]:
    """Ritorna tutti i flag di una categoria, nell'ordine di FLAGS."""
    return [f for f in FLAGS if f.category == category]
