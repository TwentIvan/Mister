"""
Federation — il regolamento sportivo + feature flags di una Lega.

CAMBIAMENTO ARCHITETTURALE RISPETTO ALLA V0:
La Federation ora include due cose: il calcolo (bonus/soglie/modificatori,
come prima) E i feature flags (contratti, mercati, economia, tattica,
scouting). Al momento della creazione di una Lega, i valori dei flag
vengono COPIATI dal TemplateProfile scelto. Da quel momento la Federation
è autonoma.

CONCETTO DI "snapshot" vs "live reference":
La Federation contiene una copia dei flag, NON un puntatore al template
da cui viene. Se il superadmin ritara "Esploratore" dopo che Marco ha
creato la sua lega, Marco resta sui suoi valori vecchi. È questa la
proprietà che ci garantisce stabilità delle leghe in corso.

TRACCIABILITÀ:
Il campo `template_id` registra solo da quale template è stata generata
la federation, per analytics. NON viene usato a runtime per leggere
valori del template.
"""

from __future__ import annotations
from datetime import datetime
from typing import Any, Dict, List, Literal, Optional
from pydantic import BaseModel, Field, field_validator

from app.models.flags import validate_flag_value, FLAGS_BY_KEY, default_flag_values


# ============================================================
# ENUMS
# ============================================================

Mode = Literal["classic", "mantra"]
VotoSource = Literal["gazzetta", "italia", "fantacalcio_it", "consensus"]


# ============================================================
# CALCOLO — BONUS / SOGLIE / MODIFICATORI (come prima)
# ============================================================

class BonusMalus(BaseModel):
    """Tabella bonus/malus per evento."""
    goal_att: float        = Field( 3.0, description="Gol attaccante")
    goal_mid: float        = Field( 3.5, description="Gol centrocampista")
    goal_def: float        = Field( 4.0, description="Gol difensore")
    goal_gk: float         = Field( 6.0, description="Gol portiere")
    assist: float          = Field( 1.0, description="Assist tradizionale")
    key_pass_chain: float  = Field( 0.5, description="Assist da assist (opzionale)")
    penalty_saved: float   = Field( 3.0, description="Rigore parato")
    clean_sheet_gk: float  = Field( 1.0, description="Imbattuto portiere")
    goal_conceded_gk: float= Field(-1.0, description="Gol subito portiere")
    penalty_scored: float  = Field( 3.0, description="Rigore segnato (cumulato col gol_*)")
    penalty_missed: float  = Field(-3.0, description="Rigore sbagliato")
    yellow: float          = Field(-0.5, description="Giallo")
    red: float             = Field(-1.0, description="Rosso diretto")
    own_goal: float        = Field(-2.0, description="Autogol")
    goal_conceded_def: float = Field(0.0, description="Malus difensore per gol subito (raro)")


class GoalThresholds(BaseModel):
    """Soglie punteggio squadra → fanta-gol."""
    base: float = Field(66.0, description="Punteggio minimo per il primo gol")
    step: float = Field( 6.0, description="Incremento per gol successivi")
    max_goals: int = Field(8, description="Tetto massimo gol/giornata")

    def threshold_for_goal(self, goal_number: int) -> float:
        return self.base + (goal_number - 1) * self.step

    def goals_from_score(self, total_score: float) -> int:
        if total_score < self.base:
            return 0
        return min(self.max_goals, int((total_score - self.base) // self.step) + 1)


class DefenseModifier(BaseModel):
    """Modificatore difesa: media voto centrali → bonus al totale."""
    enabled: bool = True
    use_full_defense: bool = False
    table: Dict[str, float] = Field(
        default_factory=lambda: {
            "<=5.0":   -1.0,
            "5.0-5.5": -0.5,
            "5.5-6.0":  0.0,
            "6.0-6.5":  1.0,
            "6.5-7.0":  3.0,
            "7.0-7.5":  5.0,
            ">7.5":     6.0,
        }
    )


class MidfieldModifier(BaseModel):
    """Modificatore centrocampo (analogo a difesa)."""
    enabled: bool = False
    table: Dict[str, float] = Field(
        default_factory=lambda: {
            "<=5.5":  -0.5,
            "5.5-6.0": 0.0,
            "6.0-6.5": 1.0,
            "6.5-7.0": 2.0,
            ">7.0":    3.0,
        }
    )


class HomeAdvantage(BaseModel):
    """
    Bonus al fanta-punteggio del padrone di casa, prima della conversione
    in gol via soglie. Settabile a livello di Competizione, ma il
    default qui è il "valore consigliato" che la Federation suggerisce.
    """
    enabled: bool = True
    bonus_points: float = Field(3.0, description="Crediti aggiunti al totale del padrone di casa")


class SubstitutionRules(BaseModel):
    """Sostituzioni automatiche per titolari senza voto."""
    auto_substitution: bool = True
    max_auto_subs: int = 3
    fallback_no_vote: Literal["sv_zero", "exclude", "average"] = "sv_zero"


# ============================================================
# FEDERATION
# ============================================================

class Federation(BaseModel):
    """
    Il regolamento sportivo + feature flags di una specifica Lega.

    NON è un "regolamento condiviso tra leghe" (quello è il TemplateProfile).
    Una Federation appartiene a UNA Lega specifica, ed è uno snapshot al
    momento della creazione, modificabile poi dall'admin della lega.
    """
    id: str = Field(..., description="Slug univoco")
    name: str
    description: str = ""

    # Origine (analytics, non usato a runtime)
    template_id: Optional[str] = Field(
        None,
        description="Slug del TemplateProfile da cui è stata generata. None se creata custom."
    )

    # === CALCOLO ===
    mode: Mode = "classic"
    voto_source: VotoSource = "consensus"
    bonus_malus: BonusMalus = Field(default_factory=BonusMalus)
    goal_thresholds: GoalThresholds = Field(default_factory=GoalThresholds)
    defense_modifier: DefenseModifier = Field(default_factory=DefenseModifier)
    midfield_modifier: MidfieldModifier = Field(default_factory=MidfieldModifier)
    home_advantage: HomeAdvantage = Field(default_factory=HomeAdvantage)
    substitutions: SubstitutionRules = Field(default_factory=SubstitutionRules)

    # === FEATURE FLAGS ===
    feature_flags: Dict[str, Any] = Field(
        default_factory=default_flag_values,
        description="Snapshot copiato dal TemplateProfile al momento della creazione."
    )

    # Metadati
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    @field_validator("id")
    @classmethod
    def id_must_be_slug(cls, v: str) -> str:
        if not v.replace("_", "").replace("-", "").isalnum():
            raise ValueError("id deve essere uno slug alfanumerico con _ o -")
        return v.lower()

    def flag(self, key: str) -> Any:
        """
        Accesso safe a un feature flag. Se non presente nello snapshot,
        ritorna il default conservativo da flags.py.
        """
        if key in self.feature_flags:
            return self.feature_flags[key]
        if key in FLAGS_BY_KEY:
            return FLAGS_BY_KEY[key].default
        raise KeyError(f"Flag '{key}' non riconosciuto")

    def supports(self, key: str) -> bool:
        """Shortcut per leggere flag boolean."""
        v = self.flag(key)
        if not isinstance(v, bool):
            raise TypeError(f"Flag '{key}' non è un boolean")
        return v
