"""
Template Profile — i preset di partenza per la creazione di una Lega.

Concettualmente questi sono i tre profili Classico / Esploratore / Manageriale,
ma il superadmin può ritarare i valori, aggiungere nuovi template, disattivare
quelli esistenti. Per questo motivo i template VIVONO NEL DATABASE come
righe di una tabella `template_profiles`, non come costanti Python.

Quando un admin crea una nuova Lega scegliendo un template:
  1. Il sistema carica i feature_flags del template dal DB
  2. Li COPIA dentro la nuova Federazione (snapshot)
  3. Da quel momento la lega è autonoma — modifiche al template non
     impattano leghe esistenti
"""

from __future__ import annotations
from datetime import datetime
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field, model_validator

from app.models.flags import validate_flag_value, FLAGS_BY_KEY


class MarketEventTemplate(BaseModel):
    """
    Configurazione abbreviata di un evento di mercato suggerito dal template.
    Al momento della creazione della Lega questi diventano veri MarketEvent.
    """
    name: str
    type: str             # auction | trade | release | free_agent
    mode: Optional[str] = None  # live | async | blind | token | open
    window_hint: str = Field(
        ...,
        description="Es. '18-23 agosto' o '30 gen - 2 feb' — l'admin lo riempie con date concrete."
    )
    description: str = ""


class CompetitionSuggestion(BaseModel):
    """Suggerimento di competizione che viene proposto all'admin in onboarding."""
    name: str
    type: str
    description: str = ""


class TemplateProfile(BaseModel):
    """
    Un template profilo. Rappresenta uno dei "preset di partenza" scegliibili
    in onboarding dall'admin di una nuova Lega.
    """
    id: str = Field(..., description="Slug univoco, es. 'classico'")
    name: str
    tagline: str
    description: str

    # Categoria di complessità per UI (1=base, 3=full)
    complexity_level: int = Field(..., ge=1, le=5)
    estimated_weekly_minutes: int = Field(
        ...,
        description="Tempo stimato di gestione settimanale per il manager"
    )
    icon: str = Field(
        "",
        description="Identificatore di icona per UI (es. 'ball-football' / 'compass' / 'briefcase')"
    )

    # I valori dei feature flag per questo template
    feature_flags: Dict[str, Any] = Field(default_factory=dict)

    # Eventi di mercato suggeriti all'admin in onboarding
    suggested_markets: List[MarketEventTemplate] = Field(default_factory=list)

    # Competizioni suggerite
    suggested_competitions: List[CompetitionSuggestion] = Field(default_factory=list)

    # Metadata di amministrazione
    author_user_id: Optional[str] = Field(
        None,
        description="None per template di sistema, user_id per template creati dal superadmin"
    )
    is_system: bool = Field(
        False,
        description="I template di sistema non possono essere cancellati, solo disattivati."
    )
    is_active: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    @model_validator(mode="after")
    def validate_flags(self):
        """Tutti i valori dei flag devono essere accettabili secondo flags.py."""
        for key, value in self.feature_flags.items():
            if key not in FLAGS_BY_KEY:
                raise ValueError(
                    f"Flag '{key}' non riconosciuto. Aggiungilo a app/models/flags.py "
                    "prima di usarlo in un template."
                )
            if not validate_flag_value(key, value):
                raise ValueError(
                    f"Valore '{value}' non valido per flag '{key}' "
                    f"(tipo atteso: {FLAGS_BY_KEY[key].type})"
                )
        return self

    def resolved_flags(self) -> Dict[str, Any]:
        """
        Restituisce tutti i flag, dove quelli non specificati esplicitamente
        nel template assumono il valore di default conservativo.
        """
        from app.models.flags import default_flag_values
        merged = default_flag_values()
        merged.update(self.feature_flags)
        return merged
