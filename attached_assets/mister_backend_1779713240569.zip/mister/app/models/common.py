"""
Team, Player, Match — modelli di supporto referenziati dai modelli di configurazione.
"""

from __future__ import annotations
from datetime import datetime
from typing import Dict, List, Literal, Optional
from pydantic import BaseModel, Field


# ============================================================
# PLAYER (Serie A real player, source: API-Football)
# ============================================================

PlayerRole = Literal["GK", "DEF", "MID", "ATT"]
MantraRole = Literal["Por", "Dc", "Dd", "Ds", "E", "M", "C", "T", "W", "A", "Pc"]


class Player(BaseModel):
    """Un giocatore reale di Serie A. Sorgente: API-Football."""
    id: int = Field(..., description="API-Football player_id")
    name: str
    full_name: str
    real_team: str = Field(..., description="Squadra Serie A di appartenenza")

    # Anagrafica
    birth_date: Optional[str] = None
    nationality: Optional[str] = None
    height_cm: Optional[int] = None
    weight_kg: Optional[int] = None
    foot: Optional[Literal["left", "right", "both"]] = None

    # Ruoli
    role_classic: PlayerRole
    roles_mantra: List[MantraRole] = Field(default_factory=list)

    # Status corrente
    injured: bool = False
    photo_url: Optional[str] = None


# ============================================================
# FANTA TEAM (squadra di un manager dentro una lega)
# ============================================================

class FantaTeam(BaseModel):
    """La squadra fantacalcio di un manager in una specifica lega."""
    id: str
    league_id: str
    manager_user_id: str

    # Identità
    name: str = Field(..., description="Nome della squadra (es. 'Real Acalappia')")
    name_auction: Optional[str] = Field(
        None,
        description="Nome usato all'asta per distinguere omonimi (es. 'Mario A' vs 'Mario B')"
    )
    logo_url: Optional[str] = None
    jersey_config: Optional[dict] = Field(
        None,
        description="JSON config maglia AI: colore primario, secondario, pattern, sponsor."
    )

    # Stato squadra
    credits_remaining: int
    roster: List[int] = Field(
        default_factory=list,
        description="Lista player_ids (Serie A IDs)"
    )

    # Storia
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ============================================================
# LINEUP (formazione per una giornata specifica)
# ============================================================

class Lineup(BaseModel):
    """Lo schieramento di una FantaTeam per una giornata specifica."""
    id: str
    fanta_team_id: str
    competition_id: str
    round: int = Field(..., description="Numero giornata, es. 30")

    module: str = Field(..., description="Es. '3-4-3'")
    starters: List[int] = Field(..., description="11 player_ids titolari, ordinati")
    bench: List[int] = Field(..., description="Player_ids panchina, in ordine di subentro")

    captain: int
    vice_captain: Optional[int] = None

    submitted_at: Optional[datetime] = None
    deadline: datetime


# ============================================================
# MATCH (partita fanta tra due squadre in una giornata)
# ============================================================

class FantaMatch(BaseModel):
    """
    Una partita fanta tra due squadre della lega in una specifica giornata.
    Generata dal calendario della Competizione.
    """
    id: str
    competition_id: str
    round: int
    home_team_id: str
    away_team_id: str

    # Risultato (popolato dopo il calcolo)
    home_score: Optional[float] = None  # fanta-punti totali
    away_score: Optional[float] = None
    home_goals: Optional[int] = None    # fanta-gol dopo soglie
    away_goals: Optional[int] = None

    # Output engine
    engine_events: List[dict] = Field(
        default_factory=list,
        description="Eventi del match engine (passes, tackles, shots, goals)."
    )
    narrative: Optional[str] = Field(
        None,
        description="Match report generato da Claude."
    )

    # Stato
    completed: bool = False
    calculated_at: Optional[datetime] = None
