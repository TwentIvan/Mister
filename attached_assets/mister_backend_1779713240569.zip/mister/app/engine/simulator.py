"""
Match engine — porting di match_engine_v2.py dentro la struttura applicativa.

Differenza chiave dal prototipo: questa versione accetta lineups e
performance data come parametri, non li ha hard-coded. Il fetcher
(app.data.api_football) si occupa di popolarli.
"""

from __future__ import annotations
import math
import random
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

from app.config import get_settings


@dataclass
class EnginePlayer:
    """Player input al match engine (sottoinsieme di app.models.Player)."""
    name: str
    pos: str               # GK, DEF, MID, ATT
    is_captain: bool = False


@dataclass
class EngineLineup:
    """Lineup input al match engine."""
    team_key: str          # 'home' o 'away'
    module: str
    players: List[EnginePlayer]

    def by_pos(self, pos: str) -> List[EnginePlayer]:
        return [p for p in self.players if p.pos == pos]

    @property
    def gk(self) -> EnginePlayer:
        return self.by_pos("GK")[0]


@dataclass
class EngineState:
    minute: float = 0.0
    possession: str = "home"
    carrier: Optional[EnginePlayer] = None
    zone: str = "mid"
    events: List[dict] = field(default_factory=list)
    score_home: int = 0
    score_away: int = 0


def player_form(p: EnginePlayer, perf: Dict[str, dict]) -> float:
    """
    Form di settimana: rating reale * boost capitano.
    Sostituisce la funzione hard-coded del prototipo.
    """
    d = perf.get(p.name, {"rating": 6.0})
    rating = float(d.get("rating", 6.0))
    boost = 1.25 if p.is_captain else 1.0
    return rating * boost


def simulate_match(
    home: EngineLineup,
    away: EngineLineup,
    perf: Dict[str, dict],
    seed: Optional[int] = None,
) -> dict:
    """
    Simula una partita tra due lineups con i dati di performance reali.

    Args:
      home, away: i due schieramenti (EngineLineup)
      perf:       dict {player_name: stats} prodotto da
                  APIFootballClient.get_giornata_player_stats(season, round)
      seed:       per riproducibilità

    Returns:
      {
        'events': [...],
        'score': {'home': int, 'away': int},
        'stats': {...summary...}
      }
    """
    s = get_settings()
    rng = random.Random(seed if seed is not None else s.engine_seed)

    state = EngineState()
    state.carrier = rng.choice(home.by_pos("MID"))

    while state.minute < 90.0:
        _tick(state, home, away, perf, rng)
        state.minute += rng.uniform(0.08, 0.20)

    return {
        "events": state.events,
        "score": {"home": state.score_home, "away": state.score_away},
        "stats": _summary(state.events),
    }


def _tick(state, home, away, perf, rng):
    atk = home if state.possession == "home" else away
    dfn = away if state.possession == "home" else home

    if state.carrier is None:
        state.carrier = rng.choice(atk.by_pos("MID"))

    c = state.carrier

    # Action probabilities
    if state.zone == "def":
        p_shoot, p_dribble, p_pass = 0.0, 0.08, 0.92
    elif state.zone == "mid":
        p_shoot, p_dribble, p_pass = 0.01, 0.12, 0.87
    else:
        p_shoot, p_dribble, p_pass = 0.12, 0.18, 0.70

    if c.pos == "ATT":
        p_shoot *= 1.5
    elif c.pos == "MID":
        p_shoot *= 0.6
    elif c.pos == "DEF":
        p_shoot = 0.0
        p_dribble *= 0.3

    total = p_shoot + p_dribble + p_pass
    p_shoot, p_dribble, p_pass = p_shoot / total, p_dribble / total, p_pass / total

    r = rng.random()
    if r < p_shoot:
        _do_shot(state, atk, dfn, perf, rng)
    elif r < p_shoot + p_dribble:
        _do_dribble(state, atk, dfn, perf, rng)
    else:
        _do_pass(state, atk, dfn, perf, rng)


def _do_pass(state, atk, dfn, perf, rng):
    c = state.carrier
    if state.zone == "def":
        forward = atk.by_pos("MID")
    elif state.zone == "mid":
        forward = atk.by_pos("ATT") + atk.by_pos("MID")
    else:
        forward = atk.by_pos("ATT")
    others = [p for p in atk.players if p.name != c.name]
    pool = [p for p in forward if p.name != c.name] if forward and rng.random() < 0.65 else others
    target = rng.choice(pool or others)

    new_zone = state.zone
    if target.pos == "ATT": new_zone = "att"
    elif target.pos == "MID" and state.zone == "def": new_zone = "mid"
    elif target.pos == "DEF": new_zone = "def"

    # Interception
    if new_zone == "att":
        intercept_pool = dfn.by_pos("DEF") + dfn.by_pos("MID")
    elif new_zone == "mid":
        intercept_pool = dfn.by_pos("MID") + dfn.by_pos("DEF")
    else:
        intercept_pool = dfn.by_pos("MID")

    if intercept_pool:
        defender = max(intercept_pool, key=lambda x: player_form(x, perf))
        p_int = 0.08 + max(0, (player_form(defender, perf) - player_form(c, perf)) * 0.02)
        if new_zone == "att":
            p_int *= 1.6
        if rng.random() < p_int:
            state.events.append({
                "minute": round(state.minute, 2),
                "type": "tackle",
                "team_winning": "away" if state.possession == "home" else "home",
                "from": c.name, "to": defender.name, "zone": new_zone,
            })
            state.possession = "away" if state.possession == "home" else "home"
            state.carrier = defender
            state.zone = {"def": "att", "mid": "mid", "att": "def"}[new_zone]
            return

    state.events.append({
        "minute": round(state.minute, 2),
        "type": "pass",
        "team": state.possession,
        "from": c.name, "to": target.name, "zone": new_zone,
    })
    state.carrier = target
    state.zone = new_zone


def _do_dribble(state, atk, dfn, perf, rng):
    c = state.carrier
    d = perf.get(c.name, {})
    base = min(0.85, 0.55 + d.get("dribbles_succ", 0) * 0.03)
    if rng.random() < base:
        zones = ["def", "mid", "att"]
        idx = zones.index(state.zone)
        new_zone = zones[min(2, idx + 1)]
        state.events.append({
            "minute": round(state.minute, 2),
            "type": "dribble",
            "team": state.possession,
            "player": c.name, "zone": new_zone,
        })
        state.zone = new_zone
    else:
        defender = rng.choice(dfn.by_pos("DEF") + dfn.by_pos("MID"))
        state.events.append({
            "minute": round(state.minute, 2),
            "type": "tackle",
            "team_winning": "away" if state.possession == "home" else "home",
            "from": c.name, "to": defender.name, "zone": state.zone,
        })
        state.possession = "away" if state.possession == "home" else "home"
        state.carrier = defender
        state.zone = {"def": "att", "mid": "mid", "att": "def"}[state.zone]


def _do_shot(state, atk, dfn, perf, rng):
    c = state.carrier
    keeper = dfn.gk
    nearest_def = max(dfn.by_pos("DEF"), key=lambda x: player_form(x, perf))

    atk_q = player_form(c, perf) + perf.get(c.name, {}).get("shots_on_target", 0) * 0.3
    def_q = (player_form(nearest_def, perf) + player_form(keeper, perf)) * 0.62
    noise = rng.uniform(-4, 4)
    raw = atk_q - def_q + noise

    if raw > 4.5:
        outcome = "goal"
    elif raw > 1.5:
        outcome = "save"
    else:
        outcome = "shot_off"

    evt = {
        "minute": round(state.minute, 2),
        "type": outcome,
        "team": state.possession,
        "attacker": c.name,
    }
    if outcome in ("goal", "save"):
        evt["keeper"] = keeper.name
    state.events.append(evt)

    if outcome == "goal":
        if state.possession == "home":
            state.score_home += 1
        else:
            state.score_away += 1

    state.possession = "away" if state.possession == "home" else "home"
    new_atk = atk if state.possession == "home" else dfn  # swap
    state.carrier = new_atk.gk if outcome != "goal" else rng.choice(new_atk.by_pos("MID"))
    state.zone = "def" if outcome != "goal" else "mid"


def _summary(events: List[dict]) -> dict:
    return {
        "passes": sum(1 for e in events if e["type"] == "pass"),
        "dribbles": sum(1 for e in events if e["type"] == "dribble"),
        "tackles": sum(1 for e in events if e["type"] == "tackle"),
        "shots": sum(1 for e in events if e["type"] in ("goal", "save", "shot_off")),
        "goals_home": sum(1 for e in events if e["type"] == "goal" and e["team"] == "home"),
        "goals_away": sum(1 for e in events if e["type"] == "goal" and e["team"] == "away"),
    }
