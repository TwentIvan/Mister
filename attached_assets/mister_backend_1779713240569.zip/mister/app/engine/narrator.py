"""
Match narrator — chiama Claude Sonnet per trasformare la lista di
eventi del match engine in un racconto manageriale.

In produzione vogliamo usare Sonnet 4.6 in batch mode per ridurre i
costi del 50%. Per il lanciamento singolo (test, debug, on-demand)
usiamo direttamente l'endpoint sync.

PROMPT ENGINEERING:
Il system prompt è la chiave della qualità del narrato. Va iterato.
Quello che trovi qui è una v1 — buon punto di partenza, da raffinare
con esempi few-shot e tuning.
"""

from __future__ import annotations
import json
from typing import Optional

from anthropic import AsyncAnthropic
from app.config import get_settings


SYSTEM_PROMPT = """Sei un narratore di partite di fantacalcio per Mister, un'app
manageriale italiana. Il tuo compito è trasformare una lista di eventi tecnici
(passaggi, tiri, parate, gol, contrasti) in un racconto scorrevole e appassionante
della partita, dal punto di vista neutro, in italiano calcistico naturale.

REGOLE DI STILE:
- Tono: serio ma vivo, come una cronaca scritta della domenica sera. Niente
  sensazionalismo, niente esclamazioni gratuite. Il dramma viene dai fatti.
- Lingua: italiano fluente, registro sportivo. Usa termini propri ("girata di
  testa", "tiro a giro", "rovesciata", "filtrante", "scaricarla in area",
  "imbucata", "verticalizzazione", "doppio passo", "uscire in scivolata").
- Tempo verbale: passato remoto e imperfetto, come la cronaca giornalistica
  italiana (es. "segnò", "stava controllando", "trovò il varco").
- Lunghezza: 250-400 parole totali. Apertura, snodo, finale.
- Struttura: 3-5 paragrafi corti. Apertura sul ritmo iniziale, snodo sul
  momento di svolta, finale con considerazioni essenziali.
- Capitano: se il capitano fa qualcosa, sottolinealo (la fascia ha un peso
  narrativo).
- Non inventare eventi che non sono nella lista. Non aggiungere assist,
  cartellini o sostituzioni non presenti nei dati.

DENTRO IL RACCONTO USA SEMPRE I NOMI REALI dei giocatori e dei manager.
Esempio: "Al 23° Lautaro, in serata di grazia, trovò il varco tra Buongiorno
e Di Lorenzo e infilò il piattone all'angolo basso. 0-1, Marco avanti."

NON USARE:
- Asterischi, grassetti, elenchi puntati nel testo (è prosa, non un report).
- Anglicismi gratuiti (no "playmaker", sì "regista"; no "striker", sì
  "centravanti" o "punta").
- Tag HTML, markdown, emoji.

CHIUDI con un breve paragrafo "Considerazioni del Mister" (1-3 frasi) che
sintetizza la lezione tattica della partita per il manager che leggerà:
- Chi ha fatto la differenza
- Chi è stato deludente
- Una nota strategica per la prossima giornata
"""


def _user_prompt(
    home_manager: str,
    away_manager: str,
    home_module: str,
    away_module: str,
    score_home: int,
    score_away: int,
    home_captain: str,
    away_captain: str,
    key_events: list[dict],
) -> str:
    """
    Costruisce il prompt utente con i dati strutturati della partita.
    Passiamo solo gli eventi significativi (gol, parate, tiri, contrasti
    importanti). I 400+ passaggi non servono al narratore.
    """
    return f"""Genera la cronaca della seguente partita fanta:

Squadra di casa: {home_manager} ({home_module}), capitano: {home_captain}
Squadra fuori casa: {away_manager} ({away_module}), capitano: {away_captain}
Risultato finale: {home_manager} {score_home} — {score_away} {away_manager}

Eventi chiave in ordine cronologico:
{json.dumps(key_events, indent=2, ensure_ascii=False)}

Restituisci solo il testo della cronaca, in italiano, seguendo le regole
indicate nel system prompt.
"""


async def narrate_match(
    home_manager: str,
    away_manager: str,
    home_module: str,
    away_module: str,
    home_captain: str,
    away_captain: str,
    events: list[dict],
    score: dict,
    model: Optional[str] = None,
) -> str:
    """
    Chiamata principale del narratore. Restituisce la stringa della cronaca.
    """
    settings = get_settings()
    if not settings.anthropic_api_key:
        raise RuntimeError("ANTHROPIC_API_KEY mancante. Imposta nei Secrets di Replit.")

    # Filtra solo eventi salienti (riduce token e migliora focus)
    key_events = [e for e in events if e["type"] in ("goal", "save", "shot_off", "tackle")]
    # Limitiamo ai 25 più importanti per non saturare il prompt
    key_events = key_events[:25]

    client = AsyncAnthropic(api_key=settings.anthropic_api_key)
    response = await client.messages.create(
        model=model or settings.claude_model,
        max_tokens=1500,
        system=SYSTEM_PROMPT,
        messages=[{
            "role": "user",
            "content": _user_prompt(
                home_manager, away_manager,
                home_module, away_module,
                score["home"], score["away"],
                home_captain, away_captain,
                key_events,
            ),
        }],
    )
    return response.content[0].text


# ============================================================
# BATCH MODE — per giornata intera (8-15 partite contemporaneamente)
# ============================================================

async def narrate_giornata_batch(matches: list[dict]) -> list[str]:
    """
    TODO: usare l'API batch di Anthropic per generare il narrato di
    tutta la giornata in una singola operazione async. Sconto 50%.

    Spec: https://docs.claude.com/en/docs/build-with-claude/batch-processing
    """
    raise NotImplementedError(
        "Batch narrative generation: da implementare nella settimana 2-3."
    )
