"""
API pubblica per i template profili.

Read-only, accessibile a chiunque crei una lega. Mostra solo i template
`is_active=True`. Il superadmin usa /api/superadmin/templates per il CRUD.
"""

from __future__ import annotations
from typing import Any, Dict
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlmodel import Session, select

from app.db.schema import TemplateProfileDB


router = APIRouter(prefix="/api/templates", tags=["templates"])


class PublicTemplateSummary(BaseModel):
    """Versione ridotta per il selettore di onboarding."""
    id: str
    name: str
    tagline: str
    description: str
    complexity_level: int
    estimated_weekly_minutes: int
    icon: str


class PublicTemplateDetail(PublicTemplateSummary):
    """Versione dettagliata per il drawer 'Vedi dettagli' del template."""
    feature_flags: Dict[str, Any]
    suggested_markets: list[dict]
    suggested_competitions: list[dict]


def get_session():
    from app.main import engine
    with Session(engine) as session:
        yield session


@router.get("", response_model=list[PublicTemplateSummary])
def list_active_templates(session: Session = Depends(get_session)):
    """Lista i template attivi disponibili in onboarding."""
    stmt = select(TemplateProfileDB).where(TemplateProfileDB.is_active == True).order_by(TemplateProfileDB.complexity_level)
    rows = session.exec(stmt).all()
    return [
        PublicTemplateSummary(
            id=r.id,
            name=r.name,
            tagline=r.tagline,
            description=r.description,
            complexity_level=r.complexity_level,
            estimated_weekly_minutes=r.estimated_weekly_minutes,
            icon=r.icon,
        )
        for r in rows
    ]


@router.get("/{template_id}", response_model=PublicTemplateDetail)
def get_template_detail(template_id: str, session: Session = Depends(get_session)):
    from fastapi import HTTPException
    row = session.get(TemplateProfileDB, template_id)
    if not row or not row.is_active:
        raise HTTPException(404, "Template non trovato")
    return PublicTemplateDetail(
        id=row.id,
        name=row.name,
        tagline=row.tagline,
        description=row.description,
        complexity_level=row.complexity_level,
        estimated_weekly_minutes=row.estimated_weekly_minutes,
        icon=row.icon,
        feature_flags=row.feature_flags_json,
        suggested_markets=row.suggested_markets_json.get("items", []),
        suggested_competitions=row.suggested_competitions_json.get("items", []),
    )
