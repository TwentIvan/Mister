"""
Superadmin API — gestione dei template profili.

L'autenticazione e l'autorizzazione sono stub-ate in `require_superadmin`:
per ora si basa su un header `X-Superadmin-Key` che viene letto dai Secrets
di Replit. Quando aggiungeremo auth vera con utenti/sessioni, sostituiremo
questo middleware col controllo del flag `is_superadmin` sull'utente loggato.

Endpoint:
  GET    /api/superadmin/flags                       → catalogo dei flag disponibili
  GET    /api/superadmin/templates                   → lista template (inclusi disattivi)
  GET    /api/superadmin/templates/{id}              → dettaglio
  POST   /api/superadmin/templates                   → crea nuovo template custom
  PUT    /api/superadmin/templates/{id}              → modifica esistente
  DELETE /api/superadmin/templates/{id}              → cancella (solo non-system)
  POST   /api/superadmin/templates/{id}/deactivate   → disattiva
  POST   /api/superadmin/templates/{id}/activate     → riattiva
  POST   /api/superadmin/templates/reset-system      → ripristina i tre di sistema ai valori del file
"""

from __future__ import annotations
import os
from datetime import datetime
from typing import Any, Dict, List, Optional
from fastapi import APIRouter, Depends, Header, HTTPException, status
from pydantic import BaseModel, Field
from sqlmodel import Session, select

from app.config import get_settings
from app.db.schema import TemplateProfileDB
from app.db.seed import seed_system_templates
from app.models.flags import FLAGS, FLAGS_BY_KEY, validate_flag_value


router = APIRouter(prefix="/api/superadmin", tags=["superadmin"])


# ============================================================
# AUTH STUB
# ============================================================

def require_superadmin(
    x_superadmin_key: Optional[str] = Header(None, alias="X-Superadmin-Key"),
) -> None:
    """
    Stub di autorizzazione. Confronta l'header con un Secret di Replit
    chiamato SUPERADMIN_KEY. Quando avremo auth vera, sostituiremo con
    controllo del flag is_superadmin sull'utente di sessione.
    """
    expected = os.environ.get("SUPERADMIN_KEY", "")
    if not expected:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="SUPERADMIN_KEY non configurato nei Secrets di Replit",
        )
    if x_superadmin_key != expected:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Accesso superadmin richiesto",
        )


# ============================================================
# DB SESSION DEPENDENCY
# ============================================================

def get_session():
    """Dependency che apre/chiude una session SQLModel."""
    from app.main import engine  # import lazy per evitare circolarità
    with Session(engine) as session:
        yield session


# ============================================================
# REQUEST/RESPONSE MODELS
# ============================================================

class FlagSpecResponse(BaseModel):
    key: str
    category: str
    type: str
    default: Any
    label: str
    description: str
    min_value: float | None = None
    max_value: float | None = None
    allowed_values: list[str] | None = None


class TemplateResponse(BaseModel):
    id: str
    name: str
    tagline: str
    description: str
    complexity_level: int
    estimated_weekly_minutes: int
    icon: str
    feature_flags: Dict[str, Any]
    suggested_markets: list[dict]
    suggested_competitions: list[dict]
    is_system: bool
    is_active: bool
    created_at: datetime
    updated_at: datetime


class TemplateCreateRequest(BaseModel):
    id: str = Field(..., min_length=2, max_length=50, pattern=r"^[a-z][a-z0-9_]*$")
    name: str
    tagline: str
    description: str
    complexity_level: int = Field(..., ge=1, le=5)
    estimated_weekly_minutes: int = Field(..., ge=5, le=180)
    icon: str = ""
    feature_flags: Dict[str, Any]
    suggested_markets: list[dict] = Field(default_factory=list)
    suggested_competitions: list[dict] = Field(default_factory=list)


class TemplateUpdateRequest(BaseModel):
    name: Optional[str] = None
    tagline: Optional[str] = None
    description: Optional[str] = None
    complexity_level: Optional[int] = None
    estimated_weekly_minutes: Optional[int] = None
    icon: Optional[str] = None
    feature_flags: Optional[Dict[str, Any]] = None
    suggested_markets: Optional[list[dict]] = None
    suggested_competitions: Optional[list[dict]] = None
    is_active: Optional[bool] = None


# ============================================================
# HELPER
# ============================================================

def _validate_flags_dict(flags: Dict[str, Any]) -> None:
    """Solleva HTTPException se uno qualunque dei flag non è valido."""
    for k, v in flags.items():
        if k not in FLAGS_BY_KEY:
            raise HTTPException(
                status_code=400,
                detail=f"Flag '{k}' non riconosciuto. Vedi GET /api/superadmin/flags per il catalogo.",
            )
        if not validate_flag_value(k, v):
            raise HTTPException(
                status_code=400,
                detail=f"Valore '{v}' non valido per flag '{k}' (tipo atteso: {FLAGS_BY_KEY[k].type})",
            )


def _to_response(row: TemplateProfileDB) -> TemplateResponse:
    return TemplateResponse(
        id=row.id,
        name=row.name,
        tagline=row.tagline,
        description=row.description,
        complexity_level=row.complexity_level,
        estimated_weekly_minutes=row.estimated_weekly_minutes,
        icon=row.icon,
        feature_flags=row.feature_flags_json,
        suggested_markets=row.suggested_markets_json.get("items", []),
        suggested_competitions=row.suggested_competitions_json.get("items", []),
        is_system=row.is_system,
        is_active=row.is_active,
        created_at=row.created_at,
        updated_at=row.updated_at,
    )


# ============================================================
# FLAG CATALOG
# ============================================================

@router.get("/flags", response_model=list[FlagSpecResponse], dependencies=[Depends(require_superadmin)])
def list_flags():
    """Lista tutti i feature flag conosciuti dal sistema."""
    return [
        FlagSpecResponse(
            key=f.key,
            category=f.category,
            type=f.type,
            default=f.default,
            label=f.label,
            description=f.description,
            min_value=f.min_value,
            max_value=f.max_value,
            allowed_values=f.allowed_values,
        )
        for f in FLAGS
    ]


# ============================================================
# TEMPLATE CRUD
# ============================================================

@router.get("/templates", response_model=list[TemplateResponse], dependencies=[Depends(require_superadmin)])
def list_templates(include_inactive: bool = True, session: Session = Depends(get_session)):
    """Lista tutti i template (di sistema e custom). Default include anche i disattivi."""
    stmt = select(TemplateProfileDB)
    if not include_inactive:
        stmt = stmt.where(TemplateProfileDB.is_active == True)
    rows = session.exec(stmt).all()
    return [_to_response(r) for r in rows]


@router.get("/templates/{template_id}", response_model=TemplateResponse, dependencies=[Depends(require_superadmin)])
def get_template(template_id: str, session: Session = Depends(get_session)):
    row = session.get(TemplateProfileDB, template_id)
    if not row:
        raise HTTPException(404, "Template non trovato")
    return _to_response(row)


@router.post("/templates", response_model=TemplateResponse, status_code=201, dependencies=[Depends(require_superadmin)])
def create_template(payload: TemplateCreateRequest, session: Session = Depends(get_session)):
    if session.get(TemplateProfileDB, payload.id):
        raise HTTPException(409, f"Template '{payload.id}' esiste già")

    _validate_flags_dict(payload.feature_flags)

    row = TemplateProfileDB(
        id=payload.id,
        name=payload.name,
        tagline=payload.tagline,
        description=payload.description,
        complexity_level=payload.complexity_level,
        estimated_weekly_minutes=payload.estimated_weekly_minutes,
        icon=payload.icon,
        feature_flags_json=payload.feature_flags,
        suggested_markets_json={"items": payload.suggested_markets},
        suggested_competitions_json={"items": payload.suggested_competitions},
        is_system=False,  # i template creati da endpoint non sono mai di sistema
        is_active=True,
    )
    session.add(row)
    session.commit()
    session.refresh(row)
    return _to_response(row)


@router.put("/templates/{template_id}", response_model=TemplateResponse, dependencies=[Depends(require_superadmin)])
def update_template(
    template_id: str,
    payload: TemplateUpdateRequest,
    session: Session = Depends(get_session),
):
    row = session.get(TemplateProfileDB, template_id)
    if not row:
        raise HTTPException(404, "Template non trovato")

    if payload.feature_flags is not None:
        _validate_flags_dict(payload.feature_flags)

    data = payload.model_dump(exclude_unset=True)
    if "suggested_markets" in data:
        data["suggested_markets_json"] = {"items": data.pop("suggested_markets")}
    if "suggested_competitions" in data:
        data["suggested_competitions_json"] = {"items": data.pop("suggested_competitions")}
    if "feature_flags" in data:
        data["feature_flags_json"] = data.pop("feature_flags")

    for k, v in data.items():
        setattr(row, k, v)
    row.updated_at = datetime.utcnow()
    session.add(row)
    session.commit()
    session.refresh(row)
    return _to_response(row)


@router.delete("/templates/{template_id}", status_code=204, dependencies=[Depends(require_superadmin)])
def delete_template(template_id: str, session: Session = Depends(get_session)):
    row = session.get(TemplateProfileDB, template_id)
    if not row:
        raise HTTPException(404, "Template non trovato")
    if row.is_system:
        raise HTTPException(
            400,
            "I template di sistema non possono essere cancellati. "
            "Usa /deactivate per nasconderli."
        )
    session.delete(row)
    session.commit()


@router.post("/templates/{template_id}/deactivate", response_model=TemplateResponse, dependencies=[Depends(require_superadmin)])
def deactivate_template(template_id: str, session: Session = Depends(get_session)):
    row = session.get(TemplateProfileDB, template_id)
    if not row:
        raise HTTPException(404, "Template non trovato")
    row.is_active = False
    row.updated_at = datetime.utcnow()
    session.add(row)
    session.commit()
    session.refresh(row)
    return _to_response(row)


@router.post("/templates/{template_id}/activate", response_model=TemplateResponse, dependencies=[Depends(require_superadmin)])
def activate_template(template_id: str, session: Session = Depends(get_session)):
    row = session.get(TemplateProfileDB, template_id)
    if not row:
        raise HTTPException(404, "Template non trovato")
    row.is_active = True
    row.updated_at = datetime.utcnow()
    session.add(row)
    session.commit()
    session.refresh(row)
    return _to_response(row)


@router.post("/templates/reset-system", dependencies=[Depends(require_superadmin)])
def reset_system_templates(session: Session = Depends(get_session)):
    """
    Ripristina i tre template di sistema ai valori di app/presets/templates.py.
    Utile dopo un deploy che ha aggiornato i preset, se vuoi propagare gli
    aggiornamenti ai template esistenti. NON tocca i template custom.
    """
    seed_system_templates(session, force_overwrite=True)
    return {"status": "ok", "message": "Template di sistema ripristinati ai valori del file"}
