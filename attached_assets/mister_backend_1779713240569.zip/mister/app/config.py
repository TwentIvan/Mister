"""
App configuration. Carica i settings da env vars con validazione typed.

In Replit le variabili sensibili (API key) vanno messe in Secrets dal
pannello laterale "Tools → Secrets". Non vanno mai committate.
"""

from functools import lru_cache
from typing import Literal
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Configurazione applicativa, popolata da env / Replit Secrets."""

    # --- Identità app ---
    app_name: str = "Mister"
    app_env: Literal["dev", "staging", "production"] = "dev"

    # --- API-Football ---
    api_football_key: str = ""
    api_football_base_url: str = "https://v3.football.api-sports.io"
    api_football_serie_a_league_id: int = 135

    # --- Anthropic / Claude (narrative gen) ---
    anthropic_api_key: str = ""
    claude_model: str = "claude-sonnet-4-6"
    claude_model_fallback: str = "claude-haiku-4-5"

    # --- Database ---
    # Replit: sqlite va benissimo per partire. In production: Postgres.
    database_url: str = "sqlite:///./mister.db"

    # --- Cache TTL (giorni) per dati API-Football ---
    cache_players_ttl_days: int = 7
    cache_fixtures_ttl_days: int = 1
    cache_voti_ttl_days: int = 1825  # i voti storici non cambiano mai (5 anni)

    # --- Engine ---
    engine_seed: int | None = None
    engine_randomness_pct: float = 0.18

    # --- Limiti soft (anti-abuse) ---
    max_leagues_per_user: int = 5
    max_managers_per_league: int = 20

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


@lru_cache
def get_settings() -> Settings:
    """
    Singleton dei settings. Usalo via dependency injection in FastAPI:
        from app.config import get_settings
        settings = Depends(get_settings)
    """
    return Settings()
