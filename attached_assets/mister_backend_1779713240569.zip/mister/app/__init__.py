"""Mister backend. The fantacalcio manageriale."""

__version__ = "0.1.0"
