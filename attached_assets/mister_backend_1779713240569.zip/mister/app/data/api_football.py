"""
API-Football client — wrapper tipato sugli endpoint che servono al match engine.

Endpoint usati nella v1:
  GET /leagues          - verifica coverage di Serie A per la stagione
  GET /teams            - tutte le squadre Serie A
  GET /players          - anagrafica giocatori
  GET /injuries         - infortuni correnti
  GET /fixtures         - calendario partite
  GET /fixtures/players - statistiche per giocatore per partita (★ chiave per il match engine)

LIMITI PIANO FREE:
  - 100 richieste/giorno
  - solo stagioni 2022-2024

LIMITI PIANO PRO ($19/mese):
  - 7500 richieste/giorno
  - stagione corrente inclusa
"""

from __future__ import annotations
import httpx
from datetime import datetime, timedelta
from typing import Any, Optional
from app.config import get_settings


class APIFootballError(Exception):
    """Errore generico API-Football."""


class APIFootballClient:
    """
    Client async per API-Football v3.

    Esempio uso:
        async with APIFootballClient() as client:
            coverage = await client.get_league(league_id=135, season=2024)
            fixtures = await client.get_fixtures(league=135, season=2024)
            stats = await client.get_fixture_players(fixture_id=12345)
    """

    def __init__(self, api_key: Optional[str] = None):
        s = get_settings()
        self.api_key = api_key or s.api_football_key
        self.base_url = s.api_football_base_url
        if not self.api_key:
            raise APIFootballError(
                "API-Football key mancante. Imposta API_FOOTBALL_KEY in .env "
                "o nei Secrets di Replit."
            )
        self._client: Optional[httpx.AsyncClient] = None

    async def __aenter__(self):
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={"x-apisports-key": self.api_key},
            timeout=30.0,
        )
        return self

    async def __aexit__(self, *_):
        if self._client:
            await self._client.aclose()

    async def _get(self, path: str, params: dict | None = None) -> dict[str, Any]:
        assert self._client, "Use 'async with' to open client"
        r = await self._client.get(path, params=params or {})
        r.raise_for_status()
        data = r.json()
        if data.get("errors"):
            errs = data["errors"]
            if isinstance(errs, dict) and errs:
                raise APIFootballError(f"API errors: {errs}")
        return data

    # ============================================================
    # LEAGUES & COVERAGE
    # ============================================================

    async def get_league(self, league_id: int, season: int) -> dict:
        """
        Restituisce dettagli e coverage di una lega per una stagione.
        Esempio: get_league(135, 2024) → Serie A 2024-25 con i flag di coverage.
        """
        data = await self._get("/leagues", {"id": league_id, "season": season})
        if not data["response"]:
            raise APIFootballError(f"Lega {league_id} stagione {season} non trovata")
        return data["response"][0]

    async def verify_serie_a_coverage(self, season: int) -> dict[str, bool]:
        """
        Verifica che la copertura di Serie A per la stagione abbia i flag
        che ci servono. Restituisce dict con i flag rilevanti.
        """
        league = await self.get_league(135, season)
        cov = league["seasons"][0]["coverage"]
        return {
            "events": cov["fixtures"]["events"],
            "lineups": cov["fixtures"]["lineups"],
            "statistics_fixtures": cov["fixtures"]["statistics_fixtures"],
            "statistics_players": cov["fixtures"]["statistics_players"],
            "players": cov["players"],
            "injuries": cov["injuries"],
        }

    # ============================================================
    # TEAMS & PLAYERS
    # ============================================================

    async def get_teams(self, season: int) -> list[dict]:
        """Tutte le 20 squadre Serie A della stagione."""
        data = await self._get("/teams", {"league": 135, "season": season})
        return data["response"]

    async def get_players(self, team_id: int, season: int) -> list[dict]:
        """
        Tutti i giocatori di una squadra in una stagione, con anagrafica
        e statistiche stagionali aggregate.

        ATTENZIONE: l'endpoint è paginato. Pagina 1-2 di solito coprono
        tutta una squadra.
        """
        all_players = []
        page = 1
        while True:
            data = await self._get("/players", {
                "team": team_id, "season": season, "page": page
            })
            all_players.extend(data["response"])
            if page >= data["paging"]["total"]:
                break
            page += 1
        return all_players

    async def get_injuries(self, season: int) -> list[dict]:
        """Infortuni attivi in Serie A. Aggiornato ogni 2h da API-Football."""
        data = await self._get("/injuries", {"league": 135, "season": season})
        return data["response"]

    # ============================================================
    # FIXTURES & PERFORMANCE
    # ============================================================

    async def get_fixtures(self, season: int, round_name: Optional[str] = None) -> list[dict]:
        """
        Calendario partite di Serie A.
        Se round_name è specificato (es. "Regular Season - 30"), filtra
        per quella giornata.
        """
        params: dict = {"league": 135, "season": season}
        if round_name:
            params["round"] = round_name
        data = await self._get("/fixtures", params)
        return data["response"]

    async def get_fixture_players(self, fixture_id: int) -> list[dict]:
        """
        ★ ENDPOINT CRITICO ★

        Statistiche per giocatore per una specifica partita. Output:
        per ogni squadra, lista di giocatori con stats granulari
        (rating, shots, passes, tackles, duels, dribbles, fouls, ecc.).

        Questo è il dato di input principale del match engine: la
        "performance di settimana" per ogni giocatore.
        """
        data = await self._get("/fixtures/players", {"fixture": fixture_id})
        return data["response"]

    async def get_giornata_player_stats(
        self, season: int, round_number: int
    ) -> dict[str, dict]:
        """
        High-level helper. Data una giornata di Serie A (es. round 30),
        restituisce un dict {player_name: stats} con i dati di tutti i
        giocatori che hanno giocato in quella giornata.

        Internamente: get_fixtures (filtrato per round) + get_fixture_players
        per ognuna delle 10 partite. Quindi 11 chiamate API totali per
        coprire una giornata completa.
        """
        round_name = f"Regular Season - {round_number}"
        fixtures = await self.get_fixtures(season, round_name=round_name)
        all_stats: dict[str, dict] = {}
        for fixture in fixtures:
            fid = fixture["fixture"]["id"]
            teams_data = await self.get_fixture_players(fid)
            for team_data in teams_data:
                for p in team_data["players"]:
                    name = p["player"]["name"]
                    raw = p["statistics"][0] if p["statistics"] else {}
                    all_stats[name] = {
                        "rating": float(raw.get("games", {}).get("rating") or 6.0),
                        "minutes": raw.get("games", {}).get("minutes") or 0,
                        "position": raw.get("games", {}).get("position"),
                        # Shots
                        "shots": (raw.get("shots", {}).get("total") or 0),
                        "shots_on_target": (raw.get("shots", {}).get("on") or 0),
                        # Goals & assists
                        "goals": (raw.get("goals", {}).get("total") or 0),
                        "assists": (raw.get("goals", {}).get("assists") or 0),
                        "saves": (raw.get("goals", {}).get("saves") or 0),
                        "goals_conceded": (raw.get("goals", {}).get("conceded") or 0),
                        # Passes
                        "passes": (raw.get("passes", {}).get("total") or 0),
                        "passes_acc": (raw.get("passes", {}).get("accuracy") or 0),
                        "key_passes": (raw.get("passes", {}).get("key") or 0),
                        # Duels & defense
                        "tackles": (raw.get("tackles", {}).get("total") or 0),
                        "interceptions": (raw.get("tackles", {}).get("interceptions") or 0),
                        "blocks": (raw.get("tackles", {}).get("blocks") or 0),
                        "duels_won": (raw.get("duels", {}).get("won") or 0),
                        "duels_total": (raw.get("duels", {}).get("total") or 0),
                        # Dribbles
                        "dribbles_succ": (raw.get("dribbles", {}).get("success") or 0),
                        "dribbles_attempts": (raw.get("dribbles", {}).get("attempts") or 0),
                        # Cards & fouls
                        "yellow": (raw.get("cards", {}).get("yellow") or 0),
                        "red": (raw.get("cards", {}).get("red") or 0),
                        "fouls_committed": (raw.get("fouls", {}).get("committed") or 0),
                        # Aerials (derivato)
                    }
        return all_stats
