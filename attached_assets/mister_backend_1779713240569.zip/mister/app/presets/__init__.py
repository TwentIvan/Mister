"""
Preset di prodotto: i template profili predefiniti + le factory functions
per creare entità di dominio.
"""

from app.presets.templates import (
    CLASSICO,
    ESPLORATORE,
    MANAGERIALE,
    SYSTEM_TEMPLATES,
    DEFAULT_TEMPLATE_ID,
    get_system_template,
)

from app.presets.factories import (
    make_federation_from_template,
    make_market_event_from_suggestion,
    make_campionato,
    make_coppa,
    make_battle_royale,
    make_sprint_race,
    make_formula_uno,
    make_punteggio_assoluto,
)

__all__ = [
    # template seeds
    "CLASSICO", "ESPLORATORE", "MANAGERIALE",
    "SYSTEM_TEMPLATES",
    "DEFAULT_TEMPLATE_ID",
    "get_system_template",
    # factories
    "make_federation_from_template",
    "make_market_event_from_suggestion",
    "make_campionato",
    "make_coppa",
    "make_battle_royale",
    "make_sprint_race",
    "make_formula_uno",
    "make_punteggio_assoluto",
]
