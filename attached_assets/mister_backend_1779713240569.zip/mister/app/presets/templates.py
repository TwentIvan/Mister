"""
Seed dei tre template profili predefiniti del prodotto.

Questi sono i Classico / Esploratore / Manageriale che l'admin vede in
onboarding quando crea una nuova lega. Vengono caricati nel DB all'avvio
dell'applicazione (vedi app/main.py `seed_default_templates`).

Il superadmin può:
  • Modificare i valori dei flag in qualsiasi template
  • Modificare suggested_markets e suggested_competitions
  • Disattivare un template (is_active = False)
  • Aggiungere nuovi template oltre questi tre
  • NON può cancellare i template di sistema (is_system=True)
"""

from app.models.template import (
    TemplateProfile,
    MarketEventTemplate,
    CompetitionSuggestion,
)


# ============================================================
# 1. CLASSICO
# ============================================================

CLASSICO = TemplateProfile(
    id="classico",
    name="Classico",
    tagline="Per chi ama il fantacalcio di sempre",
    description=(
        "L'esperienza fantacalcio tradizionale: asta a inizio stagione, "
        "formazioni settimanali, classifica. Niente contratti pluriennali, "
        "niente clausole, niente trattative tra manager. Ogni stagione "
        "riparte da zero."
    ),
    complexity_level=1,
    estimated_weekly_minutes=10,
    icon="ball-football",
    feature_flags={
        # Contracts
        "multi_season_contracts": False,
        "max_contract_length": 1,
        "contract_renewal": False,
        "preemption_right": False,
        # Market
        "repair_auction_january": True,
        "free_agent_pool": True,
        "direct_trades": False,
        "always_on_markets": False,
        # Economy
        "carryover_budget": False,
        "carryover_percentage": 0.0,
        "player_value_dynamic": False,
        "amortization": False,
        "release_clauses": False,
        "clause_default_factor": 0.8,  # irrilevante se off, ma teniamo il default
        "rescission_penalty": False,
        "rescission_recovery_pct": 50.0,
        # Tactics
        "no_schema_tactics": False,
        # Scouting
        "scouting_enabled": False,
    },
    suggested_markets=[
        MarketEventTemplate(
            name="Asta Iniziale",
            type="auction",
            mode="live",
            window_hint="metà agosto, 4-6 serate",
            description="Asta dal vivo col battitore AI di Mister.",
        ),
        MarketEventTemplate(
            name="Pool Svincolati",
            type="free_agent",
            window_hint="sempre attivo da settembre a maggio",
            description="Giocatori non acquistati restano in pool, prezzo base per ruolo.",
        ),
        MarketEventTemplate(
            name="Riparazione Gennaio",
            type="auction",
            mode="async",
            window_hint="30 gennaio - 2 febbraio",
            description="Asta di riparazione sui nuovi acquisti reali di gennaio.",
        ),
    ],
    suggested_competitions=[
        CompetitionSuggestion(
            name="Campionato",
            type="campionato",
            description="Girone all'italiana ripetuto 5 volte sulle giornate Serie A.",
        ),
    ],
    is_system=True,
    is_active=True,
)


# ============================================================
# 2. ESPLORATORE
# ============================================================

ESPLORATORE = TemplateProfile(
    id="esploratore",
    name="Esploratore",
    tagline="Per chi vuole più profondità, senza complicarsi la vita",
    description=(
        "Il ponte verso il manageriale. Contratti di 1-2 stagioni, "
        "trattative dirette tra manager, budget che si tramanda nel tempo. "
        "Niente clausole rescissorie ancora. La tua squadra inizia a "
        "diventare una storia, non una tabula rasa annuale."
    ),
    complexity_level=2,
    estimated_weekly_minutes=25,
    icon="compass",
    feature_flags={
        # Contracts
        "multi_season_contracts": True,
        "max_contract_length": 2,
        "contract_renewal": True,
        "preemption_right": True,
        # Market
        "repair_auction_january": True,
        "free_agent_pool": True,
        "direct_trades": True,
        "always_on_markets": True,
        # Economy
        "carryover_budget": True,
        "carryover_percentage": 50.0,
        "player_value_dynamic": True,
        "amortization": True,
        "release_clauses": False,
        "clause_default_factor": 0.8,
        "rescission_penalty": True,
        "rescission_recovery_pct": 50.0,
        # Tactics
        "no_schema_tactics": False,
        # Scouting
        "scouting_enabled": False,
    },
    suggested_markets=[
        MarketEventTemplate(
            name="Asta Iniziale",
            type="auction",
            mode="live",
            window_hint="metà agosto",
            description="Asta dal vivo. Per ogni acquisto, finestra post-asta per durata contratto.",
        ),
        MarketEventTemplate(
            name="Scambi Sempre Attivi",
            type="trade",
            window_hint="sempre da settembre a maggio",
            description="Scambi bilaterali con approvazione admin.",
        ),
        MarketEventTemplate(
            name="Pool Svincolati",
            type="free_agent",
            window_hint="sempre attivo",
            description="Include anche giocatori svincolati attivamente da altri manager.",
        ),
        MarketEventTemplate(
            name="Riparazione Gennaio",
            type="auction",
            mode="async",
            window_hint="30 gennaio - 2 febbraio",
            description="Riparazione async sui nuovi acquisti reali, con scelta contratto.",
        ),
    ],
    suggested_competitions=[
        CompetitionSuggestion(
            name="Campionato",
            type="campionato",
            description="Girone all'italiana ripetuto 5 volte.",
        ),
        CompetitionSuggestion(
            name="Coppa Manager",
            type="coppa",
            description="Eliminazione diretta a gara secca, bracket configurato dall'admin.",
        ),
    ],
    is_system=True,
    is_active=True,
)


# ============================================================
# 3. MANAGERIALE
# ============================================================

MANAGERIALE = TemplateProfile(
    id="manageriale",
    name="Manageriale",
    tagline="Per chi vuole gestire un vero club nel tempo",
    description=(
        "Il prodotto pieno. Contratti fino a 5 stagioni, ammortamento, "
        "clausole rescissorie, mercato sempre attivo, scouting per scoprire "
        "giovani, tattica no-schema attivabile. La tua squadra è un'impresa "
        "da gestire stagione dopo stagione."
    ),
    complexity_level=3,
    estimated_weekly_minutes=50,
    icon="briefcase",
    feature_flags={
        # Contracts
        "multi_season_contracts": True,
        "max_contract_length": 5,
        "contract_renewal": True,
        "preemption_right": True,
        # Market
        "repair_auction_january": True,
        "free_agent_pool": True,
        "direct_trades": True,
        "always_on_markets": True,
        # Economy
        "carryover_budget": True,
        "carryover_percentage": 100.0,
        "player_value_dynamic": True,
        "amortization": True,
        "release_clauses": True,
        "clause_default_factor": 0.8,
        "rescission_penalty": True,
        "rescission_recovery_pct": 50.0,
        # Tactics
        "no_schema_tactics": False,  # default off ma visibile nel pannello
        # Scouting
        "scouting_enabled": True,
    },
    suggested_markets=[
        MarketEventTemplate(
            name="Asta Iniziale",
            type="auction",
            mode="live",
            window_hint="metà agosto",
            description="Asta dal vivo. Decisione contratto + clausola in finestra post-asta.",
        ),
        MarketEventTemplate(
            name="Scambi Sempre Attivi",
            type="trade",
            window_hint="sempre attivo",
            description="Scambi bilaterali e triangolari, con o senza crediti.",
        ),
        MarketEventTemplate(
            name="Pool Svincolati",
            type="free_agent",
            window_hint="sempre attivo",
            description="Include svincolati e giocatori con contratto scaduto.",
        ),
        MarketEventTemplate(
            name="Riparazione Gennaio",
            type="auction",
            mode="async",
            window_hint="30 gennaio - 2 febbraio",
            description="Riparazione strutturata su nuovi acquisti reali e scambi.",
        ),
        MarketEventTemplate(
            name="Finestra Svincoli Autunno",
            type="release",
            mode="blind",
            window_hint="metà novembre, 48h",
            description="Finestra dedicata per svincoli con penale, recovery 50%.",
        ),
    ],
    suggested_competitions=[
        CompetitionSuggestion(
            name="Campionato",
            type="campionato",
            description="Girone all'italiana ripetuto 5 volte.",
        ),
        CompetitionSuggestion(
            name="Coppa Manager",
            type="coppa",
            description="Eliminazione diretta a gara secca o andata/ritorno.",
        ),
        CompetitionSuggestion(
            name="Punteggio Assoluto",
            type="punteggio_assoluto",
            description="Classifica per somma cumulativa, rimuove la fortuna del calendario.",
        ),
    ],
    is_system=True,
    is_active=True,
)


# ============================================================
# REGISTRO DEI SEED
# ============================================================

SYSTEM_TEMPLATES = [CLASSICO, ESPLORATORE, MANAGERIALE]

DEFAULT_TEMPLATE_ID = "classico"


def get_system_template(template_id: str) -> TemplateProfile:
    """Recupera un template di sistema per ID. Solleva KeyError se non esiste."""
    for t in SYSTEM_TEMPLATES:
        if t.id == template_id:
            return t
    raise KeyError(f"Template di sistema '{template_id}' non trovato")
