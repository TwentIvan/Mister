"""
Factory functions per creare entità di dominio a partire dai template.

Queste sono helper invocate dagli endpoint API quando l'admin di una
lega esegue azioni di setup (crea lega, accetta un suggerimento di mercato,
crea una competizione).

Tutte applicano la regola dello SNAPSHOT: copiano valori dal template/
suggerimento, non mantengono riferimenti vivi.
"""

from __future__ import annotations
from datetime import datetime
from typing import Optional

from app.models.template import TemplateProfile, MarketEventTemplate
from app.models.federation import Federation
from app.models.market import (
    MarketEvent,
    TimeWindow,
    AuctionRules,
    TradeRules,
    ReleaseRules,
    FreeAgentRules,
)
from app.models.competition import (
    Competition,
    CampionatoSettings,
    CoppaSettings,
    BattleRoyaleSettings,
    SprintRaceSettings,
    FormulaUnoSettings,
    PunteggioAssolutoSettings,
)


# ============================================================
# FEDERATION FACTORY
# ============================================================

def make_federation_from_template(
    template: TemplateProfile,
    federation_id: str,
    federation_name: str,
    description: str = "",
) -> Federation:
    """
    Crea una Federation copiando i feature_flags del template (snapshot).
    Tutto il resto (bonus_malus, soglie, modificatori) parte dai default,
    poi l'admin può raffinarli in modalità avanzata.
    """
    return Federation(
        id=federation_id,
        name=federation_name,
        description=description or template.description,
        template_id=template.id,
        # I default Pydantic gestiscono bonus_malus, soglie, modificatori
        feature_flags=template.resolved_flags(),
    )


# ============================================================
# MARKET EVENT FACTORY
# ============================================================

def make_market_event_from_suggestion(
    suggestion: MarketEventTemplate,
    league_id: str,
    event_id: str,
    starts_at: datetime,
    ends_at: datetime,
) -> MarketEvent:
    """
    Crea un MarketEvent concreto a partire da un MarketEventTemplate suggerito
    dal template profilo. L'admin fornisce le date concrete.
    """
    window = TimeWindow(starts_at=starts_at, ends_at=ends_at, open_24h=True)

    auction = trade = release = free_agent = None

    if suggestion.type == "auction":
        auction = AuctionRules(
            mode=suggestion.mode or "live",
        )
    elif suggestion.type == "trade":
        trade = TradeRules()
    elif suggestion.type == "release":
        release = ReleaseRules(mode=suggestion.mode or "open")
    elif suggestion.type == "free_agent":
        free_agent = FreeAgentRules()

    return MarketEvent(
        id=event_id,
        league_id=league_id,
        name=suggestion.name,
        type=suggestion.type,
        description=suggestion.description,
        window=window,
        auction=auction,
        trade=trade,
        release=release,
        free_agent=free_agent,
    )


# ============================================================
# COMPETITION FACTORY
# ============================================================

def make_campionato(
    league_id: str,
    competition_id: str,
    name: str,
    season: int,
    n_managers: int,
    numero_gironi: int = 5,
    start_giornata: int = 1,
    end_giornata: int = 38,
) -> Competition:
    """
    Crea un Campionato pre-configurato per N manager con M gironi.
    
    Per 8 manager con 5 gironi:
      giornate_per_girone = 7
      totale giornate fanta = 35
    """
    giornate_per_girone = n_managers - 1
    # Imposta il girone neutro: con un numero dispari di gironi (es. 5),
    # l'ultimo viene giocato in campo neutro per non favorire nessuno
    girone_neutro = [numero_gironi] if numero_gironi % 2 == 1 else []

    return Competition(
        id=competition_id,
        league_id=league_id,
        name=name,
        type="campionato",
        season=season,
        start_giornata=start_giornata,
        end_giornata=end_giornata,
        campionato=CampionatoSettings(
            giornate_per_girone=giornate_per_girone,
            numero_gironi=numero_gironi,
            home_advantage_enabled=True,
            home_advantage_bonus=3.0,
            girone_neutro=girone_neutro,
        ),
        tiebreakers=[
            "scontri_diretti",
            "differenza_reti",
            "gol_fatti",
            "punteggio_totale",
        ],
    )


def make_coppa(
    league_id: str,
    competition_id: str,
    name: str,
    season: int,
    bracket: list[list[str]],
    two_legs: bool = False,
    start_giornata: int = 1,
    end_giornata: int = 38,
) -> Competition:
    """
    Crea una Coppa con bracket manuale fornito dall'admin.
    """
    return Competition(
        id=competition_id,
        league_id=league_id,
        name=name,
        type="coppa",
        season=season,
        start_giornata=start_giornata,
        end_giornata=end_giornata,
        coppa=CoppaSettings(
            two_legs=two_legs,
            tie_break_in_match="penalties",
            bracket=bracket,
        ),
    )


def make_battle_royale(
    league_id: str,
    competition_id: str,
    name: str,
    season: int,
    start_giornata: int,
    end_giornata: int,
) -> Competition:
    return Competition(
        id=competition_id,
        league_id=league_id,
        name=name,
        type="battle_royale",
        season=season,
        start_giornata=start_giornata,
        end_giornata=end_giornata,
        battle_royale=BattleRoyaleSettings(),
        tiebreakers=[
            "vittorie_totali_match",
            "punteggio_totale",
            "differenza_reti",
        ],
    )


def make_sprint_race(
    league_id: str,
    competition_id: str,
    name: str,
    season: int,
    start_giornata: int,
    end_giornata: int,
) -> Competition:
    return Competition(
        id=competition_id,
        league_id=league_id,
        name=name,
        type="sprint_race",
        season=season,
        start_giornata=start_giornata,
        end_giornata=end_giornata,
        sprint_race=SprintRaceSettings(),
        tiebreakers=["gol_fatti_giornata", "punteggio_totale_storico"],
    )


def make_formula_uno(
    league_id: str,
    competition_id: str,
    name: str,
    season: int,
    start_giornata: int = 1,
    end_giornata: int = 38,
    scale: list[int] | None = None,
) -> Competition:
    """
    Formula 1. Scala default = moderna F1.
    Per la scala storica passa [10, 6, 4, 3, 2, 1].
    """
    return Competition(
        id=competition_id,
        league_id=league_id,
        name=name,
        type="formula_uno",
        season=season,
        start_giornata=start_giornata,
        end_giornata=end_giornata,
        formula_uno=FormulaUnoSettings(
            points_scale=scale or [25, 18, 15, 12, 10, 8, 6, 4, 2, 1]
        ),
        tiebreakers=["f1_vittorie", "f1_podi", "punteggio_totale"],
    )


def make_punteggio_assoluto(
    league_id: str,
    competition_id: str,
    name: str,
    season: int,
    start_giornata: int = 1,
    end_giornata: int = 38,
    exclude_worst_n: int = 0,
) -> Competition:
    return Competition(
        id=competition_id,
        league_id=league_id,
        name=name,
        type="punteggio_assoluto",
        season=season,
        start_giornata=start_giornata,
        end_giornata=end_giornata,
        punteggio_assoluto=PunteggioAssolutoSettings(
            exclude_worst_n_giornate=exclude_worst_n,
        ),
        tiebreakers=["giornate_vinte", "punteggio_max_giornata"],
    )
