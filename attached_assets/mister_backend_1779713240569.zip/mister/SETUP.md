# SETUP — Replit step by step

Da zero a "FastAPI running con template profili caricati" in circa 20 minuti.

## 1. Crea il Repl

Vai su [replit.com](https://replit.com), accedi, clicca **+ Create Repl**:
- Template: **Python**
- Nome: `mister-backend`
- Privacy: **Private** (raccomandato)
- Click **Create**

## 2. Importa i file del progetto

**Opzione A (più semplice) — Upload zip:**
1. Scarica `mister_backend.zip` da questa chat
2. Nella sidebar di Replit, click destro sulla cartella root → **Upload file**
3. Carica lo zip
4. Apri la **Shell** (icona terminal in basso) e lancia:
   ```
   unzip mister_backend.zip
   mv mister/* mister/.[!.]* .
   rmdir mister
   rm mister_backend.zip
   ```

**Opzione B — Git:**
1. Estrai lo zip in locale, `cd mister`, `git init`, `git add .`, `git commit -m "initial"`, push su GitHub
2. In Replit: **+ Create Repl** → **Import from GitHub**

## 3. Imposta i Secrets

In Replit cerca **🔒 Secrets** (o **Tools → Secrets**) nella sidebar e aggiungi:

| Key                  | Value                                                    |
|----------------------|----------------------------------------------------------|
| `API_FOOTBALL_KEY`   | da dashboard.api-football.com → My Access                |
| `ANTHROPIC_API_KEY`  | da console.anthropic.com                                 |
| `SUPERADMIN_KEY`     | una stringa random lunga (vedi sotto)                    |
| `APP_ENV`            | `dev`                                                    |
| `DATABASE_URL`       | `sqlite:///./mister.db`                                  |

Per generare un `SUPERADMIN_KEY` random, in Shell:
```
python3 -c "import secrets; print(secrets.token_urlsafe(32))"
```

Copialo nel Secret. Tienitelo da parte: ti servirà come header nelle
chiamate a `/api/superadmin/*`.

## 4. Installa le dipendenze

```
pip install -r requirements.txt
```

Se vedi "externally-managed-environment":
```
pip install --break-system-packages -r requirements.txt
```

## 5. Lancia il server

Click **Run** in alto. Replit eseguirà:
```
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Console attesa:
```
INFO:     Uvicorn running on http://0.0.0.0:8000
[seed] Template 'classico' creato
[seed] Template 'esploratore' creato
[seed] Template 'manageriale' creato
INFO:     Application startup complete.
```

I tre template di sistema sono ora nel DB. Naviga su `/health` e vedrai
`{"status": "ok"}`. Su `/docs` trovi la documentazione interattiva di
FastAPI (Swagger UI).

## 6. Verifica i template pubblici

Endpoint pubblico, accessibile senza auth:
```
curl http://localhost:8000/api/templates
```

Output atteso:
```json
[
  {"id": "classico", "name": "Classico", "complexity_level": 1, ...},
  {"id": "esploratore", "name": "Esploratore", "complexity_level": 2, ...},
  {"id": "manageriale", "name": "Manageriale", "complexity_level": 3, ...}
]
```

Per il dettaglio di un template (compresi i feature flag):
```
curl http://localhost:8000/api/templates/manageriale
```

## 7. Verifica il pannello superadmin

Tutti gli endpoint `/api/superadmin/*` richiedono l'header
`X-Superadmin-Key: <SUPERADMIN_KEY>`. Senza, ricevi 403.

Lista del catalogo feature flag:
```
curl -H "X-Superadmin-Key: <la_tua_chiave>" \
  http://localhost:8000/api/superadmin/flags
```

Lista template (inclusi disattivi):
```
curl -H "X-Superadmin-Key: <la_tua_chiave>" \
  http://localhost:8000/api/superadmin/templates
```

Modifica del template Esploratore (es. alza carryover al 70%):
```
curl -X PUT \
  -H "X-Superadmin-Key: <la_tua_chiave>" \
  -H "Content-Type: application/json" \
  -d '{"feature_flags": {"carryover_percentage": 70.0, "carryover_budget": true, "multi_season_contracts": true, "max_contract_length": 2, "contract_renewal": true, "preemption_right": true, "repair_auction_january": true, "free_agent_pool": true, "direct_trades": true, "always_on_markets": true, "player_value_dynamic": true, "amortization": true, "release_clauses": false, "clause_default_factor": 0.8, "rescission_penalty": true, "rescission_recovery_pct": 50.0, "no_schema_tactics": false, "scouting_enabled": false}}' \
  http://localhost:8000/api/superadmin/templates/esploratore
```

(Nota: nei `PUT` puoi mandare solo i campi che cambiano. Per i flag,
includili tutti per chiarezza. Aggiungeremo presto un endpoint dedicato
per aggiornare singoli flag.)

Reset dei template di sistema ai valori del file (utile dopo un deploy):
```
curl -X POST \
  -H "X-Superadmin-Key: <la_tua_chiave>" \
  http://localhost:8000/api/superadmin/templates/reset-system
```

## 8. Verifica API-Football

In Shell:
```
python3
```
```python
import asyncio
from app.data.api_football import APIFootballClient

async def test():
    async with APIFootballClient() as c:
        cov = await c.verify_serie_a_coverage(season=2024)
        print(cov)

asyncio.run(test())
```

Output atteso: `{'events': True, 'lineups': True, 'statistics_fixtures': True, 'statistics_players': True, 'players': True, 'injuries': True}`.

## 9. Verifica Anthropic

```python
import os
from anthropic import Anthropic
c = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
m = c.messages.create(model="claude-sonnet-4-6", max_tokens=50,
                      messages=[{"role":"user","content":"Dimmi 'ok' in italiano."}])
print(m.content[0].text)
```

## 10. Prossimi sviluppi

Roadmap per arrivare a MVP funzionante:

1. **Script seeding API-Football → DB** (`scripts/seed_serie_a.py`)
2. **Fetcher giornata** (`scripts/fetch_giornata.py`) per popolare le performance
3. **Endpoint POST /api/leagues** — crea lega da template + scaffolding Federation/markets/competitions
4. **Endpoint /api/lineups** — schiera formazione
5. **Endpoint /api/matches/{id}/calculate** — engine + narratore
6. **Implementazione flusso contratto** (per Esploratore/Manageriale)
7. **Implementazione asta live** con WebSocket + diritto di pareggio
8. **Pannello superadmin HTML** semplice per editing template visivo

## Risoluzione problemi

**"ModuleNotFoundError: No module named 'app'"**
Lancia dalla root del progetto, non da dentro `app/`.

**"SUPERADMIN_KEY non configurato"**
Manca il Secret. Vai nei Secrets di Replit e impostalo.

**403 sugli endpoint /api/superadmin/***
Header mancante o sbagliato. Verifica che `X-Superadmin-Key` corrisponda al Secret.

**Server non raggiungibile dall'iframe Replit**
Verifica `--host 0.0.0.0`, non `127.0.0.1`.

**"401 Unauthorized" da API-Football**
Chiave non valida o scaduta. Rigenera da dashboard.
