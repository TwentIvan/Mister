# Mister — il fantacalcio manageriale

Backend del prodotto. Python 3.12 + FastAPI + SQLModel + Pydantic.

## Architettura in una pagina

```
Onboarding di una nuova lega:
─────────────────────────────────────────────────────
  TemplateProfile (DB-stored, superadmin-editable)
       Classico / Esploratore / Manageriale
              ↓ snapshot al momento della creazione
       Federation (rules + feature_flags copiati)
              ↑
       League (manager, crediti, rosa, capitano)
              ↓
       Competition × N  +  MarketEvent × N
       (creati esplicitamente dall'admin)
```

```
mister/
├── app/
│   ├── config.py            ← settings
│   ├── main.py              ← FastAPI app
│   │
│   ├── models/              ★ MODELLI DI DOMINIO
│   │   ├── flags.py         ← CATALOGO feature flag (18 voci, source of truth)
│   │   ├── template.py      ← TemplateProfile (i preset Classico/Esploratore/Manageriale)
│   │   ├── federation.py    ← Regolamento + feature_flags snapshot
│   │   ├── league.py        ← Istanza lega (manager, crediti)
│   │   ├── competition.py   ← 6 tipi: campionato/coppa/battle_royale/sprint_race/F1/p.assoluto
│   │   ├── market.py        ← Eventi mercato: auction/trade/release/free_agent
│   │   ├── contract.py      ← Contratti multi-stagione (ammortamento, clausola)
│   │   └── common.py        ← Player, FantaTeam, Lineup, FantaMatch
│   │
│   ├── presets/             ★ PRESET DI PRODOTTO
│   │   ├── templates.py     ← I 3 template Classico/Esploratore/Manageriale (seed)
│   │   └── factories.py     ← Factory functions (Federation, Campionato, ecc.)
│   │
│   ├── api/                 ← Endpoints FastAPI
│   │   ├── templates.py     ← Pubblico: lista template attivi
│   │   └── superadmin.py    ← CRUD template (solo superadmin)
│   │
│   ├── engine/              ← Match engine
│   │   ├── simulator.py     ← Flow simulation
│   │   └── narrator.py      ← Claude narrative gen
│   │
│   ├── data/                ← Integrazioni esterne
│   │   └── api_football.py  ← Client API-Football
│   │
│   └── db/                  ← Persistenza
│       ├── schema.py        ← Tabelle SQLModel
│       └── seed.py          ← Seeder dei template di sistema
│
├── tests/
├── scripts/
│
├── requirements.txt
├── .env.example             ← copia in .env per dev locale
├── .replit                  ← config Replit
└── README.md
```

## I concetti chiave

### Template, Federation, League — chi fa cosa

**TemplateProfile** è il preset di partenza che l'admin di una nuova lega
sceglie in onboarding. Esistono tre template di sistema:

- **Classico** (~10 min/settimana) — fantacalcio tradizionale, stagione singola, niente contratti
- **Esploratore** (~25 min/settimana) — contratti 1-2 stagioni, scambi, carryover budget
- **Manageriale** (~50 min/settimana) — contratti 5 anni, clausole, scouting, mercato sempre attivo

Vivono nel database (tabella `template_profiles`) e sono **editabili dal
superadmin** (tu, l'owner del prodotto) tramite l'endpoint
`/api/superadmin/templates`. Puoi anche aggiungere un quarto template,
disattivare uno esistente, o ritarare i valori.

**Federation** è creata QUANDO una lega viene istanziata. Copia i feature
flag dal template scelto come **snapshot autonomo**: cambi successivi al
template non impattano leghe esistenti. Questo evita il disastro UX di
modificare retroattivamente le regole di leghe in corso.

**League** è l'istanza vera e propria con manager, crediti, rosa, regole capitano.

### Feature flags — il sistema di configurazione

`app/models/flags.py` definisce il catalogo canonico dei 18 feature flag
che il sistema sa esprimere. Ogni flag ha tipo (bool/int/float/string),
default conservativo, label e descrizione per la UI superadmin.

Aggiungere un flag nuovo richiede:
1. Dichiararlo in `flags.py`
2. Implementare il comportamento nel match engine o nel sistema mercati
3. Aggiornare i template di sistema in `presets/templates.py`
4. Eventualmente migrare le leghe esistenti

Il superadmin **non può aggiungere flag nuovi dal pannello** — solo
modificare i valori di quelli esistenti e creare combinazioni nuove.

### Sei tipi di competizione

L'admin di una lega crea esplicitamente ogni competizione (nessun
automatismo, nessun calendario di default):

- **Campionato** — girone all'italiana ripetuto N volte (default 5 per 8 manager → 35 giornate). Home/away configurabili per girone, ultimo girone neutro se N dispari.
- **Coppa** — eliminazione diretta a gara secca o A/R. Bracket manuale fornito dall'admin.
- **Battle Royale** — tutti contro tutti ogni giornata. Cumulativo (0-21 punti/giornata per N=8).
- **Sprint Race** — eliminazione del peggiore ogni giornata fino al sopravvissuto.
- **Formula 1** — punti F1 per posizione di giornata. Scala configurabile.
- **Punteggio Assoluto** — somma cumulativa fanta-punti. Con scarto opzionale delle peggiori N giornate.

Tiebreaker dinamici: l'admin sceglie l'ordine dei criteri da una lista
specifica per ciascun tipo.

### Quattro tipi di mercato

LF presenta 7 modalità d'asta come opzioni piatte. Noi abbiamo 4 tipi
canonici con sotto-modalità:

| Mister                          | Mappa a LF                       |
|---------------------------------|----------------------------------|
| auction (mode=live)             | Asta Classica                    |
| auction (mode=async)            | Asta Smart                       |
| auction (mode=blind)            | Asta a Buste                     |
| auction (mode=token)            | A Gettone                        |
| trade                           | Scambi                           |
| release (mode=open)             | Svincoli                         |
| release (mode=blind)            | Svincoli al Buio                 |
| free_agent                      | (non in LF, pool permanente)     |

### Contratti pluriennali (Esploratore + Manageriale)

Modello di ammortamento lineare:
- Prezzo d'asta P spalmato su N stagioni → ingaggio annuo = P/N
- L'ingaggio annuo viene scalato dal budget di ogni stagione
- Niente wage separato (l'ammortamento è l'ingaggio)

**Clausola rescissoria** (solo Manageriale):
- Default = ammortamento_residuo × 0.8 (slight discount, leggera vulnerabilità)
- Manager può ALZARLA pagando crediti 1-per-1 al momento del contratto
- Quando un altro manager paga la clausola, il vecchio incassa, il nuovo apre un nuovo contratto

**Rescissione attiva** del manager:
- Coefficiente penale decrescente per anno di contratto (default 1.5x → 1.0x)
- Recovery del 50% dell'ammortamento residuo dopo penale

**Scadenza naturale** con diritto di pareggio:
- Il giocatore va all'asta come svincolato
- Il detentore uscente può **pareggiare in tempo reale** i rilanci nell'asta
- Tie-breaking asimmetrico: a parità di importo, il pareggio vince sul rilancio normale

## Stato del codice

| Modulo                                    | Stato        |
|-------------------------------------------|--------------|
| Catalogo feature flags                    | ✅ Completo  |
| TemplateProfile + 3 seed                  | ✅ Completo  |
| Federation, League, Competition, Market   | ✅ Completo  |
| Contract                                  | ✅ Completo  |
| Endpoints superadmin (template CRUD)      | ✅ Completo  |
| Endpoints pubblici template               | ✅ Completo  |
| DB schema + seeder                        | ✅ Completo  |
| API-Football client                       | ✅ Funzionante |
| Match engine                              | ✅ Funzionante |
| Narratore Claude                          | ✅ Prompt v1 |
| Routes lega/competizione/mercato CRUD     | 🚧 Stub      |
| Auth / accounts                           | ❌ TODO      |
| Frontend                                  | ❌ TODO      |

## Come si parte

Vedi `SETUP.md` per le istruzioni Replit passo per passo.

Tldr:
```bash
pip install -r requirements.txt
cp .env.example .env  # edita con le chiavi
uvicorn app.main:app --reload
```

Poi `curl http://localhost:8000/api/templates` per vedere i tre template attivi.

## Prossimi step di sviluppo

1. Endpoint CRUD per Lega/Federation/Competition/MarketEvent
2. Fetcher API-Football per popolare il DB con squadre + giocatori
3. Endpoint creazione lega da template (con cascade: Federation + suggested markets)
4. Implementazione del flusso contratto (asta → finestra post-aggiudicazione → contract DB)
5. Implementazione del diritto di pareggio in asta
6. Pannello superadmin minimal (HTML form, no React per v1)
