# Mister — Specifica (documento modulare)

*Documento vivo, v2 modulare. Da vedere e rivedere.*

Mister è un'app di fantacalcio manageriale (backend Replit/Drizzle/Postgres, frontend React/Vite). Questa specifica è la **fonte di verità del design**, organizzata in moduli indipendenti.

## Come è fatto (e come si refactora veloce)

- **Moduli**: ogni concern è un file in `spec/`. Si modifica un modulo senza toccare gli altri.
- **ID stabili**: token `T-*`, componenti `C-*`, schermate `S-*`, regole `R-*`. I riferimenti sono per ID, non per prosa.
- **Registro**: `registro.json` tiene il grafo delle relazioni (chi usa cosa).
- **Generatore**: `genera.py` **valida** i riferimenti e **genera** la Matrice di propagazione (modulo 09) dal registro, poi **assembla** tutti i moduli in `mister_spec.md` (la copia leggibile). La matrice non si scrive a mano: si rigenera.
- **Token**: `tokens.css` è la fonte unica; `propaga.py` la inietta in tutte le schermate.

Ciclo di refactoring:
1. cambi un **token** → edita `tokens.css` → `python3 propaga.py`.
2. cambi un **componente/regola/architettura** → edita il modulo `spec/` relativo e, se cambiano le relazioni, `registro.json` → `python3 genera.py` (rivalida + rigenera matrice + riassembla).

## Moduli
01 Principi · 02 Token · 03 Brand · 04 Filosofia di layout · 05 Modello a strati · 06 Componenti · 07 Schermate · 08 Regole · 09 Matrice (generata) · 10 Stato & pendenze · 11 Allegati · 12 Brief di integrazione (generato)

---

## 1. Principi

1. **Una sola fonte di verità per ogni "lettera".** Token in `tokens.css`. Componenti definiti una volta nel modulo 06. Le schermate **usano**, non ridefiniscono.
2. **Se cambi una lettera, si propaga.** Per i token: `tokens.css` + `propaga.py` (tecnico). Per componenti/regole/architettura: il **registro** + la **Matrice (09)** dicono dove guardare; `genera.py` rivalida e rigenera.
3. **Verificare la resa, non solo che compili.** I mockup vanno guardati renderizzati; le correzioni si fanno alla fonte (token/componente), non con pezze locali.
4. **Ogni informazione una volta sola.** Non ripetere a testo ciò che colore, posizione o un altro elemento già comunicano; non mostrare lo stesso dato in due punti della stessa schermata. Esempi reali da evitare: il punteggio ripetuto in titolo + corpo + scoreboard; "2ª giornata" sia nel kicker sia nel titolo; l'intestazione di reparto ("Portieri") quando il colore della riga già dice il ruolo. Il dato vive nel punto più forte; gli altri lo lasciano stare.

Maturità: alfabeto e schermate esistono come mockup statici, dati e loghi **segnaposto**. Restano test e integrazione runtime.

---

## 2. Token (l'alfabeto) → `tokens.css`

Valori esatti in `tokens.css`. Qui significato e ID.

- **T-carta** `--cream/--cream2/--paper` — carta: sfondo, superfici, card (estetica almanacco).
- **T-verde** `--green/-d/-l` — verde istituzione: marchio, testo su carta, fondi scuri, accenti/link, "sale".
- **T-erba** `--pitch/--pitch2` — **solo** il manto del campo.
- **T-oro** `--gold/--gold-l` — **riservato** (vedi R-oro): denaro/FM/valore/prezzi/prestigio/marchio.
- **T-live** `--live` — in diretta; "scende" in classifica; timer.
- **T-neutri** `--muted/--line` — testo secondario, bordi.
- **T-ruolo** — tre registri dello stesso ruolo P/D/C/A: riga su scuro `--rP/rD/rC/rA` (ocra·verde·teal·mattone) · anello chip su erba `--ringP..A` · lettera su carta `--letP..A`.
- **T-club** — mappa colori club bicolore (coda di `tokens.css`). In produzione il crest-club usa il **logo reale** (vedi `R-crest`); questa mappa resta per il **fallback monogramma** (logo mancante) e per i **mockup statici**. Crest split 135°, barra split 90°.
- **T-font** `--disp` Fraunces (titoli, cognomi, numeri-valore, cerimonie) · `--mono` JetBrains Mono (corpo, dati, etichette).
- **T-phone** `--phone-w` (390px) + regola no-squish (vedi R-mobile-nosquish) — cornice telefono.

---

## 3. Brand → `mister_brand.zip`

Concept: **almanacco editoriale × terminale manageriale**. Marchio **M-formazione** (la M come schieramento 2-3-3-2, nodi oro).

Asset: `wordmark_mister.svg` / `wordmark_mister_crema.svg` (logotipo carta/scuro) · `icona_M_formazione.svg`, `mark_M_formazione.svg`, `segno_M_carta.svg` (il segno) · `lockup_impilato.svg` · `mister_volto_inciso.png` (**acquaforte del Mister**: accento di marca **raro** — login/testate/cerimonie; *non* è il volto allenatore nei badge, vedi R-mister-toy).

---

## 4. Filosofia di layout → `mappa_guscio.html`

### Tre altitudini
1. **Globale / tu** = Home: feed-gazzetta + tue leghe/federazioni + profilo. Nativa mobile.
2. **Federazione** = il tuo mondo, identità: nome+stemma, albo d'oro, premiazioni, regole/governance. Snella ma **ricca d'identità**; è il **differenziante**, visibile da subito anche con una sola lega.
3. **Lega** = workspace operativo: competizioni, mercati, rosa, formazione, classifica, partecipanti.

### Mobile vs desktop
- **Mobile** per il quotidiano: bottom-tab (Home/Leghe/Notifiche/Profilo) + ☰.
- **Desktop** per il denso e scenico: config asta, tabellone, formazione, partita.
- **Asta live = coppia**: tabellone desktop (scena) + paletta mobile (rilancio personale).

### La Home è il feed
Eventi di sistema in **voce d'almanacco** (aste/colpi/risultati/finestre/premiazioni) + social leggero **ancorato agli affari**. Niente chat generica.

### Mercati = finestre
Vivono in **finestre** del calendario. Fuori si **tratta** (always-on); dentro si **esegue**. L'asta è **un tipo** di mercato.

---

## 5. Modello a strati (la grammatica)

Una lega appartiene **sempre** a una federazione (implicita/automatica nel caso "una sola lega": l'admin non vede il gergo).

- **Globale/sistema** — il dato reale: anagrafica giocatori, giornate Serie A, voti grezzi (API-Sports).
- **Federazione** — l'istituzione: **identità** (nome+logo) · **regole** (algoritmo voto + punteggio/ruoli **flessibili**, non rigido classic/mantra — qui vivono anche i **parametri di conversione gol** del classico: soglia base e passo, vedi `R-classico-gol`) · **convalida** · **memoria/prestigio** (albo d'oro). Catena: lega organizza → federazione convalida → premiabile → albo d'oro. Strato **latente**: affiora come identità+albo (visibile) e governance (owner).
- **Lega** — l'organizzatore: competizioni · **mercati** (asta/scambi/svincoli) · **quotazioni** · partecipanti · rosa · budget. I mercati sono di **lega**, non di federazione. Ogni lega legge/congela uno **snapshot** della federazione.
- **Competizione** — una **sequenza di fasi** (vedi *Composizione* sotto), da cui discende come i risultati diventano graduatoria/tabellone e *quale punteggio si racconta*. Organizzata dalla lega; legge le regole della federazione senza duplicarle (`R-fonte-strato`).
- **Modelli/template** — ricette di default che seminano valori alla creazione. Trasversali, **non** legati alla federazione, **non** voce di menu. Es. "Classico" semina le finestre abituali, tutte **editabili**.

### Composizione: fasi, misura, struttura

Una **competizione** è una **sequenza ordinata di fasi**. Una **fase** combina due assi indipendenti, e risolve *come una giornata di punteggi grezzi diventa esito ufficiale* — prodotto **una sola volta** e letto da Feed/Classifica/Partita (`R-classico-gol`, `R-fonte-strato`).

**Misura** — come una giornata diventa un valore per la squadra:
- *scontro diretto* — affronti avversari → conversione gol → punti V/N/P; sotto-parametro: contro **uno** (calendario) o contro **tutti** (ogni giornata); sola andata o andata/ritorno.
- *punteggio assoluto* — vale il tuo totale grezzo.
- *posizione* — il piazzamento di giornata → punti da tabella (alla F1).

**Struttura** — come la fase decide:
- *classifica* — si accumula, vince il totale; parametro **numero di gironi** (1 = girone unico; N = gironi).
- *tabellone* — eliminazione a scontri secchi; parametri: gambe (andata/ritorno), spareggio (`R-spareggio`).
- *caduta* — ogni giornata esce chi sta sotto; parametro: quanti escono.

**Qualificazione** — ogni fase non-finale dichiara *chi passa* alla successiva e con quale criterio (primi K per girone · migliori M assoluti · vincitori del tabellone).

I nomi noti sono **combinazioni**, non scatole: *campionato* = una fase `classifica · scontro vs uno`; *battle royale* = `classifica · scontro vs tutti`; *punteggio assoluto* = `classifica · assoluto`; *Formula 1* = `classifica · posizione`; *coppa* = `tabellone` (o `classifica a gironi → tabellone`); *last dead* = `caduta`. Lo spareggio serve solo dove un vincitore è obbligatorio (tabellone; caduta in caso di pari per l'ultimo posto) — nella classifica il pari è sano.

*Supercoppa: accantonata* — i suoi ingressi vengono dai vincitori di **altre** competizioni (qualificazione cross-competizione), fuori dal modello a fasi attuale.

### Configurazione — il wizard (dall'alto in giù)

La configurazione scende per livelli, ognuno **eredita** quello sopra:
1. **Federazione** — regole del mondo: algoritmo voto, parametri di conversione gol. (Nel caso semplice, implicita.)
2. **Lega** — budget, struttura rosa (25 = 3-8-8-6), manager/squadre, finestre di mercato (l'asta).
3. **Competizioni** — una o più; per ognuna scegli un **preset** (campionato, coppa) oppure **componi le fasi** a mano (misura × struttura); ogni fase non-finale dichiara la sua **qualificazione**.
4. **Calendario** — allinea le **fasi** delle competizioni alle **giornate reali** di Serie A: per ogni fase scegli la giornata di partenza, la durata deriva dalla config. L'**asta** è un evento **stand-alone** della lega (area mercati), *non* agganciato alle giornate; può comparire nella vista calendario ma non si schedula qui.

Divisioni: **non** esistono ora (futuro).

---

## 6. Componenti (le parole) → `libreria_componenti.html`

> **Fonte unica in codice: `componenti.py`.** Centralizza il volto toy (`FACE`), la mappa colori club (`CLUBS`, 14 squadre) e la logica colore (`grad_crest` 135° / `grad_bar` 90°), ed espone `badge()` come generatore canonico. Tutti i `build_*.py` importano da qui: cambi il volto o un colore club → rigeneri → si propaga in ogni vista. La migrazione del *markup* del chip al generatore canonico è incrementale (oggi i dati e i colori sono già centralizzati; i wrapper di stile restano per-vista, governati dai token).


### C-badge — Badge giocatore (un solo DNA, più tier)
DNA: **anello colore-ruolo** + **volto toy** (immagine scaricata e "toyzzata", stessa pipeline giocatori e allenatori) + **crest/barra club bicolore** + **cognome** (Fraunces) + slot opzionali: **pillola** alto-dx (prezzo oro in asta / voto in partita) e **disco capitano** alto-sx (oro).
*Regola pillola*: sta **fuori** dal cerchio del volto (l'avatar ha `overflow:hidden`); è figlia del chip, sovrapposta — mai figlia dell'avatar.
Tier: Hero/scheda · Roster (riga) · Tabellone (compatto: colore-ruolo+crest+cognome+**prezzo oro**, senza volto) · Formazione (chip) · Partita (chip+voto) · Medaglione (scheda).

### C-crest — Crest bicolore
Due usi distinti (vedi `R-crest`): **club reale** del giocatore → **logo reale** (API-Football) in contenitore neutro, monogramma di fallback; **squadra fanta** → **disco-monogramma** col `team.color`. Nei mockup statici il club resta placeholder split-135° bicolore.

### C-area-tecnica — Area tecnica
Rettangolo **tratteggiato** sul verde, interno trasparente, nel **margine erboso sinistro** ("campo per destinazione"), **appena fuori dalla linea laterale**, **in basso nella propria metà**. Contiene volto allenatore (**toy**) + nome (+ modulo nel desktop). Nella partita: due, una per metà.

### C-marcature — Marcature campo
Singola squadra: campo verticale con area di rigore e cerchio. **Testa a testa**: ogni metà disegna solo porta e lati; **riga di centrocampo + cerchio tondo + dischetto** = **un solo** elemento condiviso sul confine; corridoio centrale; campo alto abbastanza da non tagliare il portiere.

### C-card-evento — Card-evento (feed)
Voce d'almanacco, accento sinistro per tipo: **rosso** live · **oro** colpo (FM) · **oro tratteggiato** trattativa · neutro risultato/finestra · **verde scuro cerimoniale** albo d'oro. Social leggero ancorato all'evento.

### C-classifica-row — Riga classifica
Posizione + freccia movimento · disco squadra · nome+allenatore · colonne G·V·N·P·GF·GS·Pt·PF. Riga propria evidenziata; capolista col filo verde.

### C-barra-panchina — Barra-panchina (partita)
Barra **verticale** col logo (disco) + nome ruotato 90° ("tettoia"). Le righe panchina dividono l'altezza del box in parti uguali (`flex:1`).

### C-guida-fasi — Guida a fasi
Racconta la **sequenza di fasi** di una competizione come **nodi** uniti da **connettori che portano la regola di qualificazione**. Nodo *concluso* (✓, verde-l), nodo *in corso* (verde pieno con alone), connettore con etichetta (es. "prime 2 di ogni girone → 4"). È la resa visibile e toccabile del modello a fasi (§5): la usano l'hub (card competizione) e il wizard (competizioni/fase/riepilogo). Riusabile per qualunque competizione multi-fase (gironi→tabellone, campionato→playoff, format misti).

### C-bracket — Tabellone (rami)
Albero a eliminazione: **match-card** (due righe-squadra col disco-squadra fanta, risultato in **gol**, vincitore evidenziato col segno di spunta, perdente sbiadito) + **connettori a gomito** che fanno convergere ogni coppia nel turno successivo. Lo **spareggio** è annotato fuori dalla card (caption rossa). Il **campione** chiude con trofeo oro (unico oro, R-oro). Due rese: **desktop** = albero ramificato (connettori SVG su coordinate); **mobile** = un turno per schermata, paginato (tab + scroll-snap, non analogico), coi rami tagliati ai bordi che escono/entrano alla **stessa altezza** così sfogliando la linea prosegue. Usato anche per l'anteprima accoppiamenti nei gironi.

---

## 7. Schermate (le frasi)

Inventario e ID in `registro.json`. Dettaglio per schermata:

- **S-config-asta** (desktop, `config_asta.html`) — pagina unica. Striscia "Ereditato dalla lega" read-only (budget, rosa 3·8·8·6, mode, link a Regole di lega). Formato (live / busta chiusa). Svolgimento (a giro / per ruolo / libera) + voce. Base (Libera=1 / Quotazione). Tempi. Partecipanti & ordine. Niente budget editabile / flag spendi-tutto / conduttore (ruolo runtime).
- **S-tabellone** (desktop, `tabellone_desktop.html`) — plancia broadcast: hero 3 zone (giocatore+base oro / timer / comandi banditore con voce) + board 8 squadre (rose 25) + ticker. **Mostra**, non agisce.
- **S-paletta** (mobile, `paletta_mobile.html`) — coppia del tabellone: badge, timer-barra, offerta oro, "superato", rilanci +1/+5/+10, autobid, Parla, budget+slot.
- **S-feed** (mobile, `feed_home.html`) — gazzetta: testata, card-evento taggate, social leggero, bottom-tab + ☰.
- **S-federazione** (mobile, `federazione_home.html`) — il tuo mondo: hero identità, **albo d'oro**, bacheche, leghe, "Le regole del mondo" (niente mercati).
- **S-dettaglio** (mobile, `lega_dettaglio.html`) — panoramica: sub-nav pills, tua società, prossimo impegno, classifica mini, mercato.
- **S-mercato** (mobile, `lega_mercato.html`) — finestre in scroll, countdown, trattative aperte.
- **S-rosa** (mobile, `lega_rosa.html`) — riepilogo (FM/rosa/completezza) + lista unica di badge-roster; slot liberi visibili.
- **S-scheda** (mobile, `scheda_giocatore.html`) — hero medaglione; contesto-lega; rendimento fanta; statistiche API-Sports; storico stagioni/lega. Larghezza bloccata (R-mobile-nosquish).
- **S-formazione-d** (desktop, `lega_formazione.html`) — topbar+tab; sidebar filtri (ruolo×club) e rosa = **panchina automatica**; campo 4-3-3; **area tecnica** col Mister.
- **S-formazione-m** (mobile, `formazione_mobile.html`) — tab **Campo/Panchina**; sostituzione **a tocco** (titolare → entrante); 14 panchinari; striscia modulo+allenatore. **Interattiva.**
- **S-partita-d** (desktop, `lega_partita.html`) — punteggio; due panchine (barra-panchina) a sx; campo affacciato + due aree tecniche + centrocampo unico; due pagelle a dx. Panche da **14**.
- **S-partita-m** (mobile, `partita_mobile.html`) — punteggio; campo verticale affacciato; sotto, segmentato **Pagelle/Panchine** + selettore **La mia/Avversario**. **Interattiva.**
- **S-classifica** (mobile, `lega_classifica.html`) — tabella **# · Squadra · G · V·N·P · GF · GS · Pt · PF**. Punti/gol inchiostro (non FM).
- **S-hub** (mobile, `lega_hub.html`) — la casa della lega: identità + giornata condivisa, poi **una card per competizione** (stato a colpo d'occhio: estratto classifica per il campionato, **guida a fasi** gironi→tabellone per la coppa). Ogni card chiude con la sua **porta etichettata** ("Classifica completa" / "Vai al tabellone") e ha in alto il suo **tasto calendario**. Pila omogenea che scrolla pulita per N competizioni: niente funzioni di squadra né calendario globale qui.
- **S-classifica-d** (desktop, `classifica_dettaglio.html`) — la **vista larga** della Classifica: colonne piene `G · V · N · P · GF · GS · DR · PF · PT`. Stessa sostanza della mobile, dove c'è spazio per separare ogni colonna (la mobile raggruppa V·N·P e GF-GS).
- **S-gironi** (mobile, `coppa_gironi.html`) — la fase a gironi vista da dentro: **switch di fase** Gironi/Tabellone, classifica di ogni gruppo con le **prime K marcate (Q)**, e il **versamento** — le qualificate raccolte e **incrociate** nelle semifinali (1°A-2°B, 1°B-2°A) coi tag di provenienza. Il salto gironi→tabellone raccontato per esteso.
- **S-bracket-d** (desktop, `bracket_coppa_desktop.html`) — il **tabellone ramificato** vero: turni in colonne, connettori a gomito, spareggio in evidenza, campione col trofeo oro. Dove l'albero respira.
- **S-bracket-m** (mobile, `bracket_coppa_mobile_paged.html`) — lo stesso tabellone **un turno per schermata**: tab + scroll-snap (non analogico), i rami escono dal bordo destro e rientrano da sinistra alla **stessa altezza**, così sfogliando si percorre l'albero. (La versione *funnel* è accantonata.)
- **S-caduta** (mobile, `comp_caduta.html`) — la **sopravvivenza**: contatore "in gioco / cadute" con la fila di pallini (vivi pieni, caduti sbarrati), lista **In gioco** (sopravvissuti col punteggio che li ha salvati) e **Cadute** (in ordine inverso, col tag a freccia-giù della giornata e il punteggio fatale). Promemoria della ghigliottina viva; trofeo oro = l'ultima in piedi.
- **S-wizard-lega / -rosa / -competizioni / -fase / -calendario / -riepilogo** (mobile) — la **configurazione a cascata** (§5): crea lega → budget+rosa (3-8-8-6) → competizioni (preset o composizione delle fasi via **guida a fasi**) → ancoraggio delle fasi alle giornate reali (asta esclusa, è stand-alone) → read-back e "Crea la lega".

---

## 8. Regole trasversali

- **R-oro** — Oro (`T-oro`) solo per denaro/FM/valore/prezzi/prestigio/marchio. Punti fanta, voti, gol, posizioni **non** sono denaro → inchiostro/verde.
- **R-server** — Server-authoritative: ogni vincolo (budget, slot ruolo, finestra, punteggio) è applicato dal server; il client mostra e propone.
- **R-mister-toy** — L'acquaforte del Mister è accento di marca raro; il **badge allenatore** usa l'**avatar toy** (pipeline giocatori), distinto con anello oro.
- **R-rosa** — Rosa = **25** (3P·8D·8C·6A); schieri 11 → panca **14**; in 4-3-3 la panca è 2P·4D·5C·3A.
- **R-classico-gol** — *Parametro di federazione, applicato alle fasi a **misura scontro diretto*** (vedi §5): **non** è una "modalità classico". Il punteggio fanta di **ogni giornata** si converte in **gol** con soglia base + passo, e i **GF/GS** di classifica sono la **somma dei gol per-partita** (fatti/subiti), non una funzione del cumulato. Default classico: `<66 = 0` gol; `66 = 1°` gol; poi `+1` ogni `6` punti → `gol = max(0, floor((punteggio − 60) / 6))` per `punteggio ≥ 66`. Soglia e passo sono **parametri di federazione** (configurabili), non hardcodati. **Presentazione**: a misura scontro diretto si racconta il **risultato in gol** (sintetico) — vincitore/pareggio e margine si leggono **dai gol**, coerenti su Feed/Classifica/Partita (che leggono lo **stesso risultato ufficiale** prodotto una sola volta dalla competizione, **non** un punteggio ricalcolato per-vista); l'**assoluto** (decimali) si mostra solo nei casi-soglia (scarto minimo che ribalta un gol, "vinta per un soffio"). A **misura punteggio assoluto** vale l'opposto: l'assoluto *è* il risultato. **PF** = punteggio fanta **cumulato** (spareggio); è il campo che alcune API espongono come `goalsFor` → mapparlo su PF, **non** su GF.
- **R-mobile-nosquish** — Telefono a larghezza fissa `--phone-w` + `body{overflow-x:auto}`; **mai** `max-width:100%`; scrollbar sotto-nav nascosta.
- **R-marcature** — Centrocampo testa-a-testa = **un solo** elemento sul confine; metà disegnano solo porte/lati; campo alto a sufficienza; corridoio per gli attaccanti.
- **R-crest** — **Marchio club ≠ disco squadra fanta.** Il **club reale** del giocatore = **logo reale** del club (da API-Football) in contenitore neutro **tondo** (cerchio, forma uniforme su tutte le schermate), con **monogramma di fallback** se il logo manca. La **squadra fanta** = **disco-monogramma** col suo `team.color` (non ha un logo reale). I due **non** sono intercambiabili: il logo-club appare sul giocatore (rosa, scheda, asta/tabellone), il disco-squadra sull'owner/competizione (Feed, Classifica, dettaglio). Nota IP: l'uso dei loghi reali è una scelta di rischio accettata (vedi §10), da rivalutare alla monetizzazione. Nei **mockup statici** (senza API) il crest-club resta placeholder bicolore.
- **R-spareggio** — Serve solo dove un vincitore è **obbligatorio**: struttura **tabellone**, e **caduta** quando due pareggiano per l'ultimo posto. Nella struttura **classifica** il pari resta pari. **Supplementari** = mini-partita coi **primi panchinari con voto per reparto** (1 D, 1 C, 1 A, niente portiere), sommati e convertiti in gol; se il primo di un reparto non ha voto, **si scala al successivo valido**. **Rigori** (se ancora pari) = voto netto ≥ 6 = segnato, in ordine di panchina, 5 a testa poi a oltranza; chi non ha voto si salta. Se in un reparto/serie **non si trova alcun valido**, si assegna un **voto d'ufficio configurabile** (default `5,5`).
- **R-fonte-strato** — Ogni strato ha una sola fonte per il suo dato; gli strati sotto leggono/congelano snapshot, non duplicano.
- **R-fasi** — Una **competizione è una sequenza ordinata di fasi**; ogni fase è **misura × struttura** e ogni fase non-finale dichiara la sua **qualificazione** (vedi §5). I formati noti sono combinazioni, non scatole. La sequenza si **vede e si tocca** tramite `C-guida-fasi` (hub, wizard) e si percorre nelle rese (gironi → tabellone). L'agente implementa il modello a fasi, non i singoli formati hardcodati.
- **R-classifica-adattiva** — La Classifica è **un solo telaio** (posizione · disco-squadra · nome · spareggi · metrica-chiave · riga propria evidenziata); **colonne e criteri di ordinamento sono una configurazione della fase**, dettati dalla **misura**: *scontro diretto* → V·N·P, GF/GS, DR, **PT** (spareggi Pt→DR→GF→PF); *punteggio assoluto* → **Totale** (PF), spareggio media; *posizione/F1* → **Punti gara**, spareggio vittorie di giornata. **PF** e **PT** restano sempre presenti. **Resa mobile** (`S-classifica`): per stare a 390px, **V·N·P** si raggruppa in una cella e **GF-GS** in un'altra; la **desktop** (`S-classifica-d`) le apre tutte. Niente oro su punti/gol/posizioni (R-oro).
- **R-icona-tipo** — L'icona di una competizione indica il suo **tipo per struttura** (classifica → lista; tabellone → forcella; caduta → la sua; F1 → bandiera), **dedotta** dal modello a fasi: deterministica, comunica il formato, zero asset. Il **logo** della competizione è uno **strato opzionale** sopra (se il creatore ne carica uno), con **fallback all'icona di tipo** — stesso schema di `R-crest`. Conseguenza R-oro: l'icona-struttura della coppa è una **forcella verde**, **non** un trofeo oro; l'oro resta sul trofeo del **campione**.

---

## 9. Matrice di propagazione (generata da `registro.json`)

*Non modificare a mano: rigenerata da `genera.py`. Per cambiare le relazioni si edita `registro.json`.*

### 9.1 Token → componenti → schermate

| Token | Componenti che lo usano | Schermate impattate |
|---|---|---|
| `T-carta` --cream/--cream2/--paper | — | **tutte** |
| `T-verde` --green/-d/-l | C-card-evento, C-classifica-row, C-barra-panchina, C-guida-fasi, C-bracket | **tutte** |
| `T-erba` --pitch/--pitch2 | C-area-tecnica, C-marcature | S-formazione-d, S-formazione-m, S-partita-d, S-partita-m |
| `T-oro` --gold/--gold-l | C-badge, C-area-tecnica, C-card-evento, C-barra-panchina, C-bracket | S-bracket-d, S-bracket-m, S-config-asta, S-feed, S-formazione-d, S-formazione-m, S-gironi, S-paletta, S-partita-d, S-partita-m, S-rosa, S-scheda, S-tabellone |
| `T-live` --live | C-card-evento, C-classifica-row, C-bracket | S-bracket-d, S-bracket-m, S-caduta, S-classifica, S-classifica-d, S-dettaglio, S-feed, S-gironi, S-hub |
| `T-neutri` --muted/--line | C-guida-fasi | **tutte** |
| `T-ruolo` --rP/D/C/A + --ring* + --let* | C-badge, C-classifica-row | S-caduta, S-classifica, S-classifica-d, S-config-asta, S-dettaglio, S-formazione-d, S-formazione-m, S-gironi, S-hub, S-paletta, S-partita-d, S-partita-m, S-rosa, S-scheda, S-tabellone |
| `T-club` mappa colori club (bicolore) | C-badge, C-crest, C-classifica-row, C-bracket | S-bracket-d, S-bracket-m, S-caduta, S-classifica, S-classifica-d, S-config-asta, S-dettaglio, S-federazione, S-feed, S-formazione-d, S-formazione-m, S-gironi, S-hub, S-mercato, S-paletta, S-partita-d, S-partita-m, S-rosa, S-scheda, S-tabellone |
| `T-font` --disp / --mono | C-badge, C-area-tecnica, C-card-evento, C-classifica-row, C-barra-panchina, C-guida-fasi, C-bracket | **tutte** |
| `T-phone` --phone-w + no-squish | — | — |

### 9.2 Componente → schermate

| Componente | Schermate |
|---|---|
| C-badge (Badge giocatore) | S-config-asta, S-tabellone, S-paletta, S-rosa, S-scheda, S-formazione-d, S-formazione-m, S-partita-d, S-partita-m |
| C-crest (Crest bicolore) | S-tabellone, S-feed, S-federazione, S-hub, S-dettaglio, S-mercato, S-rosa, S-scheda, S-formazione-d, S-formazione-m, S-partita-d, S-partita-m, S-classifica, S-gironi, S-bracket-d, S-bracket-m, S-caduta |
| C-area-tecnica (Area tecnica) | S-formazione-d, S-partita-d, S-partita-m |
| C-marcature (Marcature campo) | S-formazione-d, S-formazione-m, S-partita-d, S-partita-m |
| C-card-evento (Card-evento) | S-feed |
| C-classifica-row (Riga classifica) | S-hub, S-dettaglio, S-classifica, S-classifica-d, S-gironi, S-caduta |
| C-barra-panchina (Barra-panchina) | S-partita-d |
| C-guida-fasi (Guida a fasi) | S-hub, S-wizard-competizioni, S-wizard-fase, S-wizard-riepilogo |
| C-bracket (Tabellone (rami)) | S-gironi, S-bracket-d, S-bracket-m |

### 9.3 Regola → ambito

| Regola | Ambito |
|---|---|
| R-oro — Oro riservato a denaro/valore | **tutte le schermate** |
| R-server — Server-authoritative | **tutte le schermate** |
| R-fonte-strato — Una fonte per strato | **tutte le schermate** |
| R-fasi — Competizione = sequenza di fasi (misura × struttura × qualificazione) | S-hub, S-gironi, S-bracket-d, S-bracket-m, S-caduta, S-classifica, S-classifica-d, S-wizard-competizioni, S-wizard-fase, S-wizard-calendario, S-wizard-riepilogo |
| R-mister-toy — Mister inciso != allenatore (toy) | C-area-tecnica |
| R-rosa — Rosa 25 / panca 14 | S-rosa, S-formazione-d, S-formazione-m, S-partita-d, S-partita-m, S-wizard-rosa |
| R-classico-gol — Conversione GF/GS (misura scontro diretto) | S-classifica, S-classifica-d, S-partita-d, S-partita-m, S-gironi, S-bracket-d, S-bracket-m |
| R-classifica-adattiva — Classifica adattiva: colonne/criteri = misura della fase | S-classifica, S-classifica-d |
| R-icona-tipo — Icona competizione = struttura (logo opzionale, fallback icona) | S-hub, S-wizard-competizioni |
| R-mobile-nosquish — 390px fisso + scroll | S-paletta, S-feed, S-hub, S-federazione, S-dettaglio, S-mercato, S-rosa, S-scheda, S-formazione-m, S-partita-m, S-classifica, S-gironi, S-bracket-m, S-caduta, S-wizard-lega, S-wizard-rosa, S-wizard-competizioni, S-wizard-fase, S-wizard-calendario, S-wizard-riepilogo |
| R-marcature — Centrocampo unico testa-a-testa | C-marcature, S-partita-d, S-partita-m |
| R-crest — Logo club reale vs disco squadra fanta | C-crest |
| R-spareggio — Supplementari e rigori (eliminazione) | S-bracket-d, S-bracket-m, S-caduta, S-partita-d, S-partita-m |

---

## 10. Stato & pendenze

**Fatto (mockup):** token + `propaga.py`, libreria componenti, mappa-guscio, **26 schermate** (desktop/mobile), brand, documento modulare + registro + `genera.py`. **Competizioni a fasi** consolidate: hub di lega, classifica adattiva (mobile raggruppata + dettaglio desktop), tabellone coppa (ramificato desktop + paginato mobile), gironi→tabellone, caduta; **wizard** di configurazione in 5 step. Componenti nuovi: `C-guida-fasi`, `C-bracket`.

**Decisioni di questo giro (a verbale):**
- **Icona competizione** (`R-icona-tipo`): icona **di tipo per struttura** + logo opzionale come strato (fallback all'icona). La coppa passa da trofeo-oro a **forcella verde** (l'oro resta sul campione).
- **Tabellone mobile**: la forma canonica è il **paginato** (un turno/schermata); il *funnel* è accantonato (resta come alternativa, non nel prodotto).
- **Calendario**: niente vista globale nell'hub; ogni competizione ha il **suo** tasto calendario. La vista combinata cross-competizione (con URL pubblico + iCal) resta idea futura, eventualmente agganciata all'indicatore di giornata.


**Da fare / decidere:**
- **[PARZIALE]** Componenti a fonte unica: `componenti.py` centralizza già **volto + colori club + logica colore** e i `build_*.py` lo importano (rigenerazione verificata byte-identica). Resta da migrare il **markup del chip** al generatore canonico `badge()` (incrementale, per non regredire le viste approvate).
- Classifica: viste sorelle **Marcatori** / **Andamento** (se servono; marcatori per giocatore reale o squadra fanta).
- Vincolo di ruolo nello scambio Formazione mobile (oggi permissivo).
- Sostituzione segnaposto: volti toy reali, dati API-Sports. **Loghi club reali: adottati** (vedi `R-crest`) — scelta di rischio IP accettata, da rivalutare alla monetizzazione.
- Pre-deploy (fuori dal giro design): `JWT_SECRET` reale (≥32), copy/i18n, fix logo-login, magic-link + Google OAuth, fondamenta brand.

**Idee future:**
- **Vista calendario** della stagione (fasi sulle giornate reali) come artefatto consultabile, con **URL pubblico** e sincronizzazione **iCal** verso il calendario personale.
- **Supercoppa** e simili: competizioni i cui ingressi vengono dai vincitori di altre competizioni (qualificazione cross-competizione) — richiede di estendere il modello a fasi.
- **Divisioni** (promozioni/retrocessioni tra leghe).

---

## 11. Allegati

(Esclusi i file di processo: brief/checkpoint/diagnostiche all'agente.)

**Sistema / riferimento:** `tokens.css` (token) · `propaga.py` (compilatore token) · `componenti.py` (fonte unica componenti: volto, club, logica colore, `badge()`) · `registro.json` (grafo) · `genera.py` (validatore+generatore) · `spec/` (moduli) · `mister_spec.md` (assemblato) · `libreria_componenti.html` · `lingua_visiva.html` · `mappa_guscio.html`.

**Desktop:** `config_asta.html` · `tabellone_desktop.html` · `lega_formazione.html` · `lega_partita.html`.

**Mobile:** `feed_home.html` · `federazione_home.html` · `lega_dettaglio.html` · `lega_mercato.html` · `lega_rosa.html` · `scheda_giocatore.html` · `paletta_mobile.html` · `formazione_mobile.html` · `partita_mobile.html` · `lega_classifica.html`.

**Brand:** `mister_brand.zip`.

---

## 12. Brief di integrazione (per l'agente Replit) — generato da `registro.json`

*Per schermata: componenti · regole da far rispettare lato server · dati · azioni. Generato; non modificare a mano.*

### Sequenza di cablaggio consigliata
1. **Sblocco** pendenze pre-deploy (login/magic-link + OAuth, `JWT_SECRET`, copy/i18n) — vedi modulo 10.
2. **Quick-win in lettura**: `S-classifica`, poi `S-feed`.
3. **Milestone asta** (real-time, server-authoritative): `S-config-asta` → `S-tabellone` + `S-paletta`.
4. **Competizioni**: telaio `S-hub` → dentro, classifica adattiva (`S-classifica`/`S-classifica-d`), tabellone (`S-bracket-d`/`S-bracket-m`), gironi che versano nel tabellone (`S-gironi`), caduta (`S-caduta`).
5. **Configurazione**: wizard `S-wizard-lega` → `-rosa` → `-competizioni`/`-fase` → `-calendario` → `-riepilogo` (genera la lega e le sue competizioni a fasi).
6. **Il resto**: `S-rosa`, `S-scheda`, `S-formazione-d/m`, `S-partita-d/m`, `S-dettaglio`, `S-mercato`, `S-federazione`.

### Regole globali (ogni schermata)
- R-oro (Oro riservato a denaro/valore) · R-server (Server-authoritative) · R-fonte-strato (Una fonte per strato)

#### S-config-asta — Configurazione asta (desktop · `config_asta.html`)
- **Componenti**: C-badge
- **Regole server**: solo globali
- **Dati**: regole ereditate dalla lega (budget, struttura rosa 3-8-8-6, mode) read-only; finestra = Asta iniziale; elenco partecipanti; ordine di chiamata
- **Azioni**: legge regole-lega (sola lettura, link a Regole di lega); scrive config asta (formato, svolgimento, base, tempi, ordine); avvia asta -> crea sessione live

#### S-tabellone — Tabellone live (desktop · `tabellone_desktop.html`)
- **Componenti**: C-badge, C-crest
- **Regole server**: R-crest
- **Dati**: stato asta live (giocatore corrente, base, offerta+team, timer); board 8 squadre (budget, slot, rose 25); ticker ultimi colpi
- **Azioni**: banditore: chiama giocatore (ricerca fuzzy), aggiudica, prossimo, pausa, annulla; riceve eventi real-time; SOLO mostra le offerte (non rilancia)

#### S-paletta — Paletta asta (mobile · `paletta_mobile.html`)
- **Componenti**: C-badge
- **Regole server**: R-mobile-nosquish
- **Dati**: giocatore in asta; mia offerta / stato 'superato'; budget e slot mancanti
- **Azioni**: rilancia +1/+5/+10 e 'a X'; autobid (offerta max); parla (voce); real-time col tabellone

#### S-feed — Feed / Home (mobile · `feed_home.html`)
- **Componenti**: C-card-evento, C-crest
- **Regole server**: R-mobile-nosquish, R-crest
- **Dati**: eventi di sistema (asta-live, colpi, trattative, risultati, finestre, albo) taggati per lega/federazione; reazioni/commenti
- **Azioni**: legge feed paginato; reagisce/commenta (ancorato all'evento); tap evento -> naviga al contesto

#### S-federazione — Federazione (mobile · `federazione_home.html`)
- **Componenti**: C-crest
- **Regole server**: R-mobile-nosquish, R-crest
- **Dati**: identità (nome, stemma, motto, numeri); albo d'oro (campioni per stagione); bacheche titoli per società; leghe della federazione; regole del mondo (mode, algoritmo voto, punteggio/ruoli, convalida)
- **Azioni**: legge identità/albo/regole; (owner) governance e modifica regole

#### S-hub — Hub di lega (mobile · `lega_hub.html`)
- **Componenti**: C-guida-fasi, C-classifica-row, C-crest
- **Regole server**: R-fasi, R-icona-tipo, R-mobile-nosquish, R-crest
- **Dati**: competizioni della lega (tipo/struttura, stato, fase corrente); tua posizione sintetica per competizione; giornata corrente condivisa; ingresso calendario per-competizione
- **Azioni**: entra nella competizione (classifica/tabellone); apre il calendario della competizione; si impila per N competizioni

#### S-dettaglio — Dettaglio lega (mobile · `lega_dettaglio.html`)
- **Componenti**: C-classifica-row, C-crest
- **Regole server**: R-mobile-nosquish, R-crest
- **Dati**: tua società (budget, posizione, rosa); prossimo impegno; classifica mini; mercato (finestra, tipi, trattative)
- **Azioni**: legge panoramica; naviga sub-nav (Rosa/Formazione/Mercato/Classifica/Società)

#### S-mercato — Mercato (mobile · `lega_mercato.html`)
- **Componenti**: C-crest
- **Regole server**: R-mobile-nosquish, R-crest
- **Dati**: finestre (stato conclusa/programmata, date); countdown prossima finestra; trattative aperte
- **Azioni**: legge ritmo finestre; apre trattativa (si concretizza all'apertura della finestra)

#### S-rosa — Rosa (mobile · `lega_rosa.html`)
- **Componenti**: C-badge, C-crest
- **Regole server**: R-rosa, R-mobile-nosquish, R-crest
- **Dati**: rosa (giocatori: ruolo, club, quotazione, pagato); riepilogo FM liberi / completezza per ruolo; slot liberi
- **Azioni**: legge rosa e riepilogo

#### S-scheda — Scheda giocatore (mobile · `scheda_giocatore.html`)
- **Componenti**: C-badge, C-crest
- **Regole server**: R-mobile-nosquish, R-crest
- **Dati**: anagrafica (sistema); contesto-lega (quotazione, pagato, proprietario); rendimento fanta (fantamedia, presenze, ultime giornate); statistiche API-Sports (per ruolo); storico stagioni e storico in lega
- **Azioni**: legge (aggrega dato di sistema + dato di lega)

#### S-formazione-d — Formazione (desktop · `lega_formazione.html`)
- **Componenti**: C-badge, C-crest, C-area-tecnica, C-marcature
- **Regole server**: R-mister-toy, R-rosa, R-marcature, R-crest
- **Dati**: rosa + panchina (panchina = non schierati); modulo; contesto-giornata e scadenza; allenatore
- **Azioni**: schiera/sostituisce, imposta capitano; salva formazione (server valida ruoli-slot, completezza, scadenza)

#### S-formazione-m — Formazione (mobile · `formazione_mobile.html`)
- **Componenti**: C-badge, C-crest, C-marcature
- **Regole server**: R-rosa, R-mobile-nosquish, R-marcature, R-crest
- **Dati**: XI + 14 panchinari; modulo + allenatore; scadenza
- **Azioni**: tab Campo/Panchina; sostituzione a tocco (titolare -> entrante); salva (stesse validazioni server della desktop)

#### S-partita-d — Partita (desktop · `lega_partita.html`)
- **Componenti**: C-badge, C-crest, C-area-tecnica, C-marcature, C-barra-panchina
- **Regole server**: R-mister-toy, R-rosa, R-classico-gol, R-marcature, R-crest, R-spareggio
- **Dati**: due squadre (XI + panchine da 14); voti/pagelle (S.V. finché non arrivano); totali, GF/GS; allenatori
- **Azioni**: legge tabellino e campo affacciato; (live) aggiorna voti man mano che arrivano

#### S-partita-m — Partita (mobile · `partita_mobile.html`)
- **Componenti**: C-badge, C-crest, C-area-tecnica, C-marcature
- **Regole server**: R-mister-toy, R-rosa, R-classico-gol, R-mobile-nosquish, R-marcature, R-crest, R-spareggio
- **Dati**: due squadre (campo affacciato); pagelle e panchine per squadra; totali
- **Azioni**: legge; segmentato Pagelle/Panchine + selettore La mia/Avversario

#### S-classifica — Classifica (mobile · `lega_classifica.html`)
- **Componenti**: C-classifica-row, C-crest
- **Regole server**: R-fasi, R-classico-gol, R-classifica-adattiva, R-mobile-nosquish, R-crest
- **Dati**: standings per squadra (G,V,N,P,GF,GS,Pt,PF, movimento); competizione e giornata
- **Azioni**: legge la graduatoria della competizione; resa mobile: V·N·P e GF-GS raggruppate in una cella ciascuna (PF+PT sempre presenti)

#### S-classifica-d — Classifica (dettaglio) (desktop · `classifica_dettaglio.html`)
- **Componenti**: C-classifica-row
- **Regole server**: R-fasi, R-classico-gol, R-classifica-adattiva
- **Dati**: standings a colonne piene (G·V·N·P·GF·GS·DR·PF·PT); competizione e giornata
- **Azioni**: legge la classifica dettagliata (vista larga della Classifica mobile)

#### S-gironi — Gironi (coppa) (mobile · `coppa_gironi.html`)
- **Componenti**: C-classifica-row, C-crest, C-bracket
- **Regole server**: R-fasi, R-classico-gol, R-mobile-nosquish, R-crest
- **Dati**: classifica di ogni girone; criterio di qualificazione (primi K); accoppiamenti incrociati derivati (1°A-2°B, 1°B-2°A); fase attiva
- **Azioni**: switch fase Gironi/Tabellone; legge i gruppi con le qualificate marcate; va al tabellone

#### S-bracket-d — Tabellone coppa (desktop · `bracket_coppa_desktop.html`)
- **Componenti**: C-bracket, C-crest
- **Regole server**: R-fasi, R-classico-gol, R-crest, R-spareggio
- **Dati**: tabellone ramificato (turni, match con risultato in gol, spareggio); campione
- **Azioni**: legge l'albero ramificato; (live) i turni si riempiono man mano

#### S-bracket-m — Tabellone coppa (mobile · `bracket_coppa_mobile_paged.html`)
- **Componenti**: C-bracket, C-crest
- **Regole server**: R-fasi, R-classico-gol, R-mobile-nosquish, R-crest, R-spareggio
- **Dati**: stesso tabellone, un turno per schermata; i rami escono/entrano alla stessa altezza tra schermate
- **Azioni**: sfoglia i turni (tab + scroll-snap, non analogico); legge

#### S-caduta — Sopravvivenza (caduta) (mobile · `comp_caduta.html`)
- **Componenti**: C-classifica-row, C-crest
- **Regole server**: R-fasi, R-mobile-nosquish, R-crest, R-spareggio
- **Dati**: stato sopravvivenza: in gioco / cadute (giornata + punteggio fatale); quanti escono per giornata; soglia di giornata in corso
- **Azioni**: legge chi è vivo e chi è caduto e quando

#### S-wizard-lega — Wizard 1 — Lega (mobile · `wizard_lega.html`)
- **Componenti**: —
- **Regole server**: R-mobile-nosquish
- **Dati**: nome lega; federazione (eredita le regole del mondo)
- **Azioni**: crea/identifica la lega

#### S-wizard-rosa — Wizard 2 — Budget & rosa (mobile · `wizard_rosa_budget.html`)
- **Componenti**: —
- **Regole server**: R-rosa, R-mobile-nosquish
- **Dati**: budget in FM; struttura rosa 25 = 3-8-8-6
- **Azioni**: imposta budget e struttura rosa

#### S-wizard-competizioni — Wizard 3 — Competizioni (mobile · `wizard_competizioni.html`)
- **Componenti**: C-guida-fasi
- **Regole server**: R-fasi, R-icona-tipo, R-mobile-nosquish
- **Dati**: lista competizioni = pile di fasi; preset (campionato/coppa) o composizione a mano
- **Azioni**: aggiunge competizioni; compone le fasi (misura × struttura)

#### S-wizard-fase — Wizard 3b — Fase (mobile · `wizard_fase.html`)
- **Componenti**: C-guida-fasi
- **Regole server**: R-fasi, R-mobile-nosquish
- **Dati**: misura × struttura × qualificazione della singola fase; sub-config che si aprono
- **Azioni**: configura la fase; dichiara la qualificazione (chi passa)

#### S-wizard-calendario — Wizard 4 — Calendario (mobile · `wizard_calendario.html`)
- **Componenti**: —
- **Regole server**: R-fasi, R-mobile-nosquish
- **Dati**: fasi ancorate alle giornate reali di Serie A; durata derivata dalla config
- **Azioni**: ancora ogni fase alla giornata di partenza; l'asta resta evento stand-alone (non qui)

#### S-wizard-riepilogo — Wizard 5 — Riepilogo (mobile · `wizard_riepilogo.html`)
- **Componenti**: C-guida-fasi
- **Regole server**: R-fasi, R-mobile-nosquish
- **Dati**: read-back di lega + competizioni + fasi + calendario
- **Azioni**: crea la lega
