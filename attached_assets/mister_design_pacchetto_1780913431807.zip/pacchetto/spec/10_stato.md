## 10. Stato & pendenze

**Fatto (mockup):** token + `propaga.py`, libreria componenti, mappa-guscio, **26 schermate** (desktop/mobile), brand, documento modulare + registro + `genera.py`. **Competizioni a fasi** consolidate: hub di lega, classifica adattiva (mobile raggruppata + dettaglio desktop), tabellone coppa (ramificato desktop + paginato mobile), gironi→tabellone, caduta; **wizard** di configurazione in 5 step. Componenti nuovi: `C-guida-fasi`, `C-bracket`.

**Decisioni di questo giro (a verbale):**
- **Icona competizione** (`R-icona-tipo`): icona **di tipo per struttura** + logo opzionale come strato (fallback all'icona). La coppa passa da trofeo-oro a **forcella verde** (l'oro resta sul campione).
- **Tabellone mobile**: la forma canonica è il **paginato** (un turno/schermata); il *funnel* è accantonato (resta come alternativa, non nel prodotto).
- **Calendario**: niente vista globale nell'hub; ogni competizione ha il **suo** tasto calendario. La vista combinata cross-competizione (con URL pubblico + iCal) resta idea futura, eventualmente agganciata all'indicatore di giornata.


**Da fare / decidere:**
- **[PARZIALE]** Componenti a fonte unica: `componenti.py` centralizza già **volto + colori club + logica colore** e i `build_*.py` lo importano (rigenerazione verificata byte-identica). Resta da migrare il **markup del chip** al generatore canonico `badge()` (incrementale, per non regredire le viste approvate).
- Classifica: viste sorelle **Marcatori** / **Andamento** (se servono; marcatori per giocatore reale o squadra fanta).
- Vincolo di ruolo nello scambio Formazione mobile (oggi permissivo).
- Sostituzione segnaposto: volti toy reali, dati API-Sports. **Loghi club reali: adottati** (vedi `R-crest`) — scelta di rischio IP accettata, da rivalutare alla monetizzazione.
- Pre-deploy (fuori dal giro design): `JWT_SECRET` reale (≥32), copy/i18n, fix logo-login, magic-link + Google OAuth, fondamenta brand.

**Idee future:**
- **Vista calendario** della stagione (fasi sulle giornate reali) come artefatto consultabile, con **URL pubblico** e sincronizzazione **iCal** verso il calendario personale.
- **Supercoppa** e simili: competizioni i cui ingressi vengono dai vincitori di altre competizioni (qualificazione cross-competizione) — richiede di estendere il modello a fasi.
- **Divisioni** (promozioni/retrocessioni tra leghe).
