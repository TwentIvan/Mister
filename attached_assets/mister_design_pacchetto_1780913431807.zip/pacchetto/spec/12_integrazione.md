## 12. Brief di integrazione (per l'agente Replit) — generato da `registro.json`

*Per schermata: componenti · regole da far rispettare lato server · dati · azioni. Generato; non modificare a mano.*

### Sequenza di cablaggio consigliata
1. **Sblocco** pendenze pre-deploy (login/magic-link + OAuth, `JWT_SECRET`, copy/i18n) — vedi modulo 10.
2. **Quick-win in lettura**: `S-classifica`, poi `S-feed`.
3. **Milestone asta** (real-time, server-authoritative): `S-config-asta` → `S-tabellone` + `S-paletta`.
4. **Competizioni**: telaio `S-hub` → dentro, classifica adattiva (`S-classifica`/`S-classifica-d`), tabellone (`S-bracket-d`/`S-bracket-m`), gironi che versano nel tabellone (`S-gironi`), caduta (`S-caduta`).
5. **Configurazione**: wizard `S-wizard-lega` → `-rosa` → `-competizioni`/`-fase` → `-calendario` → `-riepilogo` (genera la lega e le sue competizioni a fasi).
6. **Il resto**: `S-rosa`, `S-scheda`, `S-formazione-d/m`, `S-partita-d/m`, `S-dettaglio`, `S-mercato`, `S-federazione`.

### Regole globali (ogni schermata)
- R-oro (Oro riservato a denaro/valore) · R-server (Server-authoritative) · R-fonte-strato (Una fonte per strato)

#### S-config-asta — Configurazione asta (desktop · `config_asta.html`)
- **Componenti**: C-badge
- **Regole server**: solo globali
- **Dati**: regole ereditate dalla lega (budget, struttura rosa 3-8-8-6, mode) read-only; finestra = Asta iniziale; elenco partecipanti; ordine di chiamata
- **Azioni**: legge regole-lega (sola lettura, link a Regole di lega); scrive config asta (formato, svolgimento, base, tempi, ordine); avvia asta -> crea sessione live

#### S-tabellone — Tabellone live (desktop · `tabellone_desktop.html`)
- **Componenti**: C-badge, C-crest
- **Regole server**: R-crest
- **Dati**: stato asta live (giocatore corrente, base, offerta+team, timer); board 8 squadre (budget, slot, rose 25); ticker ultimi colpi
- **Azioni**: banditore: chiama giocatore (ricerca fuzzy), aggiudica, prossimo, pausa, annulla; riceve eventi real-time; SOLO mostra le offerte (non rilancia)

#### S-paletta — Paletta asta (mobile · `paletta_mobile.html`)
- **Componenti**: C-badge
- **Regole server**: R-mobile-nosquish
- **Dati**: giocatore in asta; mia offerta / stato 'superato'; budget e slot mancanti
- **Azioni**: rilancia +1/+5/+10 e 'a X'; autobid (offerta max); parla (voce); real-time col tabellone

#### S-feed — Feed / Home (mobile · `feed_home.html`)
- **Componenti**: C-card-evento, C-crest
- **Regole server**: R-mobile-nosquish, R-crest
- **Dati**: eventi di sistema (asta-live, colpi, trattative, risultati, finestre, albo) taggati per lega/federazione; reazioni/commenti
- **Azioni**: legge feed paginato; reagisce/commenta (ancorato all'evento); tap evento -> naviga al contesto

#### S-federazione — Federazione (mobile · `federazione_home.html`)
- **Componenti**: C-crest
- **Regole server**: R-mobile-nosquish, R-crest
- **Dati**: identità (nome, stemma, motto, numeri); albo d'oro (campioni per stagione); bacheche titoli per società; leghe della federazione; regole del mondo (mode, algoritmo voto, punteggio/ruoli, convalida)
- **Azioni**: legge identità/albo/regole; (owner) governance e modifica regole

#### S-hub — Hub di lega (mobile · `lega_hub.html`)
- **Componenti**: C-guida-fasi, C-classifica-row, C-crest
- **Regole server**: R-fasi, R-icona-tipo, R-mobile-nosquish, R-crest
- **Dati**: competizioni della lega (tipo/struttura, stato, fase corrente); tua posizione sintetica per competizione; giornata corrente condivisa; ingresso calendario per-competizione
- **Azioni**: entra nella competizione (classifica/tabellone); apre il calendario della competizione; si impila per N competizioni

#### S-dettaglio — Dettaglio lega (mobile · `lega_dettaglio.html`)
- **Componenti**: C-classifica-row, C-crest
- **Regole server**: R-mobile-nosquish, R-crest
- **Dati**: tua società (budget, posizione, rosa); prossimo impegno; classifica mini; mercato (finestra, tipi, trattative)
- **Azioni**: legge panoramica; naviga sub-nav (Rosa/Formazione/Mercato/Classifica/Società)

#### S-mercato — Mercato (mobile · `lega_mercato.html`)
- **Componenti**: C-crest
- **Regole server**: R-mobile-nosquish, R-crest
- **Dati**: finestre (stato conclusa/programmata, date); countdown prossima finestra; trattative aperte
- **Azioni**: legge ritmo finestre; apre trattativa (si concretizza all'apertura della finestra)

#### S-rosa — Rosa (mobile · `lega_rosa.html`)
- **Componenti**: C-badge, C-crest
- **Regole server**: R-rosa, R-mobile-nosquish, R-crest
- **Dati**: rosa (giocatori: ruolo, club, quotazione, pagato); riepilogo FM liberi / completezza per ruolo; slot liberi
- **Azioni**: legge rosa e riepilogo

#### S-scheda — Scheda giocatore (mobile · `scheda_giocatore.html`)
- **Componenti**: C-badge, C-crest
- **Regole server**: R-mobile-nosquish, R-crest
- **Dati**: anagrafica (sistema); contesto-lega (quotazione, pagato, proprietario); rendimento fanta (fantamedia, presenze, ultime giornate); statistiche API-Sports (per ruolo); storico stagioni e storico in lega
- **Azioni**: legge (aggrega dato di sistema + dato di lega)

#### S-formazione-d — Formazione (desktop · `lega_formazione.html`)
- **Componenti**: C-badge, C-crest, C-area-tecnica, C-marcature
- **Regole server**: R-mister-toy, R-rosa, R-marcature, R-crest
- **Dati**: rosa + panchina (panchina = non schierati); modulo; contesto-giornata e scadenza; allenatore
- **Azioni**: schiera/sostituisce, imposta capitano; salva formazione (server valida ruoli-slot, completezza, scadenza)

#### S-formazione-m — Formazione (mobile · `formazione_mobile.html`)
- **Componenti**: C-badge, C-crest, C-marcature
- **Regole server**: R-rosa, R-mobile-nosquish, R-marcature, R-crest
- **Dati**: XI + 14 panchinari; modulo + allenatore; scadenza
- **Azioni**: tab Campo/Panchina; sostituzione a tocco (titolare -> entrante); salva (stesse validazioni server della desktop)

#### S-partita-d — Partita (desktop · `lega_partita.html`)
- **Componenti**: C-badge, C-crest, C-area-tecnica, C-marcature, C-barra-panchina
- **Regole server**: R-mister-toy, R-rosa, R-classico-gol, R-marcature, R-crest, R-spareggio
- **Dati**: due squadre (XI + panchine da 14); voti/pagelle (S.V. finché non arrivano); totali, GF/GS; allenatori
- **Azioni**: legge tabellino e campo affacciato; (live) aggiorna voti man mano che arrivano

#### S-partita-m — Partita (mobile · `partita_mobile.html`)
- **Componenti**: C-badge, C-crest, C-area-tecnica, C-marcature
- **Regole server**: R-mister-toy, R-rosa, R-classico-gol, R-mobile-nosquish, R-marcature, R-crest, R-spareggio
- **Dati**: due squadre (campo affacciato); pagelle e panchine per squadra; totali
- **Azioni**: legge; segmentato Pagelle/Panchine + selettore La mia/Avversario

#### S-classifica — Classifica (mobile · `lega_classifica.html`)
- **Componenti**: C-classifica-row, C-crest
- **Regole server**: R-fasi, R-classico-gol, R-classifica-adattiva, R-mobile-nosquish, R-crest
- **Dati**: standings per squadra (G,V,N,P,GF,GS,Pt,PF, movimento); competizione e giornata
- **Azioni**: legge la graduatoria della competizione; resa mobile: V·N·P e GF-GS raggruppate in una cella ciascuna (PF+PT sempre presenti)

#### S-classifica-d — Classifica (dettaglio) (desktop · `classifica_dettaglio.html`)
- **Componenti**: C-classifica-row
- **Regole server**: R-fasi, R-classico-gol, R-classifica-adattiva
- **Dati**: standings a colonne piene (G·V·N·P·GF·GS·DR·PF·PT); competizione e giornata
- **Azioni**: legge la classifica dettagliata (vista larga della Classifica mobile)

#### S-gironi — Gironi (coppa) (mobile · `coppa_gironi.html`)
- **Componenti**: C-classifica-row, C-crest, C-bracket
- **Regole server**: R-fasi, R-classico-gol, R-mobile-nosquish, R-crest
- **Dati**: classifica di ogni girone; criterio di qualificazione (primi K); accoppiamenti incrociati derivati (1°A-2°B, 1°B-2°A); fase attiva
- **Azioni**: switch fase Gironi/Tabellone; legge i gruppi con le qualificate marcate; va al tabellone

#### S-bracket-d — Tabellone coppa (desktop · `bracket_coppa_desktop.html`)
- **Componenti**: C-bracket, C-crest
- **Regole server**: R-fasi, R-classico-gol, R-crest, R-spareggio
- **Dati**: tabellone ramificato (turni, match con risultato in gol, spareggio); campione
- **Azioni**: legge l'albero ramificato; (live) i turni si riempiono man mano

#### S-bracket-m — Tabellone coppa (mobile · `bracket_coppa_mobile_paged.html`)
- **Componenti**: C-bracket, C-crest
- **Regole server**: R-fasi, R-classico-gol, R-mobile-nosquish, R-crest, R-spareggio
- **Dati**: stesso tabellone, un turno per schermata; i rami escono/entrano alla stessa altezza tra schermate
- **Azioni**: sfoglia i turni (tab + scroll-snap, non analogico); legge

#### S-caduta — Sopravvivenza (caduta) (mobile · `comp_caduta.html`)
- **Componenti**: C-classifica-row, C-crest
- **Regole server**: R-fasi, R-mobile-nosquish, R-crest, R-spareggio
- **Dati**: stato sopravvivenza: in gioco / cadute (giornata + punteggio fatale); quanti escono per giornata; soglia di giornata in corso
- **Azioni**: legge chi è vivo e chi è caduto e quando

#### S-wizard-lega — Wizard 1 — Lega (mobile · `wizard_lega.html`)
- **Componenti**: —
- **Regole server**: R-mobile-nosquish
- **Dati**: nome lega; federazione (eredita le regole del mondo)
- **Azioni**: crea/identifica la lega

#### S-wizard-rosa — Wizard 2 — Budget & rosa (mobile · `wizard_rosa_budget.html`)
- **Componenti**: —
- **Regole server**: R-rosa, R-mobile-nosquish
- **Dati**: budget in FM; struttura rosa 25 = 3-8-8-6
- **Azioni**: imposta budget e struttura rosa

#### S-wizard-competizioni — Wizard 3 — Competizioni (mobile · `wizard_competizioni.html`)
- **Componenti**: C-guida-fasi
- **Regole server**: R-fasi, R-icona-tipo, R-mobile-nosquish
- **Dati**: lista competizioni = pile di fasi; preset (campionato/coppa) o composizione a mano
- **Azioni**: aggiunge competizioni; compone le fasi (misura × struttura)

#### S-wizard-fase — Wizard 3b — Fase (mobile · `wizard_fase.html`)
- **Componenti**: C-guida-fasi
- **Regole server**: R-fasi, R-mobile-nosquish
- **Dati**: misura × struttura × qualificazione della singola fase; sub-config che si aprono
- **Azioni**: configura la fase; dichiara la qualificazione (chi passa)

#### S-wizard-calendario — Wizard 4 — Calendario (mobile · `wizard_calendario.html`)
- **Componenti**: —
- **Regole server**: R-fasi, R-mobile-nosquish
- **Dati**: fasi ancorate alle giornate reali di Serie A; durata derivata dalla config
- **Azioni**: ancora ogni fase alla giornata di partenza; l'asta resta evento stand-alone (non qui)

#### S-wizard-riepilogo — Wizard 5 — Riepilogo (mobile · `wizard_riepilogo.html`)
- **Componenti**: C-guida-fasi
- **Regole server**: R-fasi, R-mobile-nosquish
- **Dati**: read-back di lega + competizioni + fasi + calendario
- **Azioni**: crea la lega

