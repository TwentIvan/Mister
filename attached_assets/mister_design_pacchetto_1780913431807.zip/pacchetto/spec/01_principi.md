## 1. Principi

1. **Una sola fonte di verità per ogni "lettera".** Token in `tokens.css`. Componenti definiti una volta nel modulo 06. Le schermate **usano**, non ridefiniscono.
2. **Se cambi una lettera, si propaga.** Per i token: `tokens.css` + `propaga.py` (tecnico). Per componenti/regole/architettura: il **registro** + la **Matrice (09)** dicono dove guardare; `genera.py` rivalida e rigenera.
3. **Verificare la resa, non solo che compili.** I mockup vanno guardati renderizzati; le correzioni si fanno alla fonte (token/componente), non con pezze locali.
4. **Ogni informazione una volta sola.** Non ripetere a testo ciò che colore, posizione o un altro elemento già comunicano; non mostrare lo stesso dato in due punti della stessa schermata. Esempi reali da evitare: il punteggio ripetuto in titolo + corpo + scoreboard; "2ª giornata" sia nel kicker sia nel titolo; l'intestazione di reparto ("Portieri") quando il colore della riga già dice il ruolo. Il dato vive nel punto più forte; gli altri lo lasciano stare.

Maturità: alfabeto e schermate esistono come mockup statici, dati e loghi **segnaposto**. Restano test e integrazione runtime.
