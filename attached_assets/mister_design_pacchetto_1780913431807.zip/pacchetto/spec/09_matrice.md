## 9. Matrice di propagazione (generata da `registro.json`)

*Non modificare a mano: rigenerata da `genera.py`. Per cambiare le relazioni si edita `registro.json`.*

### 9.1 Token → componenti → schermate

| Token | Componenti che lo usano | Schermate impattate |
|---|---|---|
| `T-carta` --cream/--cream2/--paper | — | **tutte** |
| `T-verde` --green/-d/-l | C-card-evento, C-classifica-row, C-barra-panchina, C-guida-fasi, C-bracket | **tutte** |
| `T-erba` --pitch/--pitch2 | C-area-tecnica, C-marcature | S-formazione-d, S-formazione-m, S-partita-d, S-partita-m |
| `T-oro` --gold/--gold-l | C-badge, C-area-tecnica, C-card-evento, C-barra-panchina, C-bracket | S-bracket-d, S-bracket-m, S-config-asta, S-feed, S-formazione-d, S-formazione-m, S-gironi, S-paletta, S-partita-d, S-partita-m, S-rosa, S-scheda, S-tabellone |
| `T-live` --live | C-card-evento, C-classifica-row, C-bracket | S-bracket-d, S-bracket-m, S-caduta, S-classifica, S-classifica-d, S-dettaglio, S-feed, S-gironi, S-hub |
| `T-neutri` --muted/--line | C-guida-fasi | **tutte** |
| `T-ruolo` --rP/D/C/A + --ring* + --let* | C-badge, C-classifica-row | S-caduta, S-classifica, S-classifica-d, S-config-asta, S-dettaglio, S-formazione-d, S-formazione-m, S-gironi, S-hub, S-paletta, S-partita-d, S-partita-m, S-rosa, S-scheda, S-tabellone |
| `T-club` mappa colori club (bicolore) | C-badge, C-crest, C-classifica-row, C-bracket | S-bracket-d, S-bracket-m, S-caduta, S-classifica, S-classifica-d, S-config-asta, S-dettaglio, S-federazione, S-feed, S-formazione-d, S-formazione-m, S-gironi, S-hub, S-mercato, S-paletta, S-partita-d, S-partita-m, S-rosa, S-scheda, S-tabellone |
| `T-font` --disp / --mono | C-badge, C-area-tecnica, C-card-evento, C-classifica-row, C-barra-panchina, C-guida-fasi, C-bracket | **tutte** |
| `T-phone` --phone-w + no-squish | — | — |

### 9.2 Componente → schermate

| Componente | Schermate |
|---|---|
| C-badge (Badge giocatore) | S-config-asta, S-tabellone, S-paletta, S-rosa, S-scheda, S-formazione-d, S-formazione-m, S-partita-d, S-partita-m |
| C-crest (Crest bicolore) | S-tabellone, S-feed, S-federazione, S-hub, S-dettaglio, S-mercato, S-rosa, S-scheda, S-formazione-d, S-formazione-m, S-partita-d, S-partita-m, S-classifica, S-gironi, S-bracket-d, S-bracket-m, S-caduta |
| C-area-tecnica (Area tecnica) | S-formazione-d, S-partita-d, S-partita-m |
| C-marcature (Marcature campo) | S-formazione-d, S-formazione-m, S-partita-d, S-partita-m |
| C-card-evento (Card-evento) | S-feed |
| C-classifica-row (Riga classifica) | S-hub, S-dettaglio, S-classifica, S-classifica-d, S-gironi, S-caduta |
| C-barra-panchina (Barra-panchina) | S-partita-d |
| C-guida-fasi (Guida a fasi) | S-hub, S-wizard-competizioni, S-wizard-fase, S-wizard-riepilogo |
| C-bracket (Tabellone (rami)) | S-gironi, S-bracket-d, S-bracket-m |

### 9.3 Regola → ambito

| Regola | Ambito |
|---|---|
| R-oro — Oro riservato a denaro/valore | **tutte le schermate** |
| R-server — Server-authoritative | **tutte le schermate** |
| R-fonte-strato — Una fonte per strato | **tutte le schermate** |
| R-fasi — Competizione = sequenza di fasi (misura × struttura × qualificazione) | S-hub, S-gironi, S-bracket-d, S-bracket-m, S-caduta, S-classifica, S-classifica-d, S-wizard-competizioni, S-wizard-fase, S-wizard-calendario, S-wizard-riepilogo |
| R-mister-toy — Mister inciso != allenatore (toy) | C-area-tecnica |
| R-rosa — Rosa 25 / panca 14 | S-rosa, S-formazione-d, S-formazione-m, S-partita-d, S-partita-m, S-wizard-rosa |
| R-classico-gol — Conversione GF/GS (misura scontro diretto) | S-classifica, S-classifica-d, S-partita-d, S-partita-m, S-gironi, S-bracket-d, S-bracket-m |
| R-classifica-adattiva — Classifica adattiva: colonne/criteri = misura della fase | S-classifica, S-classifica-d |
| R-icona-tipo — Icona competizione = struttura (logo opzionale, fallback icona) | S-hub, S-wizard-competizioni |
| R-mobile-nosquish — 390px fisso + scroll | S-paletta, S-feed, S-hub, S-federazione, S-dettaglio, S-mercato, S-rosa, S-scheda, S-formazione-m, S-partita-m, S-classifica, S-gironi, S-bracket-m, S-caduta, S-wizard-lega, S-wizard-rosa, S-wizard-competizioni, S-wizard-fase, S-wizard-calendario, S-wizard-riepilogo |
| R-marcature — Centrocampo unico testa-a-testa | C-marcature, S-partita-d, S-partita-m |
| R-crest — Logo club reale vs disco squadra fanta | C-crest |
| R-spareggio — Supplementari e rigori (eliminazione) | S-bracket-d, S-bracket-m, S-caduta, S-partita-d, S-partita-m |
