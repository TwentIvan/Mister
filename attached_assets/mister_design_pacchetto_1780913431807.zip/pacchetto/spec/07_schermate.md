## 7. Schermate (le frasi)

Inventario e ID in `registro.json`. Dettaglio per schermata:

- **S-config-asta** (desktop, `config_asta.html`) — pagina unica. Striscia "Ereditato dalla lega" read-only (budget, rosa 3·8·8·6, mode, link a Regole di lega). Formato (live / busta chiusa). Svolgimento (a giro / per ruolo / libera) + voce. Base (Libera=1 / Quotazione). Tempi. Partecipanti & ordine. Niente budget editabile / flag spendi-tutto / conduttore (ruolo runtime).
- **S-tabellone** (desktop, `tabellone_desktop.html`) — plancia broadcast: hero 3 zone (giocatore+base oro / timer / comandi banditore con voce) + board 8 squadre (rose 25) + ticker. **Mostra**, non agisce.
- **S-paletta** (mobile, `paletta_mobile.html`) — coppia del tabellone: badge, timer-barra, offerta oro, "superato", rilanci +1/+5/+10, autobid, Parla, budget+slot.
- **S-feed** (mobile, `feed_home.html`) — gazzetta: testata, card-evento taggate, social leggero, bottom-tab + ☰.
- **S-federazione** (mobile, `federazione_home.html`) — il tuo mondo: hero identità, **albo d'oro**, bacheche, leghe, "Le regole del mondo" (niente mercati).
- **S-dettaglio** (mobile, `lega_dettaglio.html`) — panoramica: sub-nav pills, tua società, prossimo impegno, classifica mini, mercato.
- **S-mercato** (mobile, `lega_mercato.html`) — finestre in scroll, countdown, trattative aperte.
- **S-rosa** (mobile, `lega_rosa.html`) — riepilogo (FM/rosa/completezza) + lista unica di badge-roster; slot liberi visibili.
- **S-scheda** (mobile, `scheda_giocatore.html`) — hero medaglione; contesto-lega; rendimento fanta; statistiche API-Sports; storico stagioni/lega. Larghezza bloccata (R-mobile-nosquish).
- **S-formazione-d** (desktop, `lega_formazione.html`) — topbar+tab; sidebar filtri (ruolo×club) e rosa = **panchina automatica**; campo 4-3-3; **area tecnica** col Mister.
- **S-formazione-m** (mobile, `formazione_mobile.html`) — tab **Campo/Panchina**; sostituzione **a tocco** (titolare → entrante); 14 panchinari; striscia modulo+allenatore. **Interattiva.**
- **S-partita-d** (desktop, `lega_partita.html`) — punteggio; due panchine (barra-panchina) a sx; campo affacciato + due aree tecniche + centrocampo unico; due pagelle a dx. Panche da **14**.
- **S-partita-m** (mobile, `partita_mobile.html`) — punteggio; campo verticale affacciato; sotto, segmentato **Pagelle/Panchine** + selettore **La mia/Avversario**. **Interattiva.**
- **S-classifica** (mobile, `lega_classifica.html`) — tabella **# · Squadra · G · V·N·P · GF · GS · Pt · PF**. Punti/gol inchiostro (non FM).
- **S-hub** (mobile, `lega_hub.html`) — la casa della lega: identità + giornata condivisa, poi **una card per competizione** (stato a colpo d'occhio: estratto classifica per il campionato, **guida a fasi** gironi→tabellone per la coppa). Ogni card chiude con la sua **porta etichettata** ("Classifica completa" / "Vai al tabellone") e ha in alto il suo **tasto calendario**. Pila omogenea che scrolla pulita per N competizioni: niente funzioni di squadra né calendario globale qui.
- **S-classifica-d** (desktop, `classifica_dettaglio.html`) — la **vista larga** della Classifica: colonne piene `G · V · N · P · GF · GS · DR · PF · PT`. Stessa sostanza della mobile, dove c'è spazio per separare ogni colonna (la mobile raggruppa V·N·P e GF-GS).
- **S-gironi** (mobile, `coppa_gironi.html`) — la fase a gironi vista da dentro: **switch di fase** Gironi/Tabellone, classifica di ogni gruppo con le **prime K marcate (Q)**, e il **versamento** — le qualificate raccolte e **incrociate** nelle semifinali (1°A-2°B, 1°B-2°A) coi tag di provenienza. Il salto gironi→tabellone raccontato per esteso.
- **S-bracket-d** (desktop, `bracket_coppa_desktop.html`) — il **tabellone ramificato** vero: turni in colonne, connettori a gomito, spareggio in evidenza, campione col trofeo oro. Dove l'albero respira.
- **S-bracket-m** (mobile, `bracket_coppa_mobile_paged.html`) — lo stesso tabellone **un turno per schermata**: tab + scroll-snap (non analogico), i rami escono dal bordo destro e rientrano da sinistra alla **stessa altezza**, così sfogliando si percorre l'albero. (La versione *funnel* è accantonata.)
- **S-caduta** (mobile, `comp_caduta.html`) — la **sopravvivenza**: contatore "in gioco / cadute" con la fila di pallini (vivi pieni, caduti sbarrati), lista **In gioco** (sopravvissuti col punteggio che li ha salvati) e **Cadute** (in ordine inverso, col tag a freccia-giù della giornata e il punteggio fatale). Promemoria della ghigliottina viva; trofeo oro = l'ultima in piedi.
- **S-wizard-lega / -rosa / -competizioni / -fase / -calendario / -riepilogo** (mobile) — la **configurazione a cascata** (§5): crea lega → budget+rosa (3-8-8-6) → competizioni (preset o composizione delle fasi via **guida a fasi**) → ancoraggio delle fasi alle giornate reali (asta esclusa, è stand-alone) → read-back e "Crea la lega".
