## 5. Modello a strati (la grammatica)

Una lega appartiene **sempre** a una federazione (implicita/automatica nel caso "una sola lega": l'admin non vede il gergo).

- **Globale/sistema** — il dato reale: anagrafica giocatori, giornate Serie A, voti grezzi (API-Sports).
- **Federazione** — l'istituzione: **identità** (nome+logo) · **regole** (algoritmo voto + punteggio/ruoli **flessibili**, non rigido classic/mantra — qui vivono anche i **parametri di conversione gol** del classico: soglia base e passo, vedi `R-classico-gol`) · **convalida** · **memoria/prestigio** (albo d'oro). Catena: lega organizza → federazione convalida → premiabile → albo d'oro. Strato **latente**: affiora come identità+albo (visibile) e governance (owner).
- **Lega** — l'organizzatore: competizioni · **mercati** (asta/scambi/svincoli) · **quotazioni** · partecipanti · rosa · budget. I mercati sono di **lega**, non di federazione. Ogni lega legge/congela uno **snapshot** della federazione.
- **Competizione** — una **sequenza di fasi** (vedi *Composizione* sotto), da cui discende come i risultati diventano graduatoria/tabellone e *quale punteggio si racconta*. Organizzata dalla lega; legge le regole della federazione senza duplicarle (`R-fonte-strato`).
- **Modelli/template** — ricette di default che seminano valori alla creazione. Trasversali, **non** legati alla federazione, **non** voce di menu. Es. "Classico" semina le finestre abituali, tutte **editabili**.

### Composizione: fasi, misura, struttura

Una **competizione** è una **sequenza ordinata di fasi**. Una **fase** combina due assi indipendenti, e risolve *come una giornata di punteggi grezzi diventa esito ufficiale* — prodotto **una sola volta** e letto da Feed/Classifica/Partita (`R-classico-gol`, `R-fonte-strato`).

**Misura** — come una giornata diventa un valore per la squadra:
- *scontro diretto* — affronti avversari → conversione gol → punti V/N/P; sotto-parametro: contro **uno** (calendario) o contro **tutti** (ogni giornata); sola andata o andata/ritorno.
- *punteggio assoluto* — vale il tuo totale grezzo.
- *posizione* — il piazzamento di giornata → punti da tabella (alla F1).

**Struttura** — come la fase decide:
- *classifica* — si accumula, vince il totale; parametro **numero di gironi** (1 = girone unico; N = gironi).
- *tabellone* — eliminazione a scontri secchi; parametri: gambe (andata/ritorno), spareggio (`R-spareggio`).
- *caduta* — ogni giornata esce chi sta sotto; parametro: quanti escono.

**Qualificazione** — ogni fase non-finale dichiara *chi passa* alla successiva e con quale criterio (primi K per girone · migliori M assoluti · vincitori del tabellone).

I nomi noti sono **combinazioni**, non scatole: *campionato* = una fase `classifica · scontro vs uno`; *battle royale* = `classifica · scontro vs tutti`; *punteggio assoluto* = `classifica · assoluto`; *Formula 1* = `classifica · posizione`; *coppa* = `tabellone` (o `classifica a gironi → tabellone`); *last dead* = `caduta`. Lo spareggio serve solo dove un vincitore è obbligatorio (tabellone; caduta in caso di pari per l'ultimo posto) — nella classifica il pari è sano.

*Supercoppa: accantonata* — i suoi ingressi vengono dai vincitori di **altre** competizioni (qualificazione cross-competizione), fuori dal modello a fasi attuale.

### Configurazione — il wizard (dall'alto in giù)

La configurazione scende per livelli, ognuno **eredita** quello sopra:
1. **Federazione** — regole del mondo: algoritmo voto, parametri di conversione gol. (Nel caso semplice, implicita.)
2. **Lega** — budget, struttura rosa (25 = 3-8-8-6), manager/squadre, finestre di mercato (l'asta).
3. **Competizioni** — una o più; per ognuna scegli un **preset** (campionato, coppa) oppure **componi le fasi** a mano (misura × struttura); ogni fase non-finale dichiara la sua **qualificazione**.
4. **Calendario** — allinea le **fasi** delle competizioni alle **giornate reali** di Serie A: per ogni fase scegli la giornata di partenza, la durata deriva dalla config. L'**asta** è un evento **stand-alone** della lega (area mercati), *non* agganciato alle giornate; può comparire nella vista calendario ma non si schedula qui.

Divisioni: **non** esistono ora (futuro).
