# Mister — Marchio & Lingua visiva

Pacchetto identità. Concept: **almanacco editoriale × terminale manageriale**.

## File
- `lingua_visiva.html` — styleguide vivo (apri nel browser): marchio, palette, tipografia, vocabolario.
- `marchio/wordmark_mister.svg` — wordmark "Mister", Fraunces 800, tracciato vettoriale (indipendente dal font).
- `marchio/icona_M.svg` — icona app: M-formazione, **su verde** (linee oro chiaro, nodi oro scuro).
- `marchio/icona_M_animata.svg` — icona con animazione M↔W (parte da sola nel browser).
- `marchio/segno_M_carta.svg` — il segno per fondo **carta/crema**: linee verdi, nodi oro.
- `marchio/lockup_impilato.svg` — lockup consigliato: segno sopra, wordmark sotto.
- `volto/mister_volto_inciso.png` — ritratto inciso, trasparente, alta risoluzione (accento hero).

## Palette
Carta crema `#efe6d3` · paper `#f7f1e4` · slot `#cdbf9d`
Inchiostro verde `#1f4733` · profondo `#15301f` · chiaro `#2e6047`
Oro `#c8922b` · oro chiaro `#e6b84d` (solo denaro/FM/valore/marchio)
Live `#e2554e` · danger `#bf3b30` · muted `#8a8266` · filo `#d8ccae`

## Tipografia
- **Fraunces** — voce display/wordmark. Ricetta wordmark: peso **800**, **ss01**, `letter-spacing -0.05em`, `line-height 0.9`, optical-sizing auto.
- **JetBrains Mono** — cavallo da lavoro (dati, matrice, etichette). NIENTE DM Sans.

## Il segno (M-formazione)
- La M è disegnata da una formazione: **2 nodi in alto, 3 in basso** (2-3-3-2). Piedi larghi, vertici stretti → una W rovesciata.
- Costruito sullo scheletro reale della M di Fraunces (stesse proporzioni e peso) → contrasto simbolo↔logotipo voluto.
- **Animazione**: i cinque nodi scivolano dalla M alla W e tornano (il WM di Chapman). La W appare solo nel movimento.

### Regola colore (importante)
- **I nodi sono SEMPRE oro `#c8922b`** — l'elemento d'identità costante (i giocatori / il valore).
- **Le linee prendono l'inchiostro del fondo**: oro chiaro `#e6b84d` su verde; verde `#1f4733` su carta.
- Mai linee e nodi dello stesso colore (i nodi affogano). Mai il segno tutto-oro su crema (slavato).

## Regole d'uso
- L'icona/segno vive **da sola** (app, favicon, splash).
- Nel lockup: **impilato** (segno sopra il wordmark) o wordmark da solo. Mai una M-segno attaccata prima di "Mister" (balbettio "M-Mister").
- **Acquaforte = accento raro**, non lingua: il volto inciso solo in momenti hero. NON sulle facce dei calciatori, NON come texture d'interfaccia. La cornice (tipo + palette) fa da collante; i giocatori vivono in uno stile loro coerente.
